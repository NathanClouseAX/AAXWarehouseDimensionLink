﻿param
(
    [switch]$multibox,
    [Parameter(Mandatory=$false)]
    [string]$relatedFilesDir,
    [Parameter(Mandatory=$false)]
    [string]$targetDirectory,
    [Parameter(Mandatory=$false)]
    [string]$deploymentDir,
    [Parameter(Mandatory=$false)]
    [string]$LogDir,
    [switch]$useServiceFabric = $false,
    [Parameter(Mandatory=$false)]
    [string]$webroot,
    [Parameter(Mandatory=$false)]
    [string]$aosPackageDirectory,
    [Parameter(Mandatory=$false)]
    [string]$sourcePackageDirectory,
    [Parameter(Mandatory=$false)]
    [switch]$useStaging,
    [Parameter(Mandatory=$false)]
    [string]$tempWorkFolder = ""
)

$Global:installedPackages=@()

function GenerateSymLinkNgen([string]$webroot,[string]$metadataPackagePath)
{
    if($useServiceFabric)
    {
        $DeveloperBox = $false
    }
    else
    {
        $DeveloperBox = Get-DevToolsInstalled
    }
    if(!($DeveloperBox))
    { 
        write-output "Updating Symlink and Ngen Assemblies"
        $SymLinkNgenLog = join-path $LogDir "update_SymLink_NgenAssemblies.log"
        $argumentList = '–webroot:"$webroot" –packagedir:"$metadataPackagePath" –log:"$SymLinkNgenLog"'
      
      $NgenoutPutLog=join-path $LogDir "update_NgenOutput_$datetime.log"
  
      if(!(Test-Path $NgenoutPutLog))
      {
        New-Item -ItemType file $NgenoutPutLog -Force
      }

        invoke-Expression "$metadataPackagePath\bin\CreateSymLinkAndNgenAssemblies.ps1 $argumentList" >> $NgenoutPutLog
    }
}

function UpdateAdditionalFiles([string]$webRoot,[string]$packageDir)
{
    $directorys = Get-ChildItem $packageDir -Directory
    foreach ($moduleName in $directorys) 
    {
        $modulePath=Join-Path $packageDir $moduleName
        $additionalFilesDir=join-path $modulePath "AdditionalFiles"

        if(Test-Path $additionalFilesDir)
        {
            Write-log "Processing additional files for '$moduleName' "
            $filelocationsfile=join-path "$modulePath" "FileLocations.xml"
            if(Test-Path "$filelocationsfile")
            {
                [System.Xml.XmlDocument] $xd = new-object System.Xml.XmlDocument
                $xd.Load($filelocationsfile)
                $files=$xd.SelectNodes("//AdditionalFiles/File")
                foreach($file in $files)
                {
                    $assembly=[System.IO.Path]::GetFileName($file.Source)
                    $destination=$file.Destination
                    $relativepath=$file.RelativePath
                    $fullassemblypath=join-path "$modulePath" "AdditionalFiles\$assembly"

                    # the reason why we need to check for IsNullorEmpty() for the parameters is because the c:\pakages\bin
                    # comes from both the platform and app side. If the app bin package gets installed first
                    # it will leave a FileLocations.xml file at c:\packages\bin which will be processed by the 
                    # platform bin package when it gets installed. We want to ensure that we do not throw an exception
                    # even if we don't find the correct set of parameters being passed from the calling function. 
                    switch($destination)
                    {
                        "AOSWeb" #enum for AOS webroot
                        {
                            $target=join-path "$webRoot" "$relativepath"
                        }

                        "PackageBin" #enum for \packages\bin
                        {
                            if(-not [string]::IsNullOrEmpty($packageDir))
                            {   
                                $target=join-path "$packageDir" "bin"
                            }
                        }

                        "ModuleBin" #enum for \<<modulename>>\bin
                        {
                            $target=join-path "$modulePath" "bin"
                        }

                        "PackageDir" #enum for \packages\<<relativepath>>
                        {
                            if(-not [string]::IsNullOrEmpty($packageDir))
                            {
                                $target=join-path "$packageDir" "$relativepath"
                            }
                        }
                    }

                    if((Test-Path "$fullassemblypath") -and (-not [string]::IsNullOrEmpty($target)))
                    {
                        if(!(Test-Path "$target"))
                        {
                            Write-log "Creating target directory '$target'"
                            New-item -Path "$target" -ItemType "directory" -Force
                        }

                        $targetfile=join-path "$target" $assembly
                        Write-log "Copying '$fullassemblypath' to '$targetfile'"
                        Copy-Item -path:"$fullassemblypath" -destination:"$targetfile" -Force
                    }
                }
            }

            Write-log "Removing '$additionalFilesDir'..."
            Remove-Item -Path $additionalFilesDir -Recurse -Force|out-null
        } 
    }
}

function Update-PackageReferenceFile([string]$metadataPath,[string]$packageZipPath, [string]$tempdir)
{
    $ErrorActionPreference = "stop"

    $7zip=join-path $env:SystemDrive "DynamicsTools\7za.exe"
    $temppackagesdir=join-path $tempdir "temp_$(new-guid)"
    
    if(Test-Path $packageZipPath)
    {
        $zipFileNoExt = [System.IO.Path]::GetFileNameWithoutExtension($packageZipPath)
        $updateRefLog = join-path $LogDir "install-$zipFileNoExt-$datetime.log"
        $unzipLogName = "install-$zipFileNoExt-$datetime-unzip.log"
        $unzipLog = join-path $LogDir $unzipLogName
        
        $start = (Get-Date).ToUniversalTime()
        ("[{0}] Begin: Updating references from '{1}'" -f $start.ToString("o"), $packageZipPath) >> $updateRefLog
        
        if(!(Test-Path $temppackagesdir)){
            New-Item $temppackagesdir -ItemType directory -Force >$null
        }
        
        "Unzipping $packageZipPath to $temppackagesdir..."  >> $updateRefLog

        $zip = Start-Process $7zip -ArgumentList "x $packageZipPath -o$temppackagesdir -y -mmt" -Wait -WindowStyle Hidden -PassThru -RedirectStandardOutput $unzipLog

        if($zip.ExitCode -ne "0")
        {
          "7zip failed to unzip $packageZipPath. See '$unzipLogName' for details." >> $updateRefLog
          throw "7Zip failed to extract dynamics packages reference file."
        }

        $directories = Get-ChildItem $temppackagesdir -Directory
        foreach ($directory in $directories) 
        {
            $TargetReferenceUpdateDirectory = join-path $metadataPath $directory.Name
            if(Test-Path $TargetReferenceUpdateDirectory)
            {
                "Copying '$($directory.FullName)' to '$TargetReferenceUpdateDirectory'..."  >> $updateRefLog
                Copy-Item -Path ([IO.Path]::Combine($directory.FullName,"*")) -Destination $TargetReferenceUpdateDirectory -Force -Recurse
            }
        }

        if(Test-Path $temppackagesdir) 
        {
            "Removing temp directory '$temppackagesdir'..." >> $updateRefLog
            Remove-Item $temppackagesdir -recurse -force
        }
        
        $end = (Get-Date).ToUniversalTime()
        ("[{0}] End: Updating references from '{1}'" -f $start.ToString("o"), $packageZipPath) >> $updateRefLog
    }
}

function Install-Package([string]$packageName,[string]$metadataPath,[string]$source,[string]$log)
{
    $ErrorActionPreference = "stop"

    $dynamicstools="DynamicsTools"
    $installationrecords = Join-Path $metadataPath "InstallationRecords"
    $packageinstallationrecord = Join-Path $installationrecords $packageName
   
    $nuget=join-path $env:SystemDrive "$dynamicstools\nuget.exe"
    
    "removing package installation record $packageinstallationrecord.*" >> $log
    get-childitem -path "$installationrecords" -filter "$packageName.*" | remove-item -force -recurse

    "Unpacking the Dynamics packages to $installationrecords" >> $log

    "Running command: $nuget install -OutputDirectory `"$installationrecords`" $packageName -Source $source" >> $log
    if([System.Version]([System.Diagnostics.FileVersionInfo]::GetVersionInfo($nuget).FileVersion) -ge [System.Version]"2.9.0.0")
    {
        & $nuget install -OutputDirectory "$installationrecords" $packageName -Source $source -DependencyVersion highest #nuget version > 2.8 change behaviour and add a new switch to set it back
    }
    else
    {
        & $nuget install -OutputDirectory "$installationrecords" $packageName -Source $source
    }
    # check the last exit code and decide if the package(s) were installed correctly
    if($LASTEXITCODE -ne 0)
    {
        Throw "Something went wrong when installing the Dynamics package '$packageName'. Make sure the package name is correct and that it exists at the source directory '$source'."
    }
    
} 

function Install-ZipPackage ([string]$clickoncePath,[string]$metadataPath,[string]$frameworkPath,[string]$packageZipPath,[string]$source,[string]$webroot,[string]$log)
{
    $ErrorActionPreference = "stop"

    #install package
    $arguments='clickOnceInstallPath="{0}";metadataInstallPath="{1}";frameworkInstallPath="{2}";packageZipDrop="{3}";webroot="{4}";log="{5}"' -f $clickoncePath,$metadataPath,$frameworkPath,$packageZipPath,$webroot,$log
    $arguments
    $env:DynamicsPackageParameters=$arguments
    $dynamicstools="DynamicsTools"
    $installationrecords = Join-Path $metadataPath "InstallationRecords"
    $packageinstallationrecord = Join-Path $installationrecords $packageName

    # iterate over every installed package and run the custom powershell script
    $packagesdir=[System.IO.Directory]::EnumerateDirectories($installationrecords,"*",[System.IO.SearchOption]::TopDirectoryOnly)
    foreach ($dir in $packagesdir){
        $currentpackagename=[System.IO.Path]::GetFileName($dir)
        $toolsdir=Join-Path $dir "tools"
        $installscript=join-path $toolsdir "installpackage.ps1"
        if(Test-Path $installscript){ 
           $Global:installedPackages+=$currentpackagename

        }     
    }
    Parallel-Install -packagesName:$Global:installedPackages -installationrecorddir:$installationrecords
}

function Remove-MetadataSourceDirectory([string] $packageName, [string] $packageInstallPath)
{
    $basePackageName = $($packageName.split('-')[1])
    
    if ($packageName.EndsWith('-compile'))
    {
        $packageInstallPath = Join-Path $packageInstallPath $basePackageName
        $packageInstallPath = Join-Path $packageInstallPath 'XppMetadata'
        if(Test-Path $packageInstallPath)
        {
            #powershell bug - Remove-Item comlet doesn't implement -Recurse correctly
            #Remove-Item $packageInstallPath -Force -Recurse
            get-childitem -path "$packageInstallPath" -recurse | remove-item -force -recurse
        }
    }
    if ($packageName.EndsWith('-develop'))
    {
        $packageInstallPath = Join-Path $packageInstallPath $basePackageName
        $packageInstallPath = Join-Path $packageInstallPath $basePackageName
        if(Test-Path $packageInstallPath)
        {
            #powershell bug - Remove-Item comlet doesn't implement -Recurse correctly
            #Remove-Item $packageInstallPath -Force -Recurse
            get-childitem -path "$packageInstallPath" -recurse | remove-item -force -recurse
        }
    }
}

function Parallel-Install([string[]] $packagesName, [string] $installationrecorddir)
{
    $ErrorActionPreference = "stop"
    foreach($pkg in $packagesName){
        $dir = Join-Path $installationrecorddir $pkg
        $toolsdir=Join-Path $dir "tools"
        $installscript=join-path $toolsdir "installpackage.ps1"
        if(Test-Path $installscript){
            Write-Output "Running script '$installScript'"
            & $installscript
            Move-item $installscript ($installscript+".executed") -Force
        }
        
    }
}

if(!$useServiceFabric){
    Import-Module WebAdministration
}

Import-Module "$PSScriptRoot\CommonRollbackUtilities.psm1" -ArgumentList $useServiceFabric -DisableNameChecking
Import-Module "$PSScriptRoot\AosEnvironmentUtilities.psm1"  -ArgumentList $useServiceFabric -Force -DisableNameChecking

if (!$useServiceFabric)
{
    if (Test-Path "$($PSScriptRoot)\NonAdminDevToolsInterject.ps1")
    {
        & "$PSScriptRoot\NonAdminDevToolsInterject.ps1"
    }
}

$ErrorActionPreference = "stop"

if($tempWorkFolder -ne "")
{
    $tempPackagesDir = $tempWorkFolder
}
else
{
    $tempPackagesDir = [System.IO.Path]::GetTempPath()
}

if($useStaging)
{
    $webroot = join-path $(Get-AosServiceStagingPath) "webroot"
    $metadataPackagePath = join-path $(Get-AosServiceStagingPath) "PackagesLocalDirectory"
    $frameworkPackagePath = join-path $(Get-AosServiceStagingPath) "PackagesLocalDirectory"
    $sourcePath = [IO.Path]::Combine($(split-Path -parent $PSScriptRoot), "Packages")
}
elseif($useServiceFabric)
{
    $webroot = (Resolve-Path $webroot).ProviderPath
    $clickOncePackagePath = join-path $webroot "apps"
    $sourcePath = $sourcePackageDirectory
    $metadataPackagePath = $aosPackageDirectory
    $frameworkPackagePath = $aosPackageDirectory
    if($tempWorkFolder -eq "")
    {
        $tempPackagesDir = $sourcePath
    }
}
else
{
    $webroot = Get-AosWebSitePhysicalPath
    $metadataPackagePath = $(Get-AOSPackageDirectory)
    $frameworkPackagePath = $(Get-AOSPackageDirectory)  
    $sourcePath = [IO.Path]::Combine($(split-Path -parent $PSScriptRoot), "Packages")
}

if(!$useServiceFabric)
{
    $clickOncePackagePath = $(Get-InfrastructureClickonceAppsDirectory)
    $clickOncePackagePath = [IO.Path]::Combine($webroot,$clickOncePackagePath)
}

$resourcePath = [IO.Path]::Combine($webroot,"Resources")
$packageZipDrop = [IO.Path]::Combine($sourcePath,"files")

if((![string]::IsNullOrWhiteSpace($targetDirectory)) -and (Test-path $targetDirectory))
{
    $metadataPackagePath = $targetDirectory
    $frameworkPackagePath = $targetDirectory
}   

if((![string]::IsNullOrWhiteSpace($deploymentDir)) -and (Test-path $deploymentDir))
{
    if($multibox)
    {
        $clickOncePackagePath = [IO.Path]::Combine($deploymentDir,"WebRoot\apps")
        $webroot=[IO.Path]::Combine($deploymentDir,"WebRoot")
        $resourcePath = [IO.Path]::Combine($deploymentDir,"WebRoot\Resources")
    }
    else
    {
        $clickOncePackagePath = [IO.Path]::Combine($deploymentDir,"DObind\Packages\Cloud\AosWebApplication\AosWebApplication.csx\roles\AosWeb\approot\apps")
        $webroot=[IO.Path]::Combine($deploymentDir,"DObind\Packages\Cloud\AosWebApplication\AosWebApplication.csx\roles\AosWeb\approot")
        $resourcePath = [IO.Path]::Combine($deploymentDir,"DObind\Packages\Cloud\AosWebApplication\AosWebApplication.csx\roles\AosWeb\approot\Resources")
    }
}

if((![string]::IsNullOrWhiteSpace($relatedFilesDir)) -and (Test-Path $relatedFilesDir))
{
    $sourcePath = $relatedFilesDir
    $packageZipDrop = [IO.Path]::Combine($relatedFilesDir,"files")
}    

$datetime=get-date -Format "MMddyyyyhhmmss"

if(!$LogDir)
{
    $LogDir = $PSScriptRoot
}

$log=join-path $LogDir "install-AXpackages_$datetime.log"
  
if(!(Test-Path $log)){
    New-Item -ItemType file $log -Force
}

$innerlog=join-path $LogDir "update-AXpackages_$datetime.log"
  
if(!(Test-Path $innerlog)){
    New-Item -ItemType file $innerlog -Force
}


$startdatetime=get-date
"*******************************************************" >> $log
"** Starting the package deployment at $startdatetime **" >> $log
"*******************************************************" >> $log

$installationrecords = Join-Path -Path $metadataPackagePath -ChildPath "InstallationRecords"

if(!(Test-Path $installationrecords))
{
        "creating installation record directory '$installationrecords' to kept the installation history" >> $log
        New-Item $installationrecords -ItemType directory -Force
}
else
{
    # clean up prior nuget installation of the previous package that fail to install
    $packagesdir=[System.IO.Directory]::EnumerateDirectories($installationrecords,"*",[System.IO.SearchOption]::TopDirectoryOnly)
    foreach ($dir in $packagesdir)
    {
        $toolsdir=Join-Path $dir "tools"
        $installscript=join-path $toolsdir "installpackage.ps1"
        if(Test-Path $installscript)
        {
            Move-item $installscript ($installscript+".executed") -Force
        }
    }
}

if($useServiceFabric)
{
    $DeveloperBox = $false
}
else
{
    $DeveloperBox = Get-DevToolsInstalled
}

#Check if this is a platform update package base on existence of the config file.
#if it's platformUpdate3 or later, also perform the meta package installation for platform binarys
if ((Test-Path "$PSScriptRoot\PlatformUpdatePackages.Config") -or (Get-IsPlatformUpdate3OrLater -webroot:$webroot))
{
    if(Test-Path $sourcePath)
    {
        [Void][Reflection.Assembly]::LoadWithPartialName('System.IO.Compression.FileSystem')
        if ($DeveloperBox -eq $true)
        {
            $PackageToInstall = "dynamicsax-meta-platform-development"
        }
        else
        {
            $PackageToInstall = "dynamicsax-meta-platform-runtime"
        }
        if(![string]::IsNullOrWhiteSpace($PackageToInstall))
        {
            $zipFile = Get-Item $sourcePath\$PackageToInstall*.nupkg
            if($zipFile -eq $null)
            {
                #only throw error if it's a dedicated inplace upgrade package, 
                #on any other package it's possible that the meta package doesn't existing thus no operation required
                if(Test-Path "$PSScriptRoot\PlatformUpdatePackages.Config")
                {
                    Throw "Unable to get package information"
                }

            }
            else
            {
                $PackFiles = [IO.Compression.ZipFile]::OpenRead($zipFile).Entries
                $PackageSpec =  $PackFiles | where {($_.Name -like '*.nuspec')}

                if(!($PackageSpec))
                {
                    Throw "Unable to get package information"
                }

                [System.Xml.XmlDocument] $xmlDoc=new-object System.Xml.XmlDocument
                $XmlDoc.Load($PackageSpec.Open())

                $Dependencies = $xmlDoc.GetElementsByTagName('dependency').id

                if($Dependencies.Contains("dynamicsax-systemhealth"))
                {
                    #Remove AxPulse due to the name change to SystemHealth in PlatUpdate3
                    $axPulsePath = Join-Path -Path $metadataPackagePath -ChildPath "axpulse"
                   
                    if(Test-Path $axPulsePath)
                    {
                        Remove-Item $axPulsePath -Force -Recurse
                    }
                    if(Test-Path $installationrecords)
                    {
                        get-childitem -path "$installationrecords" -filter "dynamicsax-axpulse.*" | remove-item -force -recurse 
                    }
                }

                #Install all packages in meta-package definition
                forEach ($Package in $Dependencies)
                {
                    #if it's not appFall or later, install directory package from platform
                    #all other platform package specified in meta package will get installed
                    if(($($package.Split("-")[1]) -ne 'Directory') -or (!$(Get-IsAppFallOrLater -webroot:$webroot)))
                    {
                        "removing package installation record $Package.*" >> $log
                        get-childitem -path "$installationrecords" -filter "$Package.*" | remove-item -force -recurse  
                        
                        #Remove MetaData and Source Directories for the package before Installing
                        Remove-MetadataSourceDirectory -packageName $Package -packageInstallPath $metadataPackagePath 
                    }
                }
                Install-Package -packageName:$PackageToInstall -metadataPath:$metadataPackagePath -source:$sourcePath -log:$log >> $innerlog
            }
        }
    }
}

#dependencyaos
#Install App packages if it is sealed
if($(Get-IsAppSealed -webroot:$webroot ))
{
    if(Test-Path $sourcePath)
    {
        [Void][Reflection.Assembly]::LoadWithPartialName('System.IO.Compression.FileSystem')   
        if($useServiceFabric)
        {
            $DeveloperBox = $false
        }
        else
        {
            $DeveloperBox = Get-DevToolsInstalled
        }
        if ($DeveloperBox -eq $true)
        {
            $PackageToInstall = "dynamicsax-meta-application-development"
        }
        else
        {
            $PackageToInstall = "dynamicsax-meta-application-runtime"
        }
        if(![string]::IsNullOrWhiteSpace($PackageToInstall))
        {
            $zipFile = Get-Item $sourcePath\$PackageToInstall*.nupkg

            if($zipFile -ne $null)
            {
                $PackFiles = [IO.Compression.ZipFile]::OpenRead($zipFile).Entries
                $PackageSpec =  $PackFiles | Where-Object {($_.Name -like "*.nuspec")}

                if(!($PackageSpec))
                {
                    Throw "Unable to get package information"
                }

                [System.Xml.XmlDocument] $xmlDoc=new-object System.Xml.XmlDocument
                $XmlDoc.Load($PackageSpec.Open())

                $Dependencies = $xmlDoc.GetElementsByTagName('dependency').id

                #Install all packages in meta-package definition
                forEach ($Package in $Dependencies)
                {
                    "removing package installation record $Package.*" >> $log
                    get-childitem -path "$installationrecords" -filter "$Package.*" | remove-item -force -recurse

                    #Remove MetaData and Source Directories for the package before Installing
                    Remove-MetadataSourceDirectory -packageName $Package -packageInstallPath $metadataPackagePath
                }
                Install-Package -packageName:$PackageToInstall -metadataPath:$metadataPackagePath -source:$sourcePath -log:$log >> $innerlog
            }  
        }
    }
}

#still need to perform the aot package installation that's not part of platform or app.
if(!(Test-Path "$PSScriptRoot\PlatformUpdatePackages.Config"))
{
    if(Test-Path $sourcePath)
    {
        $files=get-childitem -Path:$sourcePath *.nupkg
        foreach ($packageFile in $files) 
        {
            #if it's not platupdate3 or later, install all package
            #if it's platupdate3 or later, install all package that's not part of platform
            if($(Get-IsModulePartOfPlatformAsBinary -packageNugetFile $packageFile.FullName))
            {
                if(!$(Get-IsPlatformUpdate3OrLater -webroot:$webroot))
                {
                    Install-Package -packageName:($packageFile.BaseName).Split(".")[0] -metadataPath:$metadataPackagePath -source:$sourcePath -log:$log >> $innerlog
                }
            }
            # If app is not sealed, install all [Application Package]
            elseif(Get-IsModulePartOfApplicationAsBinary -PackageNugetFilePath $packageFile.FullName)
            {
                if(!$(Get-IsAppSealed -webroot:$webroot))
                {
                    Install-Package -packageName:($packageFile.BaseName).Split(".")[0] -metadataPath:$metadataPackagePath -source:$sourcePath -log:$log >> $innerlog
                }
            }
            # Allow customer extension
            else
            {
                Install-Package -packageName:($packageFile.BaseName).Split(".")[0] -metadataPath:$metadataPackagePath -source:$sourcePath -log:$log >> $innerlog
            }
        }
    }
}

Install-ZipPackage -metadataPath:$metadataPackagePath -clickoncePath:$clickOncePackagePath -frameworkPath:$frameworkPackagePath -packageZipPath:$packageZipDrop -source:$sourcePath -webroot:$webroot -log:$log >> $innerlog

write-output "Updating Metadata Resources File."
$UpdateResourcesLog = join-path $LogDir "update_Resources_$datetime.log"
$ResourceConfig = @{"Common.BinDir"= $metadataPackagePath; "Infrastructure.WebRoot"= $webroot}
$ResourceBase64Config = ConvertTo-Json $ResourceConfig
$ResourceBase64Config = [System.Convert]::ToBase64String([System.Text.Encoding]::UTF8.GetBytes($ResourceBase64Config))
$argumentList = '–config:"$ResourceBase64Config" –log:"$UpdateResourcesLog"'

$Resourceslog=join-path $LogDir "update_ResourcesOutPut_$datetime.log"
  
if(!(Test-Path $Resourceslog)){
    New-Item -ItemType file $Resourceslog -Force
}

invoke-Expression "$PSScriptRoot\DeployResources.ps1 $argumentList" >> $ResoucesLog

write-output "Updating Metadata Reference File."
Update-PackageReferenceFile -metadataPath:$metadataPackagePath -packageZipPath:$(join-path $packageZipDrop "MetadataReferenceApp.zip") -tempdir:$tempPackagesDir
Update-PackageReferenceFile -metadataPath:$metadataPackagePath -packageZipPath:$(join-path $packageZipDrop "MetadataReferencePlat.zip") -tempdir:$tempPackagesDir

write-output "Updating Additional File."
UpdateAdditionalFiles -webRoot:$webroot -packageDir:$metadataPackagePath

try
{
    if(!$useServiceFabric)
    {

        $DeveloperBox = Get-DevToolsInstalled
   
        if(!($DeveloperBox))
        { 
            if(Test-Path "$PSScriptRoot\RemoveSymLinkAndNgenAssemblies.ps1")
            {
                Write-Output "Removing SymLink And NgenAssemblies..."
                if($useStaging)
                {
                    invoke-Expression "$PSScriptRoot\RemoveSymLinkAndNgenAssemblies.ps1 -useStaging"    
                }
                else
                {
                    invoke-Expression "$PSScriptRoot\RemoveSymLinkAndNgenAssemblies.ps1"
                }
            }
        }
    }
}
 catch
{
    #always generate symlink point to the none staging folder of aos services
    GenerateSymLinkNgen -webroot:$webroot -metadataPackagePath:$(Get-AOSPackageDirectory)
}

if(!$useServiceFabric)
{
    write-output "Creating Metadata Module Installation Info."
    try
    {
        ##do not touch monitoring when performing aos staging folder operation, the ma should be on already and attempt to restart it may create outage in ma and or faile to restart ma
        if(!$useStaging)
        {
            StartMonitoring
        }
        $CommonBin = $(Get-CommonBinDir)
        #using Add-Type which will auto load all referenced dll
        Add-Type -Path "$CommonBin\bin\Microsoft.Dynamics.AX.AXInstallationInfo.dll"
        [Microsoft.Dynamics.AX.AXInstallationInfo.AXInstallationInfo]::ScanMetadataModelInRuntimePackage($metadataPackagePath)
        
    }
    catch
    {
        write-warning "Failed to create metadata module installation record"
    }
}
$enddatetime=get-date
"******************************************************" >> $log
"** Completed the package deployment at $enddatetime **" >> $log
"******************************************************" >> $log
"" >> $log
$duration=$enddatetime-$startdatetime
"Package deployment duration:" >> $log 
"$duration" >> $log 
    
"" >> $log
"******************************************************" >> $log
"Packages installed in this session:" >> $log
"******************************************************" >> $log
foreach($pkg in $Global:installedPackages){
    "$pkg" >> $log
}

""
"******************************************************"
"Packages installed in this session:"
"******************************************************"
foreach($pkg in $Global:installedPackages){
    "$pkg"
}
""
"installation log file: $log"


# SIG # Begin signature block
# MIIjtgYJKoZIhvcNAQcCoIIjpzCCI6MCAQExDzANBglghkgBZQMEAgEFADB5Bgor
# BgEEAYI3AgEEoGswaTA0BgorBgEEAYI3AgEeMCYCAwEAAAQQH8w7YFlLCE63JNLG
# KX7zUQIBAAIBAAIBAAIBAAIBADAxMA0GCWCGSAFlAwQCAQUABCCoVguGyrCbVcO2
# UhBXLH0fbeis2AVTMS+xgVQgfTxiK6CCDYEwggX/MIID56ADAgECAhMzAAABA14l
# HJkfox64AAAAAAEDMA0GCSqGSIb3DQEBCwUAMH4xCzAJBgNVBAYTAlVTMRMwEQYD
# VQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNy
# b3NvZnQgQ29ycG9yYXRpb24xKDAmBgNVBAMTH01pY3Jvc29mdCBDb2RlIFNpZ25p
# bmcgUENBIDIwMTEwHhcNMTgwNzEyMjAwODQ4WhcNMTkwNzI2MjAwODQ4WjB0MQsw
# CQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9u
# ZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMR4wHAYDVQQDExVNaWNy
# b3NvZnQgQ29ycG9yYXRpb24wggEiMA0GCSqGSIb3DQEBAQUAA4IBDwAwggEKAoIB
# AQDRlHY25oarNv5p+UZ8i4hQy5Bwf7BVqSQdfjnnBZ8PrHuXss5zCvvUmyRcFrU5
# 3Rt+M2wR/Dsm85iqXVNrqsPsE7jS789Xf8xly69NLjKxVitONAeJ/mkhvT5E+94S
# nYW/fHaGfXKxdpth5opkTEbOttU6jHeTd2chnLZaBl5HhvU80QnKDT3NsumhUHjR
# hIjiATwi/K+WCMxdmcDt66VamJL1yEBOanOv3uN0etNfRpe84mcod5mswQ4xFo8A
# DwH+S15UD8rEZT8K46NG2/YsAzoZvmgFFpzmfzS/p4eNZTkmyWPU78XdvSX+/Sj0
# NIZ5rCrVXzCRO+QUauuxygQjAgMBAAGjggF+MIIBejAfBgNVHSUEGDAWBgorBgEE
# AYI3TAgBBggrBgEFBQcDAzAdBgNVHQ4EFgQUR77Ay+GmP/1l1jjyA123r3f3QP8w
# UAYDVR0RBEkwR6RFMEMxKTAnBgNVBAsTIE1pY3Jvc29mdCBPcGVyYXRpb25zIFB1
# ZXJ0byBSaWNvMRYwFAYDVQQFEw0yMzAwMTIrNDM3OTY1MB8GA1UdIwQYMBaAFEhu
# ZOVQBdOCqhc3NyK1bajKdQKVMFQGA1UdHwRNMEswSaBHoEWGQ2h0dHA6Ly93d3cu
# bWljcm9zb2Z0LmNvbS9wa2lvcHMvY3JsL01pY0NvZFNpZ1BDQTIwMTFfMjAxMS0w
# Ny0wOC5jcmwwYQYIKwYBBQUHAQEEVTBTMFEGCCsGAQUFBzAChkVodHRwOi8vd3d3
# Lm1pY3Jvc29mdC5jb20vcGtpb3BzL2NlcnRzL01pY0NvZFNpZ1BDQTIwMTFfMjAx
# MS0wNy0wOC5jcnQwDAYDVR0TAQH/BAIwADANBgkqhkiG9w0BAQsFAAOCAgEAn/XJ
# Uw0/DSbsokTYDdGfY5YGSz8eXMUzo6TDbK8fwAG662XsnjMQD6esW9S9kGEX5zHn
# wya0rPUn00iThoj+EjWRZCLRay07qCwVlCnSN5bmNf8MzsgGFhaeJLHiOfluDnjY
# DBu2KWAndjQkm925l3XLATutghIWIoCJFYS7mFAgsBcmhkmvzn1FFUM0ls+BXBgs
# 1JPyZ6vic8g9o838Mh5gHOmwGzD7LLsHLpaEk0UoVFzNlv2g24HYtjDKQ7HzSMCy
# RhxdXnYqWJ/U7vL0+khMtWGLsIxB6aq4nZD0/2pCD7k+6Q7slPyNgLt44yOneFuy
# bR/5WcF9ttE5yXnggxxgCto9sNHtNr9FB+kbNm7lPTsFA6fUpyUSj+Z2oxOzRVpD
# MYLa2ISuubAfdfX2HX1RETcn6LU1hHH3V6qu+olxyZjSnlpkdr6Mw30VapHxFPTy
# 2TUxuNty+rR1yIibar+YRcdmstf/zpKQdeTr5obSyBvbJ8BblW9Jb1hdaSreU0v4
# 6Mp79mwV+QMZDxGFqk+av6pX3WDG9XEg9FGomsrp0es0Rz11+iLsVT9qGTlrEOla
# P470I3gwsvKmOMs1jaqYWSRAuDpnpAdfoP7YO0kT+wzh7Qttg1DO8H8+4NkI6Iwh
# SkHC3uuOW+4Dwx1ubuZUNWZncnwa6lL2IsRyP64wggd6MIIFYqADAgECAgphDpDS
# AAAAAAADMA0GCSqGSIb3DQEBCwUAMIGIMQswCQYDVQQGEwJVUzETMBEGA1UECBMK
# V2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0
# IENvcnBvcmF0aW9uMTIwMAYDVQQDEylNaWNyb3NvZnQgUm9vdCBDZXJ0aWZpY2F0
# ZSBBdXRob3JpdHkgMjAxMTAeFw0xMTA3MDgyMDU5MDlaFw0yNjA3MDgyMTA5MDla
# MH4xCzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdS
# ZWRtb25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xKDAmBgNVBAMT
# H01pY3Jvc29mdCBDb2RlIFNpZ25pbmcgUENBIDIwMTEwggIiMA0GCSqGSIb3DQEB
# AQUAA4ICDwAwggIKAoICAQCr8PpyEBwurdhuqoIQTTS68rZYIZ9CGypr6VpQqrgG
# OBoESbp/wwwe3TdrxhLYC/A4wpkGsMg51QEUMULTiQ15ZId+lGAkbK+eSZzpaF7S
# 35tTsgosw6/ZqSuuegmv15ZZymAaBelmdugyUiYSL+erCFDPs0S3XdjELgN1q2jz
# y23zOlyhFvRGuuA4ZKxuZDV4pqBjDy3TQJP4494HDdVceaVJKecNvqATd76UPe/7
# 4ytaEB9NViiienLgEjq3SV7Y7e1DkYPZe7J7hhvZPrGMXeiJT4Qa8qEvWeSQOy2u
# M1jFtz7+MtOzAz2xsq+SOH7SnYAs9U5WkSE1JcM5bmR/U7qcD60ZI4TL9LoDho33
# X/DQUr+MlIe8wCF0JV8YKLbMJyg4JZg5SjbPfLGSrhwjp6lm7GEfauEoSZ1fiOIl
# XdMhSz5SxLVXPyQD8NF6Wy/VI+NwXQ9RRnez+ADhvKwCgl/bwBWzvRvUVUvnOaEP
# 6SNJvBi4RHxF5MHDcnrgcuck379GmcXvwhxX24ON7E1JMKerjt/sW5+v/N2wZuLB
# l4F77dbtS+dJKacTKKanfWeA5opieF+yL4TXV5xcv3coKPHtbcMojyyPQDdPweGF
# RInECUzF1KVDL3SV9274eCBYLBNdYJWaPk8zhNqwiBfenk70lrC8RqBsmNLg1oiM
# CwIDAQABo4IB7TCCAekwEAYJKwYBBAGCNxUBBAMCAQAwHQYDVR0OBBYEFEhuZOVQ
# BdOCqhc3NyK1bajKdQKVMBkGCSsGAQQBgjcUAgQMHgoAUwB1AGIAQwBBMAsGA1Ud
# DwQEAwIBhjAPBgNVHRMBAf8EBTADAQH/MB8GA1UdIwQYMBaAFHItOgIxkEO5FAVO
# 4eqnxzHRI4k0MFoGA1UdHwRTMFEwT6BNoEuGSWh0dHA6Ly9jcmwubWljcm9zb2Z0
# LmNvbS9wa2kvY3JsL3Byb2R1Y3RzL01pY1Jvb0NlckF1dDIwMTFfMjAxMV8wM18y
# Mi5jcmwwXgYIKwYBBQUHAQEEUjBQME4GCCsGAQUFBzAChkJodHRwOi8vd3d3Lm1p
# Y3Jvc29mdC5jb20vcGtpL2NlcnRzL01pY1Jvb0NlckF1dDIwMTFfMjAxMV8wM18y
# Mi5jcnQwgZ8GA1UdIASBlzCBlDCBkQYJKwYBBAGCNy4DMIGDMD8GCCsGAQUFBwIB
# FjNodHRwOi8vd3d3Lm1pY3Jvc29mdC5jb20vcGtpb3BzL2RvY3MvcHJpbWFyeWNw
# cy5odG0wQAYIKwYBBQUHAgIwNB4yIB0ATABlAGcAYQBsAF8AcABvAGwAaQBjAHkA
# XwBzAHQAYQB0AGUAbQBlAG4AdAAuIB0wDQYJKoZIhvcNAQELBQADggIBAGfyhqWY
# 4FR5Gi7T2HRnIpsLlhHhY5KZQpZ90nkMkMFlXy4sPvjDctFtg/6+P+gKyju/R6mj
# 82nbY78iNaWXXWWEkH2LRlBV2AySfNIaSxzzPEKLUtCw/WvjPgcuKZvmPRul1LUd
# d5Q54ulkyUQ9eHoj8xN9ppB0g430yyYCRirCihC7pKkFDJvtaPpoLpWgKj8qa1hJ
# Yx8JaW5amJbkg/TAj/NGK978O9C9Ne9uJa7lryft0N3zDq+ZKJeYTQ49C/IIidYf
# wzIY4vDFLc5bnrRJOQrGCsLGra7lstnbFYhRRVg4MnEnGn+x9Cf43iw6IGmYslmJ
# aG5vp7d0w0AFBqYBKig+gj8TTWYLwLNN9eGPfxxvFX1Fp3blQCplo8NdUmKGwx1j
# NpeG39rz+PIWoZon4c2ll9DuXWNB41sHnIc+BncG0QaxdR8UvmFhtfDcxhsEvt9B
# xw4o7t5lL+yX9qFcltgA1qFGvVnzl6UJS0gQmYAf0AApxbGbpT9Fdx41xtKiop96
# eiL6SJUfq/tHI4D1nvi/a7dLl+LrdXga7Oo3mXkYS//WsyNodeav+vyL6wuA6mk7
# r/ww7QRMjt/fdW1jkT3RnVZOT7+AVyKheBEyIXrvQQqxP/uozKRdwaGIm1dxVk5I
# RcBCyZt2WwqASGv9eZ/BvW1taslScxMNelDNMYIVizCCFYcCAQEwgZUwfjELMAkG
# A1UEBhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQx
# HjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEoMCYGA1UEAxMfTWljcm9z
# b2Z0IENvZGUgU2lnbmluZyBQQ0EgMjAxMQITMwAAAQNeJRyZH6MeuAAAAAABAzAN
# BglghkgBZQMEAgEFAKCB3jAZBgkqhkiG9w0BCQMxDAYKKwYBBAGCNwIBBDAcBgor
# BgEEAYI3AgELMQ4wDAYKKwYBBAGCNwIBFTAvBgkqhkiG9w0BCQQxIgQgUnIo98rq
# FKzIZqU/ZbEyYdrD/hT1ao0pNv/isWw3xQcwcgYKKwYBBAGCNwIBDDFkMGKgRIBC
# AEUAeABwAGkAcgBlAGQAQwBlAHIAdABpAGYAaQBjAGEAdABlAFYAYQBsAGkAZABh
# AHQAaQBvAG4ALgBwAHMAbQAxoRqAGGh0dHA6Ly93d3cubWljcm9zb2Z0LmNvbTAN
# BgkqhkiG9w0BAQEFAASCAQBSIaf4yKXCNnelhl1D6RI6P/8Pz9XxtCfnQSEFaFN3
# xK8xNo+zSu8b2V9FBHbtcpU4uCocSE777/B/x5fuNEFHX1VhSZ2ZpAeS26ljMAiT
# IWgJ6HDEMiJormTExh2/MY204jiUm/8VIZ2SDFe/QMiiq7gUAeZcGZ+EdUKII5xF
# BudSc1IYCX38y0d8AH/o7yEU5RBKcRfggc1oJ4VyyQHzBy89uDVKRTtWCNceFNuD
# 1JNUm4hkZQd2NqqsW8ZdpvfsEurjhWHzWB3Lzt+SewkzZXWkZ9n8o0CM6m2lC99B
# NmGCg7zsUFrIF9QMDfFhxouIjzCUPg+onOYGem+eGMA3oYIS5TCCEuEGCisGAQQB
# gjcDAwExghLRMIISzQYJKoZIhvcNAQcCoIISvjCCEroCAQMxDzANBglghkgBZQME
# AgEFADCCAVEGCyqGSIb3DQEJEAEEoIIBQASCATwwggE4AgEBBgorBgEEAYRZCgMB
# MDEwDQYJYIZIAWUDBAIBBQAEIDHQFRhRWgdz7bQKBmkB7hkJMafJp+v/sLsvRu91
# j+1vAgZcmjaY1YgYEzIwMTkwNDEyMDQzODM2LjM2NlowBIACAfSggdCkgc0wgcox
# CzAJBgNVBAYTAlVTMQswCQYDVQQIEwJXQTEQMA4GA1UEBxMHUmVkbW9uZDEeMBwG
# A1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMS0wKwYDVQQLEyRNaWNyb3NvZnQg
# SXJlbGFuZCBPcGVyYXRpb25zIExpbWl0ZWQxJjAkBgNVBAsTHVRoYWxlcyBUU1Mg
# RVNOOjNCRDQtNEI4MC02OUMzMSUwIwYDVQQDExxNaWNyb3NvZnQgVGltZS1TdGFt
# cCBzZXJ2aWNloIIOPDCCBPEwggPZoAMCAQICEzMAAADaSFUCZEiaNGYAAAAAANow
# DQYJKoZIhvcNAQELBQAwfDELMAkGA1UEBhMCVVMxEzARBgNVBAgTCldhc2hpbmd0
# b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3Jh
# dGlvbjEmMCQGA1UEAxMdTWljcm9zb2Z0IFRpbWUtU3RhbXAgUENBIDIwMTAwHhcN
# MTgwODIzMjAyNjUyWhcNMTkxMTIzMjAyNjUyWjCByjELMAkGA1UEBhMCVVMxCzAJ
# BgNVBAgTAldBMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNyb3NvZnQg
# Q29ycG9yYXRpb24xLTArBgNVBAsTJE1pY3Jvc29mdCBJcmVsYW5kIE9wZXJhdGlv
# bnMgTGltaXRlZDEmMCQGA1UECxMdVGhhbGVzIFRTUyBFU046M0JENC00QjgwLTY5
# QzMxJTAjBgNVBAMTHE1pY3Jvc29mdCBUaW1lLVN0YW1wIHNlcnZpY2UwggEiMA0G
# CSqGSIb3DQEBAQUAA4IBDwAwggEKAoIBAQDHRSgt7i83GHPGTY6t76iVNqsEDDwz
# 7yk//ttihHRHMjarGDnuPUq8yu9Fju16tfZA/oKKW78ZbRd56b5Ucarcs+MCH19L
# iEbvHQLACsG8qCeaAynDGORd92jQ5GkqRgwuS5KAL7K4ExIDWc+D+Wg5iSzS+RtK
# w9dj+NXs/yWGmuYEUKhVrF7FPyS+3LRQ0+7DCO4xpmOml30GnEg38iUWaRtU3uo6
# VYtphtMUKcPeJG35snn6QyVNl7PA0Nhs2I+2W4ATxXxeaDE4/9g1DCAvvuLr3DLb
# 4ZWCCn8cpKMu4drdKQ3mAisOJ41QFPTrpdK5CDYFRkpOGDC8MqWcLv8BAgMBAAGj
# ggEbMIIBFzAdBgNVHQ4EFgQUa9zI44dHDIECzixKbAU21k4/AC4wHwYDVR0jBBgw
# FoAU1WM6XIoxkPNDe3xGG8UzaFqFbVUwVgYDVR0fBE8wTTBLoEmgR4ZFaHR0cDov
# L2NybC5taWNyb3NvZnQuY29tL3BraS9jcmwvcHJvZHVjdHMvTWljVGltU3RhUENB
# XzIwMTAtMDctMDEuY3JsMFoGCCsGAQUFBwEBBE4wTDBKBggrBgEFBQcwAoY+aHR0
# cDovL3d3dy5taWNyb3NvZnQuY29tL3BraS9jZXJ0cy9NaWNUaW1TdGFQQ0FfMjAx
# MC0wNy0wMS5jcnQwDAYDVR0TAQH/BAIwADATBgNVHSUEDDAKBggrBgEFBQcDCDAN
# BgkqhkiG9w0BAQsFAAOCAQEAS+xiwfdc8Xg0apcxdBfMGH1Vpkc1X+5DAmlIn0Lc
# kXe00GJ9KnSOstLpi9Odg7CudUqg/vCdleXLfCnEmkTqaygxHGWLhyD3u0J6qhVP
# pLqOMKJdJ1SSTVQeeBtfuM6DBGBdlnEv9YOiU6k7R9kmPYxfW+lwJ7bSdKsafNH5
# a7nb4K9hghLxdVpSQVbvMeUV00jHXRADn2FAr53Uf+Qdq84e3pLg+av6Im7rtywJ
# RRVF9ULl1UqudjC5XHmrgBAasFs+IugpKZSppUXy+QuEM0yl6+ct9KTso4oRk/cq
# btuTX6JuFM470AtX9FcPZTYESI/Qwi6Cjb3bElz3/XRSIDCCBnEwggRZoAMCAQIC
# CmEJgSoAAAAAAAIwDQYJKoZIhvcNAQELBQAwgYgxCzAJBgNVBAYTAlVTMRMwEQYD
# VQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNy
# b3NvZnQgQ29ycG9yYXRpb24xMjAwBgNVBAMTKU1pY3Jvc29mdCBSb290IENlcnRp
# ZmljYXRlIEF1dGhvcml0eSAyMDEwMB4XDTEwMDcwMTIxMzY1NVoXDTI1MDcwMTIx
# NDY1NVowfDELMAkGA1UEBhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAOBgNV
# BAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEmMCQG
# A1UEAxMdTWljcm9zb2Z0IFRpbWUtU3RhbXAgUENBIDIwMTAwggEiMA0GCSqGSIb3
# DQEBAQUAA4IBDwAwggEKAoIBAQCpHQ28dxGKOiDs/BOX9fp/aZRrdFQQ1aUKAIKF
# ++18aEssX8XD5WHCdrc+Zitb8BVTJwQxH0EbGpUdzgkTjnxhMFmxMEQP8WCIhFRD
# DNdNuDgIs0Ldk6zWczBXJoKjRQ3Q6vVHgc2/JGAyWGBG8lhHhjKEHnRhZ5FfgVSx
# z5NMksHEpl3RYRNuKMYa+YaAu99h/EbBJx0kZxJyGiGKr0tkiVBisV39dx898Fd1
# rL2KQk1AUdEPnAY+Z3/1ZsADlkR+79BL/W7lmsqxqPJ6Kgox8NpOBpG2iAg16Hgc
# sOmZzTznL0S6p/TcZL2kAcEgCZN4zfy8wMlEXV4WnAEFTyJNAgMBAAGjggHmMIIB
# 4jAQBgkrBgEEAYI3FQEEAwIBADAdBgNVHQ4EFgQU1WM6XIoxkPNDe3xGG8UzaFqF
# bVUwGQYJKwYBBAGCNxQCBAweCgBTAHUAYgBDAEEwCwYDVR0PBAQDAgGGMA8GA1Ud
# EwEB/wQFMAMBAf8wHwYDVR0jBBgwFoAU1fZWy4/oolxiaNE9lJBb186aGMQwVgYD
# VR0fBE8wTTBLoEmgR4ZFaHR0cDovL2NybC5taWNyb3NvZnQuY29tL3BraS9jcmwv
# cHJvZHVjdHMvTWljUm9vQ2VyQXV0XzIwMTAtMDYtMjMuY3JsMFoGCCsGAQUFBwEB
# BE4wTDBKBggrBgEFBQcwAoY+aHR0cDovL3d3dy5taWNyb3NvZnQuY29tL3BraS9j
# ZXJ0cy9NaWNSb29DZXJBdXRfMjAxMC0wNi0yMy5jcnQwgaAGA1UdIAEB/wSBlTCB
# kjCBjwYJKwYBBAGCNy4DMIGBMD0GCCsGAQUFBwIBFjFodHRwOi8vd3d3Lm1pY3Jv
# c29mdC5jb20vUEtJL2RvY3MvQ1BTL2RlZmF1bHQuaHRtMEAGCCsGAQUFBwICMDQe
# MiAdAEwAZQBnAGEAbABfAFAAbwBsAGkAYwB5AF8AUwB0AGEAdABlAG0AZQBuAHQA
# LiAdMA0GCSqGSIb3DQEBCwUAA4ICAQAH5ohRDeLG4Jg/gXEDPZ2joSFvs+umzPUx
# vs8F4qn++ldtGTCzwsVmyWrf9efweL3HqJ4l4/m87WtUVwgrUYJEEvu5U4zM9GAS
# inbMQEBBm9xcF/9c+V4XNZgkVkt070IQyK+/f8Z/8jd9Wj8c8pl5SpFSAK84Dxf1
# L3mBZdmptWvkx872ynoAb0swRCQiPM/tA6WWj1kpvLb9BOFwnzJKJ/1Vry/+tuWO
# M7tiX5rbV0Dp8c6ZZpCM/2pif93FSguRJuI57BlKcWOdeyFtw5yjojz6f32WapB4
# pm3S4Zz5Hfw42JT0xqUKloakvZ4argRCg7i1gJsiOCC1JeVk7Pf0v35jWSUPei45
# V3aicaoGig+JFrphpxHLmtgOR5qAxdDNp9DvfYPw4TtxCd9ddJgiCGHasFAeb73x
# 4QDf5zEHpJM692VHeOj4qEir995yfmFrb3epgcunCaw5u+zGy9iCtHLNHfS4hQEe
# gPsbiSpUObJb2sgNVZl6h3M7COaYLeqN4DMuEin1wC9UJyH3yKxO2ii4sanblrKn
# QqLJzxlBTeCG+SqaoxFmMNO7dDJL32N79ZmKLxvHIa9Zta7cRDyXUHHXodLFVeNp
# 3lfB0d4wwP3M5k37Db9dT+mdHhk4L7zPWAUu7w2gUDXa7wknHNWzfjUeCLraNtvT
# X4/edIhJEqGCAs4wggI3AgEBMIH4oYHQpIHNMIHKMQswCQYDVQQGEwJVUzELMAkG
# A1UECBMCV0ExEDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29mdCBD
# b3Jwb3JhdGlvbjEtMCsGA1UECxMkTWljcm9zb2Z0IElyZWxhbmQgT3BlcmF0aW9u
# cyBMaW1pdGVkMSYwJAYDVQQLEx1UaGFsZXMgVFNTIEVTTjozQkQ0LTRCODAtNjlD
# MzElMCMGA1UEAxMcTWljcm9zb2Z0IFRpbWUtU3RhbXAgc2VydmljZaIjCgEBMAcG
# BSsOAwIaAxUAdEzTTEotoQSpGzp52CkNu4LmhZKggYMwgYCkfjB8MQswCQYDVQQG
# EwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwG
# A1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMSYwJAYDVQQDEx1NaWNyb3NvZnQg
# VGltZS1TdGFtcCBQQ0EgMjAxMDANBgkqhkiG9w0BAQUFAAIFAOBadXowIhgPMjAx
# OTA0MTIxMDI0NThaGA8yMDE5MDQxMzEwMjQ1OFowdzA9BgorBgEEAYRZCgQBMS8w
# LTAKAgUA4Fp1egIBADAKAgEAAgIVgQIB/zAHAgEAAgIRYjAKAgUA4FvG+gIBADA2
# BgorBgEEAYRZCgQCMSgwJjAMBgorBgEEAYRZCgMCoAowCAIBAAIDB6EgoQowCAIB
# AAIDAYagMA0GCSqGSIb3DQEBBQUAA4GBADKfbY22lFqGsIvtSxveSxROkXaC5fJj
# 6cDRB8LtTznunD1fOQgw/NCVVqvAzQDM79YNpdJKm8J19g8UJa+fG+AlT6FDUlSM
# 4QByfrvWnDnHyRyn5C2z5rZ9PvnX8M2KxOp75B/045Kablgjjs8iqIrliu7Itmzm
# Qc+tDL1Z2JAoMYIDDTCCAwkCAQEwgZMwfDELMAkGA1UEBhMCVVMxEzARBgNVBAgT
# Cldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29m
# dCBDb3Jwb3JhdGlvbjEmMCQGA1UEAxMdTWljcm9zb2Z0IFRpbWUtU3RhbXAgUENB
# IDIwMTACEzMAAADaSFUCZEiaNGYAAAAAANowDQYJYIZIAWUDBAIBBQCgggFKMBoG
# CSqGSIb3DQEJAzENBgsqhkiG9w0BCRABBDAvBgkqhkiG9w0BCQQxIgQgBHniO9Rh
# GmPapbMAJzqeHURIOLqHn1rshRBTrpOY6QMwgfoGCyqGSIb3DQEJEAIvMYHqMIHn
# MIHkMIG9BCCKzbtbvNqlg5eLKt6EjGbjK5shpVYd9K2O+2sNaxUxEzCBmDCBgKR+
# MHwxCzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdS
# ZWRtb25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xJjAkBgNVBAMT
# HU1pY3Jvc29mdCBUaW1lLVN0YW1wIFBDQSAyMDEwAhMzAAAA2khVAmRImjRmAAAA
# AADaMCIEIIrthahschDWJbFkP+b0PvS6A5yAF4Uf0d5YigIEZ42mMA0GCSqGSIb3
# DQEBCwUABIIBAKHXNc19kmGYkVJzM63MtrzKDeqwidhJoRCGNcEQVnz4TFEKWWyT
# AKSmVNqTvSnmkXoV+wM2z7m7my7ekEPlN6ITi9AO6tQKAPBR9oCg2JGNnoYrKQ6u
# +TZKh2z4YE0uDouZVlLqefuLh9HQSKL6tg8Kh2gHDfde/xJK+TApLrf2ieePAg7C
# VvWgBzhZ8skLpRddYqa2EVqhx5NgMa5EVIPsY+AbmkFTGF4wOXUVtD3PVLj4osIo
# +tFTA9xjTNft2Y6wCB1sz1cJpz71rfp+mEYSCaVV9V1LslJLSmhuDP1pITLpDOZG
# KYsx36ZVEHjJ6mcBUTPL+lnWQJupbk7YQoo=
# SIG # End signature block
