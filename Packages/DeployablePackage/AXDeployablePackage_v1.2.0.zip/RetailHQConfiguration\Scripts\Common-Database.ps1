<#
SAMPLE CODE NOTICE

THIS SAMPLE CODE IS MADE AVAILABLE AS IS.  MICROSOFT MAKES NO WARRANTIES, WHETHER EXPRESS OR IMPLIED,
OF FITNESS FOR A PARTICULAR PURPOSE, OF ACCURACY OR COMPLETENESS OF RESPONSES, OF RESULTS, OR CONDITIONS OF MERCHANTABILITY.
THE ENTIRE RISK OF THE USE OR THE RESULTS FROM THE USE OF THIS SAMPLE CODE REMAINS WITH THE USER.
NO TECHNICAL SUPPORT IS PROVIDED.  YOU MAY NOT DISTRIBUTE THIS CODE UNLESS YOU HAVE A LICENSE AGREEMENT WITH MICROSOFT THAT ALLOWS YOU TO DO SO.
#>

$ErrorActionPreference = "Stop"

<#
.SYNOPSIS
Create user groups and assign database roles.

.DESCRIPTION
Creates the user group on server $serverName if not existing already.
Then creates a login in the SQL SERVER $serverName, for the user, if not existing already.
Then created a database user for the user on $databaseName.
Then associated the database user with the SQL roles defined in the user group mapping object.

.PARAMETER databaseName
The name of the database to be deployed.

.PARAMETER serverName
The name of the server where Windows users should be created. Usually the same server where the database is hosted.

.PARAMETER connectionString
A connection string to the database. It may or may not specify an initial catalog or database.

.PARAMETER groupMappings
An array of groupMapping. A groupMapping is defined with the following properties:
	GroupName				(required)	- the same of the user group, possibly containing a domain (e.g. 'domain\group').
	MappedSqlRoleName		(optinal)	- the SQL role the user group should be mapped to.
#>
function Create-UserGroups()
{
	param(
		[Parameter(Mandatory=$true)]
		[ValidateNotNullOrEmpty()]
		[string]$databaseName,

		[Parameter(Mandatory=$true)]
		[ValidateNotNullOrEmpty()]
		[string]$serverName,

		[Parameter(Mandatory=$true)]
		[ValidateNotNullOrEmpty()]
		[string]$connectionString,

		[Parameter(Mandatory=$true)]
		[ValidateNotNull()]
		[array]$groupMappings
	);

	$database = New-Object Microsoft.Dynamics365.Commerce.Tools.DacValidator.Database -ArgumentList $connectionString, $databaseName

	try
	{
		foreach($group in $groupMappings)
		{
			$groupName = $group.GroupName
			if ($groupName)
			{
				Log-TimedMessage "$databaseName - creating windows group [$groupName] on $serverName, if it doesn't exist yet."

				$groupName = CreateWindowsGroup -windowsLoginGroupName $group.GroupName -serverName $serverName
				$groupName = GetExplicitWindowsUserName -userName $groupName

				$sqlRole = $group.MappedSqlRoleName
				$addToRoleCommand = if ($sqlRole) { "EXEC sp_addrolemember '$sqlRole', '$groupName';" } else { [String]::Empty }

				Log-TimedMessage "$databaseName - creating login for [$groupName] on database '$databaseName' and it will be associated to role '$sqlRole' (if empty, then no role association)."

				$createSqlUserCommand = @"
					IF NOT EXISTS (SELECT * FROM [MASTER].[DBO].[SYSLOGINS] WHERE NAME = '$groupName')
					BEGIN
						CREATE LOGIN [$groupName] FROM WINDOWS WITH DEFAULT_DATABASE = [MASTER];
					END;
					GO
					IF NOT EXISTS (SELECT * FROM SYS.SYSUSERS WHERE NAME = '$groupName')
					BEGIN
						CREATE USER [$groupName] FOR LOGIN [$groupName];
					END;
					GO
					$addToRoleCommand
"@

				$database.ExecuteSqlText($createSqlUserCommand)
			}
			else
			{
				Log-TimedWarning "$databaseName - Create-UserGroups - an entry in the 'groupMappings' array does not define 'GroupName'. Group creation will be skiped for this entry. This may cause certain users to not be able to access the database."
			}
		}
	}
	finally
	{
		if ($database)
		{
			$database.Dispose()
		}
	}
}

<#
.SYNOPSIS
Adds roles to users required for Retail cloud deployments.

.PARAMETER Server
The sql server address/name.

.PARAMETER DatabaseName
The name of the collocated AX/CHANNEL database.

.PARAMETER Credentials
The credentials for accessing the database.
#>
function Set-RolesForCloudRetailChannelDatabase(
    $Server = (Throw 'server parameter required'),
    $DatabaseName = (Throw 'database parameter required'),
    [System.Management.Automation.PSCredential]$Credentials = (Throw 'Credential parameter required'))
{

    $connectionString = Get-ConnectionString -serverName $Server `
                                    -databaseName $DatabaseName `
                                    -credential $Credentials

    $database = New-Object Microsoft.Dynamics365.Commerce.Tools.DacValidator.Database -ArgumentList $connectionString, $DatabaseName

    $retailDbRolesToUserMapping = @{'DataSyncUsersRole' = 'axretaildatasyncuser';
                                    'PublishersRole' = 'axretaildatasyncuser';
                                    'UsersRole' = 'axretailruntimeuser';
                                    'ReportUsersRole' = 'axretailruntimeuser';
                                    'DeployExtensibilityRole' = 'axdeployextuser';
                                    }

    foreach($role in $retailDbRolesToUserMapping.Keys)
    {
        $userAssociatedToCurrentRole = $retailDbRolesToUserMapping[$role]
        $queryToCheckRole = "SELECT [NAME] FROM sys.database_principals WHERE [TYPE] = 'R' and [NAME] = '$role' "

        if(!$database.ExecuteScalar($queryToCheckRole))
        {
            Log-TimedWarning "Role $role doesn't exist in database. Please check the database deployment log for any errors while creating the role."
            continue
        }
        else
        {
            Write-Log "Role $role already exists in the database."
        }

        $queryToCheckUser = "SELECT * FROM dbo.sysusers WHERE name = '$userAssociatedToCurrentRole' AND issqluser = 1"

        if(!$database.ExecuteScalar($queryToCheckUser))
        {
            Log-TimedWarning "User $userAssociatedToCurrentRole doesn't exist in database. Please check the database deployment log for any errors while creating the user."
            continue
        }
        else
        {
            Write-Log "User $userAssociatedToCurrentRole already exists in the database."
        }


        $queryToCheckIfRoleExistsForUser = "select IS_ROLEMEMBER('$role', '$userAssociatedToCurrentRole')"

        if($database.ExecuteScalar($queryToCheckIfRoleExistsForUser))
        {
            Write-Log "User $userAssociatedToCurrentRole already has the role $role"
        }
        else
        {
            Write-Log "User $userAssociatedToCurrentRole does not have the role $role."
            $queryToAddUserToRole = "EXEC sp_addrolemember '$role', '$userAssociatedToCurrentRole'"
            Write-Log ("Associating role $role to user $userAssociatedToCurrentRole")
            $database.ExecuteSqlText($queryToAddUserToRole)
        }
    }
}

<#
.SYNOPSIS
Alters an existing database and set the required parameters.

.PARAMETER databaseName
The name of the database to be deployed.

.PARAMETER connectionString
A connection string to the database. It may or may not specify an initial catalog or database.

.PARAMETER maxSqlMemoryLimitRatio
A value between 0 and 1 indicating the percentage of system memorry SQL SERVER can use.

.PARAMETER databaseFileMinSizeMB
A value in MB for the minimum size of the all database files.

.PARAMETER databaseFileGrowthPercentage
A value between 0 and 100 indicating the percentage of databaseFileMinSizeMB to be used for all database file growth.

.PARAMETER databaseAutoClose
A $true or $false value indicating how to set AUTO_CLOSE database parameter. A $null value will not change the parameter.
#>
function Alter-DatabaseParameters
{
	param(
		[Parameter(Mandatory=$true)]
		[ValidateNotNullOrEmpty()]
		[string]$databaseName,

		[Parameter(Mandatory=$true)]
		[ValidateNotNullOrEmpty()]
		[string]$connectionString,

		[Parameter(Mandatory=$false)]
		[Nullable[float]]$maxSqlMemoryLimitRatio,

		[Parameter(Mandatory=$false)]
		[Nullable[long]]$databaseFileMinSizeMB,

		[Parameter(Mandatory=$false)]
		[Nullable[float]]$databaseFileGrowthPercentage,

		[Parameter(Mandatory=$false)]
		[Nullable[bool]]$databaseAutoClose
	);

	# we need to connect to master as we cannot change some of these things while connected directly to the database
	$database = New-Object Microsoft.Dynamics365.Commerce.Tools.DacValidator.Database -ArgumentList $connectionString, 'master'

	try
	{
		# sets sql max memory
		if ($maxSqlMemoryLimitRatio -and $maxSqlMemoryLimitRatio -gt 0 -and $maxSqlMemoryLimitRatio -lt 1)
		{
			Log-TimedMessage "$databaseName - Database parameters - setting MAX SQL memory to $(100*$maxSqlMemoryLimitRatio)% of system memory"

			$cmd = @"
				sp_configure 'show advanced options', 1;
				GO

				RECONFIGURE;
				GO

				DECLARE @MAXMEMORY BIGINT = (SELECT MAX(MEM) FROM
				(
					SELECT CAST(TOTAL_PHYSICAL_MEMORY_KB * 0.5 AS BIGINT) MEM FROM SYS.DM_OS_SYS_MEMORY
					UNION
					SELECT 131072 MEM -- min memory limit 128MB
				) M)
				exec sp_configure 'max server memory', @MAXMEMORY;
				GO

				RECONFIGURE;
"@
			$database.ExecuteSqlText($cmd)
		}

		if ($databaseFileMinSizeMB -and $databaseFileMinSizeMB -gt 0)
		{
			Log-TimedMessage "$databaseName - Database parameters - increasing all database files' size to $databaseFileMinSizeMB MB"
			$cmd = @"
			SELECT [NAME] FROM SYS.MASTER_FILES WHERE
				DATABASE_ID = DB_ID('$databaseName')
				AND (SIZE * 8 / 1024) < $databaseFileMinSizeMB;
"@
			$filenames = $database.ExecuteScalarCollection($cmd)
			foreach ($filename in $filenames)
			{
				$database.Execute("ALTER DATABASE [$databaseName] MODIFY FILE (NAME = '$filename', SIZE = $($databaseFileMinSizeMB)MB)");
			}
		}

		if ($databaseFileGrowthPercentage -and $databaseFileGrowthPercentage -gt 0 -and $databaseFileGrowthPercentage -le 100)
		{
			Log-TimedMessage "$databaseName - Database parameters - setting all database files' size growth to $($databaseFileGrowthPercentage)%"

			$cmd = @"
			SELECT [NAME] FROM SYS.MASTER_FILES WHERE
				DATABASE_ID = DB_ID('$databaseName');
"@
			$filenames = $database.ExecuteScalarCollection($cmd)
			foreach ($filename in $filenames)
			{
				$database.Execute("ALTER DATABASE [$databaseName] MODIFY FILE (NAME = '$filename', FILEGROWTH = $($databaseFileGrowthPercentage)%)");
			}
		}

		# Need to do null check to see whether value was set at all.
		if($databaseAutoClose -ne $null)
		{
			Log-TimedMessage "$databaseName - Database parameters - setting AUTO_CLOSE to $databaseAutoClose"

			$database.Execute("ALTER DATABASE [$databaseName] SET AUTO_CLOSE $(if($databaseAutoClose) { 'ON' } else { 'OFF' })");
		}
	}
	finally
	{
		if ($database)
		{
			$database.Dispose()
		}
	}
}

<#
.SYNOPSIS
Gets a connection string from the database configuration object.

.PARAMETER databaseName
The name of the database.

.PARAMETER serverName
The name of the server to connect to.

.PARAMETER instanceName
Optinal name of the database server instnace to connect to.

.PARAMETER credential
Optional credential to access the database. If not provided, integrated security is assumed.
#>
function Get-ConnectionString {
	param(
		[Parameter(Mandatory=$true)]
		[ValidateNotNull()][string]$databaseName,

		[Parameter(Mandatory=$true)]
		[ValidateNotNull()][string]$serverName,

		[Parameter(Mandatory=$false)]
		[ValidateNotNull()][string]$instanceName,

		[Parameter(Mandatory=$false)]
		[System.Management.Automation.PSCredential]$credential
	)
	$server = $serverName
	if ($instanceName)
	{
		# some times instance name contains the server name as well
		$instanceNamePart = $instanceName.split('\', [System.StringSplitOptions]::RemoveEmptyEntries)[1]

		if ($instanceNamePart)
		{
			$instanceName = $instanceNamePart
		}

		# if instance name is same as server name, ignore it, callers may duplicated server name on instance name
		if ($instanceName -ne $server)
		{
			$server = "$server\$instanceName"
		}
	}

	# use a builder for connection string for proper escaping
	$builder = New-Object System.Data.SqlClient.SqlConnectionStringBuilder

	# pooling is disable so connections don't linger
	$builder.Pooling = $false
	$builder["Server"] = $server
	$builder["Connect Timeout"] = 30
	$builder["Application Name"] = "D365RetailDeployment"

	if ($credential)
	{
		$builder["User ID"] = $credential.UserName
		$builder.Password = $credential.GetNetworkCredential().password
	}
	else
	{
		$builder["Integrated Security"] = $true
	}

	$connectionString = $builder.ToString()

	$builderForLog = New-Object System.Data.SqlClient.SqlConnectionStringBuilder -ArgumentList $connectionString
	$builderForLog.Password = $null
	Log-TimedMessage "Created connection string (password is omitted): $builderForLog";

	$connectionString
}

<#
.SYNOPSIS
Deploys customization files against a database.

.DESCRIPTION
All files under 'customizationsBasePath' with extension '.sql' will be considered customization scripts and will be run against the database.
Prior executing each script, the script is checked against the database by file name, to make sure only new customization scripts are executed.

.PARAMETER databaseName
The name of the database to deploy customizations against.

.PARAMETER connectionString
A connection string to the database. It may or may not specify an initial catalog or database.

.PARAMETER customizationsBasePath
Path to the folder containing customization .sql scripts.

.PARAMETER logFolder
A path to a folder were all results will be saved to.
If the path doesn't exist, this script will try to create it.
#>
function Deploy-Customizations
{
	param(
		[Parameter(Mandatory=$true)]
		[ValidateNotNullOrEmpty()]
		[string]$databaseName,

		[Parameter(Mandatory=$true)]
		[ValidateNotNullOrEmpty()]
		[string]$connectionString,

		[Parameter(Mandatory=$false)]
		[string]$customizationsBasePath,

		[Parameter(Mandatory=$true)]
		[ValidateNotNullOrEmpty()]
		[string]$logFolder
	)

	Log-TimedMessage "$databaseName - Preparing to apply customizations to database"

	if (-not $customizationsBasePath -or -not (Test-Path $customizationsBasePath))
	{
		Log-TimedWarning "$databaseName - The base folder for customization scripts: '$customizationsBasePath' does not exist. No customizations will be applied."
		return
	}

	if (-not (Test-Path $logFolder))
	{
		Log-TimedMessage "$databaseName - log folder $logFolder doesn't exist. It will be created now."
		New-Item -ItemType Directory -Path $logFolder -Force | Out-Null
	}

	$logBasePath = Resolve-Path $logFolder

	if (-not (Test-Path $logBasePath -pathType container))
	{
		throw "$databaseName -  The log folder path provided: '$logBasePath' is not a directory."
	}

	$databaseLogFilepath = Join-Path $logBasePath "CustomizationDatabaseLogs.log"
	Log-TimedMessage "$databaseName - database statement execution logs will be available at: $databaseLogFilepath"

	$customizationsBasePath = Resolve-Path $customizationsBasePath
	Log-TimedMessage "$databaseName - Looking for customizations sql files recursively at $customizationsBasePath"

    $scriptFiles = Get-ChildItem -Path $customizationsBasePath -Recurse -Filter "*.sql" | Sort-Object Name
	Log-TimedMessage "$databaseName - Found $($scriptFiles.count) customization SQL script files."

	if (-not $scriptFiles)
	{
		Log-TimedMessage "$databaseName - No customizations found. Nothing to do."
		return
	}

	Log-TimedMessage "$databaseName - Connecting to database to obtain previously applied customization files."
	$database = New-Object Microsoft.Dynamics365.Commerce.Tools.DacValidator.Database -ArgumentList $connectionString, $databaseName, $databaseLogFilepath

	try
	{
		# This table must exist becase we just deployed the database
		$appliedCustomizationFileNames = $database.ExecuteScalarCollection("SELECT FILENAME FROM [crt].[RETAILUPGRADEHISTORY] WHERE UPGRADETYPE='CUSTOM'")
		Log-TimedMessage "$databaseName - Found $($appliedCustomizationFileNames.count) previously applied customizations."

		foreach ($scriptFile in $scriptFiles)
		{
			$filename = $scriptFile.Name
			$filepath = $scriptFile.FullName

			# only run customizations not applied before
			if ($appliedCustomizationFileNames -notcontains $filename)
			{
				Log-TimedMessage "$databaseName - Reading customization file: $filename ($filepath)"
				$scriptContents = Get-Content -Raw $filepath

				try
				{
					Log-TimedMessage "$databaseName - Applying customization file: $filename"
					$database.ExecuteSqlText($scriptContents)
				}
				catch
				{
					Log-Error "An error occurred when running the customization script $filepath against $databaseName. $_"
					throw
				}

				# Update record table right away so we don't rerun scripts in case of failure
				$database.Execute("INSERT [crt].[RETAILUPGRADEHISTORY] (UpgradeType, FilePath, FileName, Build) VALUES ('CUSTOM', '$filepath', '$filename', (SELECT TOP 1 BUILD FROM CRT.RETAILUPGRADEHISTORY WHERE UPGRADETYPE = 'RETAIL' ORDER BY ID DESC))")
				Log-TimedMessage "$databaseName - Customization file $filename applied successfully"

				$appliedCustomizationFileNames += $filename
			}
		}
	}
	finally
	{
		if ($database)
		{
			$database.Dispose()
		}
	}

	Log-TimedMessage "$databaseName - Finished applying customization scripts"
}

<#
.SYNOPSIS
Deploys the database, after validations.

.DESCRIPTION
A new database is created if it doesn't current exist. An existing database is upgraded to the version associated with the database packaged provided.

.PARAMETER databaseName
The name of the database to be deployed.

.PARAMETER connectionString
A connection string to the database. It may or may not specify an initial catalog or database.

.PARAMETER deployableBasePath
Path to the folder containing the DACPAC and other database deployment related artifacts.
The following files are expected to exist under that path:
	CommerceRuntimeScripts.dacpac (required) - the package to be deployed
	DeploymentPublishProfile.xml  (required) - an xml file with deployment configurations
	DeploymentAllowedDrops.txt	  (optional) - a EOL-separated list of database artifacts allowed to be dropped
	DeploymentAllowedMessages.txt (optional) - a EOL-separated list of allowed database deployment warning messages

.PARAMETER logFolder
A path to a folder were all results will be saved to.
If the path doesn't exist, this script will try to create it.

.EXAMPLE
Deploy-Database -databaseName "ChannelDb" -connectionString "Server=localhost;Integrated Security=true;" -logFolder "C:\dbDeployables"
#>
function Deploy-Database
{
	param(
		[Parameter(Mandatory=$true)]
		[ValidateNotNullOrEmpty()]
		[string]$databaseName,

		[Parameter(Mandatory=$true)]
		[ValidateNotNullOrEmpty()]
		[string]$connectionString,

		[Parameter(Mandatory=$true)]
		[ValidateNotNullOrEmpty()]
		[string]$deployableBasePath,

		[Parameter(Mandatory=$true)]
		[ValidateNotNullOrEmpty()]
		[string]$logFolder
	);

	Log-TimedMessage "$databaseName - Preparing to deploy"

	# Pre-flight checks
	if (-not (Test-Path $deployableBasePath))
	{
		Log-TimedWarning "$databaseName - $deployableBasePath does not exist. Deployment of Microsoft artifacts will be skipped"
		return
	}

	$basePath = Resolve-Path $deployableBasePath

	# this is the package we will be deploying
	$packageFilepath =          Join-Path $basePath 'CommerceRuntimeScripts.dacpac'

	if (-not (Test-Path $packageFilepath))
	{
		Log-TimedWarning "$databaseName - $packageFilepath does not exist. Deployment of Microsoft artifacts will be skipped"
		return
	}

    # Deployment options/profile used to be shipped with the product, but now we ship it with the deployment bits
    # To support legacy environments, we still look at the product folder to see if it is there, in case we don't find it
    # along with the deployment bits
    $deploymentOptionsFileName = 'DeploymentPublishProfile.xml'
    $deployOptionsFilepath = Join-Path $PSScriptRoot $deploymentOptionsFileName

	if (-not (Test-Path $deployOptionsFilepath))
    {
        Log-TimedWarning "$databaseName - $deployOptionsFilepath does not exist under deployment scripts folder. Using fallback location."

        $deployOptionsFilepath = Join-Path $basePath $deploymentOptionsFileName

        if (-not (Test-Path $deployOptionsFilepath))
        {
            Log-TimedWarning "$databaseName - $deployOptionsFilepath does not exist under product data folder."
            throw "No deployment profile was found. Please make sure that the deployment profile options file exists."
        }
    }

	if (-not (Test-Path $logFolder))
	{
		Log-TimedMessage "$databaseName - log folder $logFolder doesn't exist. It will be created now."
		New-Item -ItemType Directory -Path $logFolder -Force | Out-Null
	}

	$logBasePath = Resolve-Path $logFolder

	if (-not (Test-Path $logBasePath -pathType container))
	{
		throw "$databaseName - The log folder path provided: '$logBasePath' is not a directory."
	}

	$databaseLogFilepath = Join-Path $logBasePath "DatabaseLogs.log"
	Log-TimedMessage "$databaseName - database statement execution logs will be available at: $databaseLogFilepath"

	Log-TimedMessage "$databaseName - Loading publish options from: $deployOptionsFilepath"
	$publishOptions = [Microsoft.Dynamics365.Commerce.Tools.DacValidator.DacServicesFacade]::LoadDeployOptions($deployOptionsFilepath)

	Log-TimedMessage "$databaseName - Loading the following DAC package to be used for this deployment: $packageFilepath"

	# this is the dacpac that has the upgrade we want to install
	$targetDacpac = [Microsoft.Dynamics365.Commerce.Tools.DacValidator.DacServicesFacade]::LoadDacpac($packageFilepath)
	$currentDacpac = $null

	$database = $null
	$executionSuccessfull = $true
	$newDatabase = $true

	# 30 minutes - each SQL batch will timeout this many minutes when indexes are being applied or tables rebuilt
	# Ideally we should not have long running queries during deployment - however it is best to wait than fail deployment halfway
	$defaultSqlTimeoutSeconds = 1800

	try
	{
		# Check that database exists, otherwise creates a new one
		Log-TimedMessage "$databaseName - check that database exists."

		# first, try to open a connection directly to the database
		# in SQLAzure, we may not have access to master database, so we try to connect to the database directly and check its name
		$database = New-Object Microsoft.Dynamics365.Commerce.Tools.DacValidator.Database -ArgumentList $connectionString, $databaseName, $databaseLogFilepath
		$database.Timeout = $defaultSqlTimeoutSeconds

		try
		{
			$newDatabase = $database.ExecuteScalar("SELECT DB_NAME()") -ne $databaseName
		}
		catch
		{
			Log-TimedMessage "$databaseName - it appears this database doesn't exist."
		}
		finally
		{
			if ($database)
			{
				$database.Dispose()
			}
		}

		if ($newDatabase)
		{
			Log-TimedMessage "$databaseName - database doesn't exist. One will be created now."
			Log-TimedMessage "$databaseName - connecting to master database to issue CREATE DATABASE statement."
			$database = New-Object Microsoft.Dynamics365.Commerce.Tools.DacValidator.Database -ArgumentList $connectionString, '', $databaseLogFilepath
			$database.Timeout = $defaultSqlTimeoutSeconds
			$database.Execute("CREATE DATABASE [$databaseName]")
			# disconnects from master DB
			$database.Dispose();
			Log-TimedMessage "$databaseName - database created."
		}
		else
		{
			Log-TimedMessage "$databaseName - database exists."
		}

		Log-TimedMessage "$databaseName - checking connection against database."
		# makes sure we are connected to the actual database
		$database = New-Object Microsoft.Dynamics365.Commerce.Tools.DacValidator.Database -ArgumentList $connectionString, $databaseName, $databaseLogFilepath
		$database.Timeout = $defaultSqlTimeoutSeconds
		# make a dummy call to make sure we are connected
		$database.Execute("SELECT 1")

		# Check if canary view exists (if it does, we will fail deployment to allow for manual intervention)
		Log-TimedMessage "$databaseName - quering for canary view __RETAIL_CANARY before proceeding. If it exists, we will fail deployment. This can be used to provide manual intervention prior deployment. Run this on the database to create it: CREATE VIEW __RETAIL_CANARY AS SELECT 1 A;"
		$retailCanaryViewExists = $database.ExecuteScalar("SELECT OBJECT_ID('__RETAIL_CANARY')") -ne $null

		if ($retailCanaryViewExists)
		{
			Log-TimedMessage "$databaseName - canary view __RETAIL_CANARY exists."
			throw "$databaseName - canary view __RETAIL_CANARY exists. This means manual intervention was requested. Database deployment will fail. If this was not intended, remove the view from the database."
		}
		else
		{
			Log-TimedMessage "$databaseName - canary view __RETAIL_CANARY not found. Continuing normally."
		}

		# Get current version from database
		Log-TimedMessage "$databaseName - quering current database version against [AX.DBVERSION]."

		# AX.DBVERSION contains DB version. If not set, assume a new DB
		$axDbVersionTableExists = $database.ExecuteScalar("SELECT OBJECT_ID('AX.DBVERSION')") -ne $null

		if ($axDbVersionTableExists)
		{
			$currentDbVersion = [Version]$database.ExecuteScalar("SELECT TOP 1 VERSIONSTRING FROM [ax].[DBVERSION] WHERE VERSIONTYPE='databaseVersion'")
		}

		if (-not $currentDbVersion)
		{
			Log-TimedMessage "$databaseName - no version found. Assuming new database deployment."
			$currentDbVersion = [Version]'0.0.0.0'
		}

		# this is the version we will upgrade to
		[Version]$targetVersion = $targetDacpac.Version

		Log-TimedMessage "$databaseName - current DB version is $currentDbVersion and upgrade package version is $targetVersion."

		# check if DB is up to date
		if ($currentDbVersion -lt $targetVersion)
		{
			# Get src pkg from DB, if doesn't exist, fallback do DACPACs on the filesystem, if not exists, fail as we cannot do anything else
			Log-TimedMessage "$databaseName - retrieving current binary package from database using CRT.RETAILUPGRADEHISTORY."

			$databaseSupportsStoringDacpac = $database.ExecuteScalar("SELECT COL_LENGTH('[CRT].[RETAILUPGRADEHISTORY]', 'DACPACFILE')") -ne $null
			[byte[]]$currentDacpacBytes = $null

			if ($databaseSupportsStoringDacpac)
			{
				$currentDacpacBytes = [byte[]]$database.ExecuteScalar("SELECT TOP 1 DACPACFILE FROM CRT.RETAILUPGRADEHISTORY WHERE UPGRADETYPE = 'RETAIL' ORDER BY ID DESC")
			}
			else
			{
				Log-TimedMessage "$databaseName - database does not support storing/retrieving DACPACs. CRT.RETAILUPGRADEHISTORY doesn't exist or DACPACFILE column is not present."
			}

			if ($currentDacpacBytes)
			{
				Log-TimedMessage "$databaseName - current binary package found in the database."

				try
				{
					$currentDacpac = [Microsoft.Dynamics365.Commerce.Tools.DacValidator.InMemoryPackage]::LoadPackage($currentDacpacBytes)
				}
				catch
				{
					# legacy versions used to store the DACPAC bytes converted to ASCII characters, separated by spaces
					Log-TimedMessage "$databaseName - failed to parse current binary package found in the database. This is not yet an error. Assuming legacy format and trying again. Exception: $_"
					$currentDacpacBytesStr = [string]$database.ExecuteScalar("SELECT TOP 1 CAST(DACPACFILE AS VARCHAR(MAX)) FROM CRT.RETAILUPGRADEHISTORY WHERE UPGRADETYPE = 'RETAIL' ORDER BY ID DESC")
					$currentDacpacBytes = [byte[]]$currentDacpacBytesStr.split(" ")
					$currentDacpac = [Microsoft.Dynamics365.Commerce.Tools.DacValidator.InMemoryPackage]::LoadPackage($currentDacpacBytes)
					Log-TimedMessage "$databaseName - legacy format loaded successfully."
				}
			}
			elseif (-not $axDbVersionTableExists)
			{
				# this is a new database (or at least it seems like it, given the version table doesn't exist), we can generate the upgrade against an empty dacpac
				Log-TimedMessage "$databaseName - this is a new database deployment (because [ax].[DBVESION] table does not exist), binary package is not required."
				$currentDacpac = [Microsoft.Dynamics365.Commerce.Tools.DacValidator.InMemoryPackage]::BuildPackage()
			}
			else
			{
				$legacyDacpackageFilePath = Join-Path $basePath 'Upgrade\Retail' | Join-Path -ChildPath "CommerceRuntimeScripts_$currentDbVersion.dacpac"
				Log-TimedMessage "$databaseName - current binary package not found. Trying to load legacy package from file system path: $legacyDacpackageFilePath"
				if (Test-Path $legacyDacpackageFilePath)
				{
					$currentDacpac = [Microsoft.Dynamics365.Commerce.Tools.DacValidator.DacServicesFacade]::LoadDacpac($legacyDacpackageFilePath)
				}
				else
				{
					Log-TimedMessage "$databaseName - package not found at: $legacyDacpackageFilePath"
					throw "$databaseName - Couldn't find current dacpac associated to current version $currentDbVersion. This is not a new database deployment, please make sure that a DACPAC is available either on the database or at $legacyDacpackageFilePath"
				}
			}

			# Generate script from dacpacs
			Log-TimedMessage "$databaseName - generating creation/upgrade script. This may take several minutes."
			$dacFacade = New-Object Microsoft.Dynamics365.Commerce.Tools.DacValidator.DacServicesFacade -ArgumentList $publishOptions, $targetDacpac
			$script = $dacFacade.GenerateDeployScript($currentDacpac, $databaseName)

			# Remove SQLCMD mode variables not required and not supported by this execution mechanism
			$scriptStartString = "<Begin of Commerce Runtime Scripts>"
			$startIndex = $script.IndexOf($scriptStartString)
			if ($startIndex -ge 0)
			{
				$script = $script.Substring($startIndex + $scriptStartString.Length)
			}

            # Check for legacy version manipulation, i.e. when the post-deployment script would have placeholders in the form 'm4_bld*'
            # And would not handle the RETAIL-PENDING state in the RETAILUPGRADEHISTORY table
			$scriptStartString = "<Begin of versioning database>"
			$startIndex = $script.IndexOf($scriptStartString)
			if ($startIndex -ge 0)
			{
                $m4_bldvermajor_variableName = "m4_bldvermajor"
                $m4_bldverminor_variableName = "m4_bldverminor"
                $m4_bldnummajor_variableName = "m4_bldnummajor"
                $m4_bldnumminor_variableName = "m4_bldnumminor"

                $usesLegacyVersioning = $script.IndexOf($m4_bldvermajor_variableName, $startIndex) -ge 0

                if ($usesLegacyVersioning)
                {
                    Log-TimedMessage "$databaseName - the DACPAC being deployed uses LEGACY VERSIONING. Replacing build numbers on post-deployment script now."
                    $script = $script.Replace($m4_bldvermajor_variableName, $targetVersion.Major.ToString())
                    $script = $script.Replace($m4_bldverminor_variableName, $targetVersion.Minor.ToString())
                    $script = $script.Replace($m4_bldnummajor_variableName, $targetVersion.Build.ToString())
                    $script = $script.Replace($m4_bldnumminor_variableName, $targetVersion.Revision.ToString())

                    Log-TimedMessage "$databaseName - because legacy versioning is being used, storing DACPAC on the database before deployment was disabled. DACPAC will be stored on the database after deployment script has been executed"
                    $databaseSupportsStoringDacpac = $false
                }
			}

			# Replace "$(DatabaseName)" with database name
			$script = $script.Replace('$(DatabaseName)', $databaseName)

			$scriptFileName = "CommerceRuntimeScripts_$($currentDbVersion)_$targetVersion.sql"
			$scriptFilePath = Join-Path $logBasePath $scriptFileName

			# save script to file
			$script | Out-File -FilePath $scriptFilePath
			$script | Out-File -FilePath "$scriptFilePath.log" # most of the infrastructure discriminates .log extensions

			Log-TimedMessage "$databaseName - script created. It can be found at $scriptFilePath"

			# Run script
			# Before we begin, we create a record, which contains the DACPAC file in binary format, indicating that the upgrade has started, but not yet completed successfully
			# After the upgrade script runs, it alters this record's status to complete
			Log-TimedMessage "$databaseName - Storing upgrade DAPAC on the database.";

			[Byte[]]$dacpacFileBytes = [io.file]::ReadAllBytes($packageFilepath)
			$updateDacParams = @{ 'dacpacFileBytes' = $dacpacFileBytes }

			# First we check if DB has table & column to store dacpac, otherwise skip this step
			# Legacy versions of the databse may not have the table or the specific column to store DACPAC
			if ($databaseSupportsStoringDacpac)
			{
				# RETAIL-PENDING means that the upgrade is not yet complete, database script is responsible for moving state to success
				$retailPendingUpgradeType = "RETAIL-PENDING"
				$insertPendingUpgradeRecord = @"
				IF NOT EXISTS (SELECT * FROM [CRT].[RETAILUPGRADEHISTORY] WHERE UPGRADETYPE = '$retailPendingUpgradeType' AND BUILD = '$targetVersion')
					INSERT [crt].[RETAILUPGRADEHISTORY] (UpgradeType, FilePath, FileName, Build, DACPACFILE)
												 VALUES ('$retailPendingUpgradeType', '$scriptFilePath', '$scriptFileName', '$targetVersion', @dacpacFileBytes)
"@
				$database.Execute($updateDacParams, $insertPendingUpgradeRecord)
				Log-TimedMessage "$databaseName - Successfully stored DACPAC on the database.";
			}
			else
			{
				Log-TimedMessage "$databaseName - Database does not support storing DACPACs. DACPAC will be stored after database upgrade adds DACPAC storage support.";
			}


            $pendingDeploymentViewName = '__RETAIL_PENDING_DEPLOYMENT'
            Log-TimedMessage "$databaseName - Checking whether a previous channel database deployment was not deployed successfully. This will be done by checking whether view $pendingDeploymentViewName exists in DBO";
		    $retailPendingDeploymentViewExists = $database.ExecuteScalar("SELECT OBJECT_ID('$pendingDeploymentViewName')") -ne $null

            if ($retailPendingDeploymentViewExists)
            {
                throw "$databaseName - a previous incomplete deployment was identified. The channel database deployment will not continue to prevent corruption of the database. If you see this message during a retry, please check the previous retry logs for the original error message. To ignore this check and force retry (please make sure you know the implications), execute the following script against the database and retry: DROP VIEW $pendingDeploymentViewName;"
            }
            else
            {
                Log-TimedMessage "$databaseName - No previous incomplete deployment was detected. Creating view $pendingDeploymentViewName to signal begining of deployment.";
                $database.Execute("CREATE VIEW $pendingDeploymentViewName AS SELECT 1 A;")
            }

			Log-TimedMessage "$databaseName - Starting script execution. This may take several minutes.";
			$database.ExecuteSqlText($script)
			Log-TimedMessage "$databaseName - Script executed successfully. Removal of $pendingDeploymentViewName will be done next.";

            $database.Execute("IF OBJECT_ID('$pendingDeploymentViewName') IS NOT NULL DROP VIEW $pendingDeploymentViewName;")

			Log-TimedMessage "$databaseName - View $pendingDeploymentViewName was removed.";

			# To support legacy databases that do not support storing DACPACs we need to wait until the end of the upgrade to store the DACPAC
			# This applies to CTP8 and some 7.0 builds before or at 7.0.1265.27563
			if (-not $databaseSupportsStoringDacpac)
			{
				Log-TimedMessage "$databaseName - Legacy database support - Storing DACPAC on database.";
				$database.Execute($updateDacParams, "UPDATE [crt].[RETAILUPGRADEHISTORY] SET DACPACFILE = @dacpacFileBytes WHERE UPGRADETYPE = 'RETAIL' AND BUILD = '$targetVersion'")
				Log-TimedMessage "$databaseName - DACPAC stored on database.";
			}

			$updateDacParams = $null
			$dacpacFileBytes = $null
		}
		else
		{
			Log-TimedMessage "$databaseName - deployment will not continue because database is at same version or newer than upgrade package version."
		}
	}
	catch
	{
		$executionSuccessfull = $false
		throw
	}
	finally
	{
		if ($database)
		{
			$database.Dispose()
		}

		if ($targetDacpac)
		{
			$targetDacpac.Dispose()
		}

		if ($currentDacpac)
		{
			$currentDacpac.Dispose()
		}

		# This is a workaround because we cannot get the log path when running in LCS
		# We need to wait until dispose of database because logs may only be flushed to disk after disposal
		if (-not $executionSuccessfull -and (Test-Path $databaseLogFilepath))
		{
			Log-TimedMessage "$databaseName -------------------- Start of dump of DB logs"
			cat $databaseLogFilepath
			Log-TimedMessage "$databaseName -------------------- End of dump of DB logs"
		}
	}

	Log-TimedMessage "$databaseName - Deployment completed.";
}

<#
.SYNOPSIS
Deploys one or more databases.

.DESCRIPTION
For each configured database in $dbConfigurations, a new database is created if it doesn't current exist.
An existing database is upgraded to the version associated with the database packaged provided in such configuration object.

.PARAMETER dbConfigurations
A collection of dbConfiguration. A dbConfiguration is a dictionary containing the configuration for each database to be deployed.
The following properties are accepted:
	[string]DatabaseName				(required) - the name of the database
	[string]ServerName					(required) - the name (or uri) of the database server
	[stirng]InstanceName				(optional) - the instance of the server database to connect to
	[string]Install						(optional) - if present and equals to "true" the database is deployed, otherwise it is skiped.
	[string]DacpacFilePath				(required) - a path to where the DAC package and associated deployment artifacts are.
	[array]WindowsLogins				(optinal) - a list of window user groups to be created or associated to the database. See Create-UserGroups for details.
	MaxSqlServerMemoryLimitRatio		(optinal) - see Alter-DatabaseParameters function
	DatabaseFilesMinSizeInMB			(optinal) - see Alter-DatabaseParameters function
	DatabaseFilesGrowthRateInPercent	(optinal) - see Alter-DatabaseParameters function
	DatabaseAutoClose					(optinal) - see Alter-DatabaseParameters function

.PARAMETER credentials
A collection of credentials to be used for this deployment. If no credentials are provided, integrated windows authentication with SQL Server
will be used. If credentials is provided, it will only be used if for each entry of dbConfigurations there is a 'SqlUserName' property containing
the user name to be used for SQL authentication.

.PARAMETER logBasePath
A optinal path to a directory where to write additional log files. If not provided, $pwd is assumed.

.EXAMPLE
Deploy-Database -databaseName "ChannelDb" -connectionString "Server=localhost;Integrated Security=true;" -deployableBasePath "C:\dbDeployables"
#>
function Deploy-DatabaseConfiguration(
    [Parameter(Mandatory=$true)]
	[ValidateNotNull()]$dbConfigurations,

    [Parameter(Mandatory=$false)]
	[System.Management.Automation.PSCredential[]]$credentials,

	[Parameter(Mandatory=$false)]
	[string]$logBasePath)
{
	$deploymentWillContinueMessage = "Deployment will continue for other databases, but this deployment will be marked as failed."
	$failedDatabaseDeployments = @()

	# resolve where to log things to
	$logBasePath = @($logBasePath, $global:logdir, $pwd) | where { $_ } | Select-Object -First 1
	$logBasePath = Join-Path $logBasePath "RetailChannelDatabaseLogs" | Join-Path -ChildPath $(Get-Date -f yyyy-MM-dd_hh-mm-ss)
	Log-TimedMessage "Database deployment logs will be available at: $logBasePath"

	$numberOfDatabases = $dbConfigurations.count

    Log-TimedMessage "Deploying $numberOfDatabases databases."

	$dacValidatorToolLookupPaths = @((Join-Path $PSScriptRoot "DacTools\Microsoft.Dynamics365.Commerce.Tools.DacValidator.dll"),
							 (Join-Path $PSScriptRoot "Microsoft.Dynamics365.Commerce.Tools.DacValidator.dll"),
							".\Microsoft.Dynamics365.Commerce.Tools.DacValidator.dll")

	$dacValidatorToolPath = $dacValidatorToolLookupPaths | where { Test-Path $_ } | Select-Object -First 1

	if (-not $dacValidatorToolPath)
	{
		Throw-Error "Microsoft.Dynamics365.Commerce.Tools.DacValidator.dll could not be found. The following paths were used to try to find it: $dacValidatorToolLookupPaths"
	}

	Log-TimedMessage "Loading validation tools from '$dacValidatorToolPath'"
	Add-Type -Path $dacValidatorToolPath

	$index = 0
    foreach($dbConfiguration in $dbConfigurations)
    {
		$index = $index + 1
		[string]$databaseName = [string]$dbConfiguration.DatabaseName
		[string]$serverName = [string]$dbConfiguration.ServerName
		[string]$deployableBasePath = [string]$dbConfiguration.DacpacFilePath
		[string]$customizationsBasePath = [string]$dbConfiguration.CustomScriptPath

		# Topology settings differ, some will provide the path relative to the script path, instead of PWD
		if ($deployableBasePath -and -not (Test-Path $deployableBasePath))
		{
			Log-TimedMessage "$databaseName - Deployable base path not found. Trying to resolve $deployableBasePath relatively to script path at $PSScriptRoot"
			$deployableBasePath = Join-Path $PSScriptRoot $deployableBasePath
		}

		if ($customizationsBasePath -and -not (Test-Path $customizationsBasePath))
		{
			Log-TimedMessage "$databaseName - Customization script base path not found. Trying to resolve $customizationsBasePath relatively to script path at $PSScriptRoot"
			$customizationsBasePath = Join-Path $PSScriptRoot $customizationsBasePath
		}

		Log-TimedMessage "$databaseName - Processing database $index of $numberOfDatabases"

        if($dbConfiguration.Install -eq "true")
        {
			Log-TimedMessage "$databaseName - Deploying database"

			$dbCredential = $null
			$sqlUserName = $dbConfiguration.SqlUserName
			if ($sqlUserName)
			{
				$dbCredential = $credentials | where { $_.UserName -eq $sqlUserName }

				if (-not $dbCredential)
				{
					Log-TimedWarning "$databaseName - was requested to be deployed using user $sqlUserName, but no credentials found for such user. Deployment will try to continue with integrated authentication but may fail."
				}
			}

			$connectionString = Get-ConnectionString -serverName $serverName `
													 -databaseName $databaseName `
													 -instanceName $dbConfiguration.InstanceName  `
													 -credential $dbCredential

			$logFolder = Join-Path $logBasePath $databaseName
			$deploymentFailed = $false

			# Deploy MS artifacts
			try
			{
				if([string]::IsNullOrWhiteSpace($deployableBasePath))
				{
					Log-TimedWarning "$databaseName - deployableBasePath is null or empty. Deployment of Microsoft artifacts will be skipped"
				}
				else
				{
					Deploy-Database -databaseName $databaseName -connectionString $connectionString -deployableBasePath $deployableBasePath -logFolder $logFolder
					Log-TimedMessage "$databaseName - Microsoft artifacts were deployed successfully (or skipped if previous message says so).";
				}
			}
			catch
			{
				Log-Error "$databaseName - An error occurred when deploying database. $deploymentWillContinueMessage"
				Log-Exception $_
				$deploymentFailed = $true
			}

			# Alter DB parametes
			if (-not $deploymentFailed)
			{
				try
				{
					Log-TimedMessage "$databaseName - Altering database parameters.";
					Alter-DatabaseParameters -databaseName $databaseName -connectionString $connectionString `
											-maxSqlMemoryLimitRatio $dbConfiguration.MaxSqlServerMemoryLimitRatio `
											-databaseFileMinSizeMB $dbConfiguration.DatabaseFilesMinSizeInMB `
											-databaseFileGrowthPercentage $dbConfiguration.DatabaseFilesGrowthRateInPercent `
											-databaseAutoClose $dbConfiguration.DatabaseAutoClose
					Log-TimedMessage "$databaseName - Altering database completed.";
				}
				catch
				{
					Log-Error "$databaseName - An error occurred when altering database parameters. $deploymentWillContinueMessage"
					Log-Exception $_
					$deploymentFailed = $true
				}
			}

			# Setup users
			# We only setup windows users if we have $dbCredential NOT set :(
			# This is because deployment topologies that provide $dbCredential are the same topologies that cannot work with integrated Windows authentication
			if (-not $deploymentFailed -and $dbConfiguration.WindowsLogins -and -not $dbCredential)
			{
				# this is only windows users
				Create-UserGroups -databaseName $databaseName -serverName $serverName -connectionString $connectionString -groupMappings $dbConfiguration.WindowsLogins
			}

			# Deploy customizations as last step
			if (-not $deploymentFailed)
			{
				Log-TimedMessage "$databaseName - Deploying customizations";

				try
				{
					if([string]::IsNullOrWhiteSpace($customizationsBasePath))
					{
						Log-TimedWarning "$databaseName - customizationsBasePath is null or empty. Deployment of customizations will be skipped"
					}
					else
					{
						Deploy-Customizations -databaseName $databaseName -connectionString $connectionString -customizationsBasePath $customizationsBasePath -logFolder $logFolder
						Log-TimedMessage "$databaseName - Customization deployment completed successfully.";
					}
				}
				catch
				{
					Log-Error "$databaseName - An error occurred when deploying customizations for database. $deploymentWillContinueMessage"
					Log-Exception $_
					$deploymentFailed = $true
				}
			}

			if ($deploymentFailed)
			{
				$failedDatabaseDeployments += $databaseName
			}

			Log-TimedMessage "$databaseName - Deployment for '$databaseName' finished $(if ($deploymentFailed) { 'with errors' } else { 'successfully' })."
        }
        else
        {
            Log-TimedMessage "$databaseName - Skipping installation for database '$databaseName' because it was not configured for installation."
        }

        $dbConfiguration = $null
    }

	if ($failedDatabaseDeployments)
	{
		Throw-Error "Database upgrade FAILED for the following databases: $($failedDatabaseDeployments -join ', '). You may find more logs under: $logBasePath"
	}
}

# SIG # Begin signature block
# MIIjsAYJKoZIhvcNAQcCoIIjoTCCI50CAQExDzANBglghkgBZQMEAgEFADB5Bgor
# BgEEAYI3AgEEoGswaTA0BgorBgEEAYI3AgEeMCYCAwEAAAQQH8w7YFlLCE63JNLG
# KX7zUQIBAAIBAAIBAAIBAAIBADAxMA0GCWCGSAFlAwQCAQUABCBvcW4i+0XOMGBl
# /+z9vQqo4MS/OsLS5W2xiSgVTulLnaCCDYEwggX/MIID56ADAgECAhMzAAABUZ6N
# j0Bxow5BAAAAAAFRMA0GCSqGSIb3DQEBCwUAMH4xCzAJBgNVBAYTAlVTMRMwEQYD
# VQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNy
# b3NvZnQgQ29ycG9yYXRpb24xKDAmBgNVBAMTH01pY3Jvc29mdCBDb2RlIFNpZ25p
# bmcgUENBIDIwMTEwHhcNMTkwNTAyMjEzNzQ2WhcNMjAwNTAyMjEzNzQ2WjB0MQsw
# CQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9u
# ZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMR4wHAYDVQQDExVNaWNy
# b3NvZnQgQ29ycG9yYXRpb24wggEiMA0GCSqGSIb3DQEBAQUAA4IBDwAwggEKAoIB
# AQCVWsaGaUcdNB7xVcNmdfZiVBhYFGcn8KMqxgNIvOZWNH9JYQLuhHhmJ5RWISy1
# oey3zTuxqLbkHAdmbeU8NFMo49Pv71MgIS9IG/EtqwOH7upan+lIq6NOcw5fO6Os
# +12R0Q28MzGn+3y7F2mKDnopVu0sEufy453gxz16M8bAw4+QXuv7+fR9WzRJ2CpU
# 62wQKYiFQMfew6Vh5fuPoXloN3k6+Qlz7zgcT4YRmxzx7jMVpP/uvK6sZcBxQ3Wg
# B/WkyXHgxaY19IAzLq2QiPiX2YryiR5EsYBq35BP7U15DlZtpSs2wIYTkkDBxhPJ
# IDJgowZu5GyhHdqrst3OjkSRAgMBAAGjggF+MIIBejAfBgNVHSUEGDAWBgorBgEE
# AYI3TAgBBggrBgEFBQcDAzAdBgNVHQ4EFgQUV4Iarkq57esagu6FUBb270Zijc8w
# UAYDVR0RBEkwR6RFMEMxKTAnBgNVBAsTIE1pY3Jvc29mdCBPcGVyYXRpb25zIFB1
# ZXJ0byBSaWNvMRYwFAYDVQQFEw0yMzAwMTIrNDU0MTM1MB8GA1UdIwQYMBaAFEhu
# ZOVQBdOCqhc3NyK1bajKdQKVMFQGA1UdHwRNMEswSaBHoEWGQ2h0dHA6Ly93d3cu
# bWljcm9zb2Z0LmNvbS9wa2lvcHMvY3JsL01pY0NvZFNpZ1BDQTIwMTFfMjAxMS0w
# Ny0wOC5jcmwwYQYIKwYBBQUHAQEEVTBTMFEGCCsGAQUFBzAChkVodHRwOi8vd3d3
# Lm1pY3Jvc29mdC5jb20vcGtpb3BzL2NlcnRzL01pY0NvZFNpZ1BDQTIwMTFfMjAx
# MS0wNy0wOC5jcnQwDAYDVR0TAQH/BAIwADANBgkqhkiG9w0BAQsFAAOCAgEAWg+A
# rS4Anq7KrogslIQnoMHSXUPr/RqOIhJX+32ObuY3MFvdlRElbSsSJxrRy/OCCZdS
# se+f2AqQ+F/2aYwBDmUQbeMB8n0pYLZnOPifqe78RBH2fVZsvXxyfizbHubWWoUf
# NW/FJlZlLXwJmF3BoL8E2p09K3hagwz/otcKtQ1+Q4+DaOYXWleqJrJUsnHs9UiL
# crVF0leL/Q1V5bshob2OTlZq0qzSdrMDLWdhyrUOxnZ+ojZ7UdTY4VnCuogbZ9Zs
# 9syJbg7ZUS9SVgYkowRsWv5jV4lbqTD+tG4FzhOwcRQwdb6A8zp2Nnd+s7VdCuYF
# sGgI41ucD8oxVfcAMjF9YX5N2s4mltkqnUe3/htVrnxKKDAwSYliaux2L7gKw+bD
# 1kEZ/5ozLRnJ3jjDkomTrPctokY/KaZ1qub0NUnmOKH+3xUK/plWJK8BOQYuU7gK
# YH7Yy9WSKNlP7pKj6i417+3Na/frInjnBkKRCJ/eYTvBH+s5guezpfQWtU4bNo/j
# 8Qw2vpTQ9w7flhH78Rmwd319+YTmhv7TcxDbWlyteaj4RK2wk3pY1oSz2JPE5PNu
# Nmd9Gmf6oePZgy7Ii9JLLq8SnULV7b+IP0UXRY9q+GdRjM2AEX6msZvvPCIoG0aY
# HQu9wZsKEK2jqvWi8/xdeeeSI9FN6K1w4oVQM4Mwggd6MIIFYqADAgECAgphDpDS
# AAAAAAADMA0GCSqGSIb3DQEBCwUAMIGIMQswCQYDVQQGEwJVUzETMBEGA1UECBMK
# V2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0
# IENvcnBvcmF0aW9uMTIwMAYDVQQDEylNaWNyb3NvZnQgUm9vdCBDZXJ0aWZpY2F0
# ZSBBdXRob3JpdHkgMjAxMTAeFw0xMTA3MDgyMDU5MDlaFw0yNjA3MDgyMTA5MDla
# MH4xCzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdS
# ZWRtb25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xKDAmBgNVBAMT
# H01pY3Jvc29mdCBDb2RlIFNpZ25pbmcgUENBIDIwMTEwggIiMA0GCSqGSIb3DQEB
# AQUAA4ICDwAwggIKAoICAQCr8PpyEBwurdhuqoIQTTS68rZYIZ9CGypr6VpQqrgG
# OBoESbp/wwwe3TdrxhLYC/A4wpkGsMg51QEUMULTiQ15ZId+lGAkbK+eSZzpaF7S
# 35tTsgosw6/ZqSuuegmv15ZZymAaBelmdugyUiYSL+erCFDPs0S3XdjELgN1q2jz
# y23zOlyhFvRGuuA4ZKxuZDV4pqBjDy3TQJP4494HDdVceaVJKecNvqATd76UPe/7
# 4ytaEB9NViiienLgEjq3SV7Y7e1DkYPZe7J7hhvZPrGMXeiJT4Qa8qEvWeSQOy2u
# M1jFtz7+MtOzAz2xsq+SOH7SnYAs9U5WkSE1JcM5bmR/U7qcD60ZI4TL9LoDho33
# X/DQUr+MlIe8wCF0JV8YKLbMJyg4JZg5SjbPfLGSrhwjp6lm7GEfauEoSZ1fiOIl
# XdMhSz5SxLVXPyQD8NF6Wy/VI+NwXQ9RRnez+ADhvKwCgl/bwBWzvRvUVUvnOaEP
# 6SNJvBi4RHxF5MHDcnrgcuck379GmcXvwhxX24ON7E1JMKerjt/sW5+v/N2wZuLB
# l4F77dbtS+dJKacTKKanfWeA5opieF+yL4TXV5xcv3coKPHtbcMojyyPQDdPweGF
# RInECUzF1KVDL3SV9274eCBYLBNdYJWaPk8zhNqwiBfenk70lrC8RqBsmNLg1oiM
# CwIDAQABo4IB7TCCAekwEAYJKwYBBAGCNxUBBAMCAQAwHQYDVR0OBBYEFEhuZOVQ
# BdOCqhc3NyK1bajKdQKVMBkGCSsGAQQBgjcUAgQMHgoAUwB1AGIAQwBBMAsGA1Ud
# DwQEAwIBhjAPBgNVHRMBAf8EBTADAQH/MB8GA1UdIwQYMBaAFHItOgIxkEO5FAVO
# 4eqnxzHRI4k0MFoGA1UdHwRTMFEwT6BNoEuGSWh0dHA6Ly9jcmwubWljcm9zb2Z0
# LmNvbS9wa2kvY3JsL3Byb2R1Y3RzL01pY1Jvb0NlckF1dDIwMTFfMjAxMV8wM18y
# Mi5jcmwwXgYIKwYBBQUHAQEEUjBQME4GCCsGAQUFBzAChkJodHRwOi8vd3d3Lm1p
# Y3Jvc29mdC5jb20vcGtpL2NlcnRzL01pY1Jvb0NlckF1dDIwMTFfMjAxMV8wM18y
# Mi5jcnQwgZ8GA1UdIASBlzCBlDCBkQYJKwYBBAGCNy4DMIGDMD8GCCsGAQUFBwIB
# FjNodHRwOi8vd3d3Lm1pY3Jvc29mdC5jb20vcGtpb3BzL2RvY3MvcHJpbWFyeWNw
# cy5odG0wQAYIKwYBBQUHAgIwNB4yIB0ATABlAGcAYQBsAF8AcABvAGwAaQBjAHkA
# XwBzAHQAYQB0AGUAbQBlAG4AdAAuIB0wDQYJKoZIhvcNAQELBQADggIBAGfyhqWY
# 4FR5Gi7T2HRnIpsLlhHhY5KZQpZ90nkMkMFlXy4sPvjDctFtg/6+P+gKyju/R6mj
# 82nbY78iNaWXXWWEkH2LRlBV2AySfNIaSxzzPEKLUtCw/WvjPgcuKZvmPRul1LUd
# d5Q54ulkyUQ9eHoj8xN9ppB0g430yyYCRirCihC7pKkFDJvtaPpoLpWgKj8qa1hJ
# Yx8JaW5amJbkg/TAj/NGK978O9C9Ne9uJa7lryft0N3zDq+ZKJeYTQ49C/IIidYf
# wzIY4vDFLc5bnrRJOQrGCsLGra7lstnbFYhRRVg4MnEnGn+x9Cf43iw6IGmYslmJ
# aG5vp7d0w0AFBqYBKig+gj8TTWYLwLNN9eGPfxxvFX1Fp3blQCplo8NdUmKGwx1j
# NpeG39rz+PIWoZon4c2ll9DuXWNB41sHnIc+BncG0QaxdR8UvmFhtfDcxhsEvt9B
# xw4o7t5lL+yX9qFcltgA1qFGvVnzl6UJS0gQmYAf0AApxbGbpT9Fdx41xtKiop96
# eiL6SJUfq/tHI4D1nvi/a7dLl+LrdXga7Oo3mXkYS//WsyNodeav+vyL6wuA6mk7
# r/ww7QRMjt/fdW1jkT3RnVZOT7+AVyKheBEyIXrvQQqxP/uozKRdwaGIm1dxVk5I
# RcBCyZt2WwqASGv9eZ/BvW1taslScxMNelDNMYIVhTCCFYECAQEwgZUwfjELMAkG
# A1UEBhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQx
# HjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEoMCYGA1UEAxMfTWljcm9z
# b2Z0IENvZGUgU2lnbmluZyBQQ0EgMjAxMQITMwAAAVGejY9AcaMOQQAAAAABUTAN
# BglghkgBZQMEAgEFAKCB2DAZBgkqhkiG9w0BCQMxDAYKKwYBBAGCNwIBBDAcBgor
# BgEEAYI3AgELMQ4wDAYKKwYBBAGCNwIBFTAvBgkqhkiG9w0BCQQxIgQg/xIc245/
# iDARCNuBMD45IhJbijLIRc8MEaUvyczXR7MwbAYKKwYBBAGCNwIBDDFeMFygPoA8
# AEEAcABwAGwAeQBSAGUAdABhAGkAbABEAEIAUwBjAHIAaQBwAHQASQBuAFMAUQBM
# AFMAVQAuAHAAcwAxoRqAGGh0dHA6Ly93d3cubWljcm9zb2Z0LmNvbTANBgkqhkiG
# 9w0BAQEFAASCAQAySyKrlZ6Xrv0yKbp2GAs+VGCSictxg5ZT9KAZjteriQZ+czUH
# 5PU2JnaXYdG5eDDkjsESVANLefNgGqi3h81q06ns3CqqBjuU+MM3uNtgHUmh3BCP
# 2uDV4jqGoZoeDGAmWRoNrsT3yXp1UEBfeYx0A/8VDelthNIffrIRtzNAXSvsneBc
# CBOIq0W7PzIeyzNbuHD0hi1Hv1ykHKXmomWYF0iqMooLFNrR/oRIU8WjJOTw3P1p
# V7/LUSxQc5Jbz4tGPKB+3KUMKSyPbFfUjjkf8sAAPy35nC9up0wMF9XE2MqBcvx6
# X3wOouPIAFjbQyxv108cRjkgUO7Xuv+JDo/ZoYIS5TCCEuEGCisGAQQBgjcDAwEx
# ghLRMIISzQYJKoZIhvcNAQcCoIISvjCCEroCAQMxDzANBglghkgBZQMEAgEFADCC
# AVEGCyqGSIb3DQEJEAEEoIIBQASCATwwggE4AgEBBgorBgEEAYRZCgMBMDEwDQYJ
# YIZIAWUDBAIBBQAEIMMe9TkcJMgKGCnOaG6B/aILya/6uP8uiqOv+KnEkxIQAgZd
# XrmPytcYEzIwMTkwOTE3MTkyMDAyLjc4NlowBIACAfSggdCkgc0wgcoxCzAJBgNV
# BAYTAlVTMQswCQYDVQQIEwJXQTEQMA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UEChMV
# TWljcm9zb2Z0IENvcnBvcmF0aW9uMS0wKwYDVQQLEyRNaWNyb3NvZnQgSXJlbGFu
# ZCBPcGVyYXRpb25zIExpbWl0ZWQxJjAkBgNVBAsTHVRoYWxlcyBUU1MgRVNOOjJB
# RDQtNEI5Mi1GQTAxMSUwIwYDVQQDExxNaWNyb3NvZnQgVGltZS1TdGFtcCBzZXJ2
# aWNloIIOPDCCBPEwggPZoAMCAQICEzMAAADXr1puwKo9zrYAAAAAANcwDQYJKoZI
# hvcNAQELBQAwfDELMAkGA1UEBhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAO
# BgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEm
# MCQGA1UEAxMdTWljcm9zb2Z0IFRpbWUtU3RhbXAgUENBIDIwMTAwHhcNMTgwODIz
# MjAyNjUwWhcNMTkxMTIzMjAyNjUwWjCByjELMAkGA1UEBhMCVVMxCzAJBgNVBAgT
# AldBMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9y
# YXRpb24xLTArBgNVBAsTJE1pY3Jvc29mdCBJcmVsYW5kIE9wZXJhdGlvbnMgTGlt
# aXRlZDEmMCQGA1UECxMdVGhhbGVzIFRTUyBFU046MkFENC00QjkyLUZBMDExJTAj
# BgNVBAMTHE1pY3Jvc29mdCBUaW1lLVN0YW1wIHNlcnZpY2UwggEiMA0GCSqGSIb3
# DQEBAQUAA4IBDwAwggEKAoIBAQDdiIha4gkM4bDfHbchZGKOIuASSGISvvwK0tIA
# kL7hIbtG1r0X+Ybzt0lI3Hcy6C/ozxZIHPLtDUdLX2+E6XtGj8xHw6Q1xJWQbxts
# MvdLoszc51rkwPIIBfGzFMQB7iYhH9U1QPGGVRWEiMD3ZGdpkDkH7q8nPMgqzVjT
# dkHWynVaqdNMjst9lhKUBVHsptgAjOoNdcwX/Xz9CRxetlzi6hzLuFuZ47rnFIjq
# MPf7GnkbzdwvUXvoiMdP7PVATtW1M0l7Ny1VxcpTnUBrIlqaIl9O3pgggjoPLLfZ
# j+exulZi8K/E5ZVHJ3YIZ7LMUvQgTNPLs6eN4yJvwW5yuWC9AgMBAAGjggEbMIIB
# FzAdBgNVHQ4EFgQU37inVSf/92m8M1ZjNmtNKaDqVTgwHwYDVR0jBBgwFoAU1WM6
# XIoxkPNDe3xGG8UzaFqFbVUwVgYDVR0fBE8wTTBLoEmgR4ZFaHR0cDovL2NybC5t
# aWNyb3NvZnQuY29tL3BraS9jcmwvcHJvZHVjdHMvTWljVGltU3RhUENBXzIwMTAt
# MDctMDEuY3JsMFoGCCsGAQUFBwEBBE4wTDBKBggrBgEFBQcwAoY+aHR0cDovL3d3
# dy5taWNyb3NvZnQuY29tL3BraS9jZXJ0cy9NaWNUaW1TdGFQQ0FfMjAxMC0wNy0w
# MS5jcnQwDAYDVR0TAQH/BAIwADATBgNVHSUEDDAKBggrBgEFBQcDCDANBgkqhkiG
# 9w0BAQsFAAOCAQEATAtoUsT5ALWyTHGwnNqeeoO4CCjRB7i0OLPeQcjv7JWTA9Qf
# 0OzONpepqV8vwxElyOMYNMRi8MQEVckDi1DpwqzJAh8WSImjaBAg9h0F9YwOuRtG
# DWF3r6BE72QOiJ8KtWRUFF2vPszCKQK2Zon9gu3OGivAmmBy+5LnC8kq75c7uKM4
# /Zr1LrbCinPF7GZBCGkRwQzRlLQp81N9eCmOBKpDdPjesqHGPb8MAk50HA1lme/z
# RAn6RAkF4+DWOL/rNu5fLh51PjxgQPn3gUT4Q/ah1dR9yoPN0lcNnPPx9vAJ5v2s
# mw0n1ajgw4FOvCqbDLj8qs12l6t4xqT617ltMDCCBnEwggRZoAMCAQICCmEJgSoA
# AAAAAAIwDQYJKoZIhvcNAQELBQAwgYgxCzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpX
# YXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNyb3NvZnQg
# Q29ycG9yYXRpb24xMjAwBgNVBAMTKU1pY3Jvc29mdCBSb290IENlcnRpZmljYXRl
# IEF1dGhvcml0eSAyMDEwMB4XDTEwMDcwMTIxMzY1NVoXDTI1MDcwMTIxNDY1NVow
# fDELMAkGA1UEBhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1Jl
# ZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEmMCQGA1UEAxMd
# TWljcm9zb2Z0IFRpbWUtU3RhbXAgUENBIDIwMTAwggEiMA0GCSqGSIb3DQEBAQUA
# A4IBDwAwggEKAoIBAQCpHQ28dxGKOiDs/BOX9fp/aZRrdFQQ1aUKAIKF++18aEss
# X8XD5WHCdrc+Zitb8BVTJwQxH0EbGpUdzgkTjnxhMFmxMEQP8WCIhFRDDNdNuDgI
# s0Ldk6zWczBXJoKjRQ3Q6vVHgc2/JGAyWGBG8lhHhjKEHnRhZ5FfgVSxz5NMksHE
# pl3RYRNuKMYa+YaAu99h/EbBJx0kZxJyGiGKr0tkiVBisV39dx898Fd1rL2KQk1A
# UdEPnAY+Z3/1ZsADlkR+79BL/W7lmsqxqPJ6Kgox8NpOBpG2iAg16HgcsOmZzTzn
# L0S6p/TcZL2kAcEgCZN4zfy8wMlEXV4WnAEFTyJNAgMBAAGjggHmMIIB4jAQBgkr
# BgEEAYI3FQEEAwIBADAdBgNVHQ4EFgQU1WM6XIoxkPNDe3xGG8UzaFqFbVUwGQYJ
# KwYBBAGCNxQCBAweCgBTAHUAYgBDAEEwCwYDVR0PBAQDAgGGMA8GA1UdEwEB/wQF
# MAMBAf8wHwYDVR0jBBgwFoAU1fZWy4/oolxiaNE9lJBb186aGMQwVgYDVR0fBE8w
# TTBLoEmgR4ZFaHR0cDovL2NybC5taWNyb3NvZnQuY29tL3BraS9jcmwvcHJvZHVj
# dHMvTWljUm9vQ2VyQXV0XzIwMTAtMDYtMjMuY3JsMFoGCCsGAQUFBwEBBE4wTDBK
# BggrBgEFBQcwAoY+aHR0cDovL3d3dy5taWNyb3NvZnQuY29tL3BraS9jZXJ0cy9N
# aWNSb29DZXJBdXRfMjAxMC0wNi0yMy5jcnQwgaAGA1UdIAEB/wSBlTCBkjCBjwYJ
# KwYBBAGCNy4DMIGBMD0GCCsGAQUFBwIBFjFodHRwOi8vd3d3Lm1pY3Jvc29mdC5j
# b20vUEtJL2RvY3MvQ1BTL2RlZmF1bHQuaHRtMEAGCCsGAQUFBwICMDQeMiAdAEwA
# ZQBnAGEAbABfAFAAbwBsAGkAYwB5AF8AUwB0AGEAdABlAG0AZQBuAHQALiAdMA0G
# CSqGSIb3DQEBCwUAA4ICAQAH5ohRDeLG4Jg/gXEDPZ2joSFvs+umzPUxvs8F4qn+
# +ldtGTCzwsVmyWrf9efweL3HqJ4l4/m87WtUVwgrUYJEEvu5U4zM9GASinbMQEBB
# m9xcF/9c+V4XNZgkVkt070IQyK+/f8Z/8jd9Wj8c8pl5SpFSAK84Dxf1L3mBZdmp
# tWvkx872ynoAb0swRCQiPM/tA6WWj1kpvLb9BOFwnzJKJ/1Vry/+tuWOM7tiX5rb
# V0Dp8c6ZZpCM/2pif93FSguRJuI57BlKcWOdeyFtw5yjojz6f32WapB4pm3S4Zz5
# Hfw42JT0xqUKloakvZ4argRCg7i1gJsiOCC1JeVk7Pf0v35jWSUPei45V3aicaoG
# ig+JFrphpxHLmtgOR5qAxdDNp9DvfYPw4TtxCd9ddJgiCGHasFAeb73x4QDf5zEH
# pJM692VHeOj4qEir995yfmFrb3epgcunCaw5u+zGy9iCtHLNHfS4hQEegPsbiSpU
# ObJb2sgNVZl6h3M7COaYLeqN4DMuEin1wC9UJyH3yKxO2ii4sanblrKnQqLJzxlB
# TeCG+SqaoxFmMNO7dDJL32N79ZmKLxvHIa9Zta7cRDyXUHHXodLFVeNp3lfB0d4w
# wP3M5k37Db9dT+mdHhk4L7zPWAUu7w2gUDXa7wknHNWzfjUeCLraNtvTX4/edIhJ
# EqGCAs4wggI3AgEBMIH4oYHQpIHNMIHKMQswCQYDVQQGEwJVUzELMAkGA1UECBMC
# V0ExEDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3Jh
# dGlvbjEtMCsGA1UECxMkTWljcm9zb2Z0IElyZWxhbmQgT3BlcmF0aW9ucyBMaW1p
# dGVkMSYwJAYDVQQLEx1UaGFsZXMgVFNTIEVTTjoyQUQ0LTRCOTItRkEwMTElMCMG
# A1UEAxMcTWljcm9zb2Z0IFRpbWUtU3RhbXAgc2VydmljZaIjCgEBMAcGBSsOAwIa
# AxUAzTZ24jTRpyU2peucTVbl/F0HEa2ggYMwgYCkfjB8MQswCQYDVQQGEwJVUzET
# MBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UEChMV
# TWljcm9zb2Z0IENvcnBvcmF0aW9uMSYwJAYDVQQDEx1NaWNyb3NvZnQgVGltZS1T
# dGFtcCBQQ0EgMjAxMDANBgkqhkiG9w0BAQUFAAIFAOErfqQwIhgPMjAxOTA5MTcy
# MzQ3NDhaGA8yMDE5MDkxODIzNDc0OFowdzA9BgorBgEEAYRZCgQBMS8wLTAKAgUA
# 4St+pAIBADAKAgEAAgIhtgIB/zAHAgEAAgIRYTAKAgUA4SzQJAIBADA2BgorBgEE
# AYRZCgQCMSgwJjAMBgorBgEEAYRZCgMCoAowCAIBAAIDB6EgoQowCAIBAAIDAYag
# MA0GCSqGSIb3DQEBBQUAA4GBAIBBgwsM+CPjl+LOl7f70rOqeGi0Yi75UEOfYMVQ
# Po5a/9Bl+Anpa+h/u+Ip1mlOuAt+NNdfFY2pKov3/DLe04DP3EWIyNCB4sumVEis
# vrQTgCXRgp3OmOnT7nyp0dpJy+p59z9wn0y1I6Qnhm/tyEI7iHx12fGtBE9nknsv
# nms7MYIDDTCCAwkCAQEwgZMwfDELMAkGA1UEBhMCVVMxEzARBgNVBAgTCldhc2hp
# bmd0b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jw
# b3JhdGlvbjEmMCQGA1UEAxMdTWljcm9zb2Z0IFRpbWUtU3RhbXAgUENBIDIwMTAC
# EzMAAADXr1puwKo9zrYAAAAAANcwDQYJYIZIAWUDBAIBBQCgggFKMBoGCSqGSIb3
# DQEJAzENBgsqhkiG9w0BCRABBDAvBgkqhkiG9w0BCQQxIgQgZYQV1wXvbOlLZKwX
# YcFlRkFqQrg8QQed4Bel1pHfmMEwgfoGCyqGSIb3DQEJEAIvMYHqMIHnMIHkMIG9
# BCCljmAMJw9BHv3eSih0+yhBcs7IauKTg/VixBFGziTjODCBmDCBgKR+MHwxCzAJ
# BgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25k
# MR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xJjAkBgNVBAMTHU1pY3Jv
# c29mdCBUaW1lLVN0YW1wIFBDQSAyMDEwAhMzAAAA169absCqPc62AAAAAADXMCIE
# IN4TLo7X2UxXfSttJz6N3RmzIQjwELkFxFxfH5QLrsQGMA0GCSqGSIb3DQEBCwUA
# BIIBAHoagzDagloeWlOSqyNWZLg6fCrqg76q0gOlOBiwSTRiWL5RQG7fHPHROsqE
# cdpMzpKCKSRWGM3BvprKf1/RbjkhQu6H1vr9EIb/iS8S8daqAbMmFF0KxlMDag45
# pXqLVptigad4WQ/E7cfhrbI34vyLsymbHrkj4YCwI9e42Sm5we6V98j6pmArzte5
# 2GFpG+gluhd6DOld3hfuxI/LRxR/Wz1t/6LoYZCAFAtgJI+97HP/iA4mDrwDdvbz
# QmDRLnme2tHdJPu7ZMAKstXVuBhAQ25lTLLoWbGHGGVxUULVnu2HRBKijzHyYzmw
# jipf/Pv2RFCOw3vvySSXUifJ0Uk=
# SIG # End signature block
