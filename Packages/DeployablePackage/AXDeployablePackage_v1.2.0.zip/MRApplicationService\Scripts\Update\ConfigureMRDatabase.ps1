<#
.Synopsis
Runs the required steps to configure the MR database for a new environment
#>
[CmdletBinding()]
Param
(
	# Updated name for the AOS database
	[string]
	[ValidateNotNullOrEmpty()]
	$NewAosDatabaseName,

	# Updated server name for the AOS database server
	[string]
	[ValidateNotNullOrEmpty()]
	$NewAosDatabaseServerName,

	# Updated name for the MR database
	[string]
	[ValidateNotNullOrEmpty()]
	$NewMRDatabaseName,

	# Updated server name for the MR database server
	[string]
	[ValidateNotNullOrEmpty()]
	$NewMRDatabaseServerName = $NewAosDatabaseServerName,

	# New user name for the admin user in the AX database which MR should use
	[string]
	[ValidateNotNullOrEmpty()]
	$NewAxAdminUserName = 'axdeployuser',

	# New password for the admin user in the AX database which MR should use
	[string]
	[ValidateNotNullOrEmpty()]
	$NewAxAdminUserPassword,

	# New user name for the lower-privileged user in the AX database which MR should use
	[string]
	[ValidateNotNullOrEmpty()]
	$NewAxMRRuntimeUserName = 'axmrruntimeuser',

	# New password for the lower-privileged user in the AX database which MR should use
	[string]
	[ValidateNotNullOrEmpty()]
	$NewAxMRRuntimeUserPassword,

	# New user name for the admin user in the MR database
	[string]
	[ValidateNotNullOrEmpty()]
	$NewMRAdminUserName = 'mradminuser',

	# New password for the admin user in the MR database
	[string]
	[ValidateNotNullOrEmpty()]
	$NewMRAdminUserPassword,

	# New user name for the lower-privileged user in the MR database
	[string]
	[ValidateNotNullOrEmpty()]
	$NewMRRuntimeUserName = 'mrruntimeuser',

	# New password for the lower-privileged user in the MR database
	[string]
	[ValidateNotNullOrEmpty()]
	$NewMRRuntimeUserPassword,

	# Include this switch to default the FQDN of database server to Azure
	[switch]
	$AzureDatabase,

	# Include this switch to skip the pause warnings
	[switch]
	$NoPause,

	# Path to log file
	[string]
	[ValidateNotNullOrEmpty()]
	$LogFilePath = (Join-Path -Path $PSScriptRoot -ChildPath "MR_ConfigureDatabase_$(Get-Date -Format yyyyMMdd-HHmmss).log"),

	# SQL command timeout, override this to cause a shorter timeout
	[int]
	[ValidateRange(0,[int]::MaxValue)]
	$SqlTimeoutSeconds = 6600
)

#############################
# Validation of parameters
#############################

# Using checks here to avoid automation getting stuck for madatory parameters
if(!$NewAosDatabaseName) { throw 'Parameter $NewAosDatabaseName must not be null or empty.' }
if(!$NewAosDatabaseServerName) { throw 'Parameter $NewAosDatabaseServerName must not be null or empty.' }
if(!$NewMRDatabaseName) { throw 'Parameter $NewMRDatabaseName must not be null or empty.' }
if(!$NewAxAdminUserPassword) { throw 'Parameter $NewAxAdminUserPassword must not be null or empty.' }
if(!$NewAxMRRuntimeUserPassword) { throw 'Parameter $NewAxMRRuntimeUserPassword must not be null or empty.' }
if(!$NewMRAdminUserPassword) { throw 'Parameter $NewMRAdminUserPassword must not be null or empty.' }
if(!$NewMRRuntimeUserPassword) { throw 'Parameter $NewMRRuntimeUserPassword must not be null or empty.' }

$azureDatabaseDomain = '.database.windows.net'
if(!$AzureDatabase -and ($NewAosDatabaseServerName -notlike "*$azureDatabaseDomain"))
{
	if(!$NoPause)
	{
		Write-Warning "The database server $NewAosDatabaseServerName does not appear to be an Azure server."
		Write-Host "Is this correct (y/n)?"
		$response = $Host.UI.RawUI.ReadKey('NoEcho,IncludeKeyDown')
		if($response.Character -ne 'y')
		{
			Write-Warning "Updating the database server with the Azure FQDN."
			$AzureDatabase = $true
		}
	}
}

# Update the database server to fqdn
if($AzureDatabase)
{
	if ($NewAosDatabaseServerName -notlike "*$azureDatabaseDomain")
	{
		$NewAosDatabaseServerName = $NewAosDatabaseServerName + $azureDatabaseDomain
	}

	if ($NewMRDatabaseServerName -notlike "*$azureDatabaseDomain")
	{
		$NewMRDatabaseServerName = $NewMRDatabaseServerName + $azureDatabaseDomain
	}
}
#############################
# Determine the current folder, $PSScriptRoot and $PSCommandPath do not give the same results when executed in the runbook
$script:currentFolder = (Get-ChildItem -Path (Split-Path -Path $PSScriptRoot -Parent) -Recurse -Filter ConfigureMRDatabase.ps1 | Select-Object -First 1).Directory.FullName
$commonUpgradeFunctionsPath = Join-Path -Path $script:currentFolder -ChildPath "CommonMRUpgradeFunctions.ps1"
$commonUpgradeFunctionsPath = Resolve-Path -Path $commonUpgradeFunctionsPath
. "$commonUpgradeFunctionsPath"

<#
Use the DataProtectionManager to encrypt a value then encode to Base64.
Only used for Adpater Settings.
#>
function Protect-AdapterSettingValue
{
	[CmdletBinding()]
	[OutputType([string])]
	Param
	(
		[ValidateNotNull()]
		[pscustomobject]
		$InstallPaths,

		# Value to encrypt and encode
		[string]
		[ValidateNotNullOrEmpty()]
		$Value
	)

	$keyVaultPath = Join-Path -Path $InstallPaths.Services -ChildPath 'Microsoft.CE.VaultSDK.dll'
	if(Test-Path -Path $keyVaultPath)
	{
		Add-Type -Path $keyVaultPath
	}

	Add-Type -Path (Join-Path -Path $InstallPaths.Connector -ChildPath 'Microsoft.Dynamics.Integration.DataAccessLayer.dll')
	$bindingFlags = [System.Reflection.BindingFlags] "NonPublic,Static"
	$privateMethod = [Microsoft.Dynamics.Integration.DataAccessLayer.DataProtectionManager].GetMethod("Encrypt", $bindingFlags)
	$encryptedValue = $privateMethod.Invoke($null, $Value)
	$encodedValue = [System.Convert]::ToBase64String($encryptedValue)
	return $encodedValue
}

function Update-AdapterSettings
{
	[CmdletBinding()]
	Param
	(
		# Connection string to the MR database
		[string]
		[ValidateNotNullOrEmpty()]
		$ConnectionString,

		# Settings xml
		[xml]
		[ValidateNotNullOrEmpty()]
		$Settings
	)

	Write-MRStepMessage "Updating AX and Data Mart adapter settings"
	$installPaths = Get-MRFilePaths
	$defaultValues = Get-MRDefaultValues
	$protectedAxSqlPassword = (Protect-AdapterSettingValue -InstallPaths $installPaths -Value $defaultValues.AXSqlUserPassword)

	$frsite = '/FinancialReporting'
	$aosurl = Get-SettingsConfigValue -SettingsXml $Settings -SettingName 'DefaultBaseAddress'
	$aosurl = $aosurl -ireplace $frsite,''

	$query = ''
	$query += Get-UpdateAdapterQuery -AdapterId 'E3E10D70-FDAB-480C-952E-8397524F9236' -FieldName 'AOSServer' -Value $aosurl
	$query += Get-UpdateAdapterQuery -AdapterId 'E3E10D70-FDAB-480C-952E-8397524F9236' -FieldName 'DatabaseServer' -Value $defaultValues.AosSqlServerName
	$query += Get-UpdateAdapterQuery -AdapterId 'E3E10D70-FDAB-480C-952E-8397524F9236' -FieldName 'Database' -Value $defaultValues.AXDatabaseName
	$query += Get-UpdateAdapterQuery -AdapterId 'E3E10D70-FDAB-480C-952E-8397524F9236' -FieldName 'UserName' -Value $defaultValues.AXSqlUserName
	$query += Get-UpdateAdapterQuery -AdapterId 'E3E10D70-FDAB-480C-952E-8397524F9236' -FieldName 'Password' -Value $protectedAxSqlPassword
	$query += Get-UpdateAdapterQuery -AdapterId 'E3E10D70-FDAB-480C-952E-8397524F9236' -FieldName 'SqlUserName' -Value $defaultValues.AXSqlUserName
	$query += Get-UpdateAdapterQuery -AdapterId 'E3E10D70-FDAB-480C-952E-8397524F9236' -FieldName 'SqlPassword' -Value $protectedAxSqlPassword
	$query += Get-UpdateAdapterQuery -AdapterId 'E3E10D70-FDAB-480C-952E-8397524F9236' -FieldName 'CertUserName' -Value (Get-SettingsConfigValue -SettingsXml $Settings -SettingName 'CertUserName')
	$query += Get-UpdateAdapterQuery -AdapterId 'E3E10D70-FDAB-480C-952E-8397524F9236' -FieldName 'ProviderName' -Value (Get-SettingsConfigValue -SettingsXml $Settings -SettingName 'ProviderName')
	$query += Get-UpdateAdapterQuery -AdapterId 'E3E10D70-FDAB-480C-952E-8397524F9236' -FieldName 'FederationRealm' -Value (Get-SettingsConfigValue -SettingsXml $Settings -SettingName 'FederationRealm')
	$query += Get-UpdateAdapterQuery -AdapterId 'E3E10D70-FDAB-480C-952E-8397524F9236' -FieldName 'CertThumbprint' -Value (Get-SettingsConfigValue -SettingsXml $Settings -SettingName 'CertThumbprint')
	$query += Get-UpdateAdapterQuery -AdapterId 'E3E10D70-FDAB-480C-952E-8397524F9236' -FieldName 'TokenIssuer' -Value (Get-SettingsConfigValue -SettingsXml $Settings -SettingName 'TokenIssuer')

	$query += Get-UpdateAdapterQuery -AdapterId 'D08F150E-D964-4CC0-89C9-5752FF8AF85E' -FieldName 'Server' -Value $defaultValues.MRSqlServerName
	$query += Get-UpdateAdapterQuery -AdapterId 'D08F150E-D964-4CC0-89C9-5752FF8AF85E' -FieldName 'Database' -Value $defaultValues.MRDatabaseName
	$query += Get-UpdateAdapterQuery -AdapterId 'D08F150E-D964-4CC0-89C9-5752FF8AF85E' -FieldName 'UserName' -Value $defaultValues.MRSqlUserName
	$query += Get-UpdateAdapterQuery -AdapterId 'D08F150E-D964-4CC0-89C9-5752FF8AF85E' -FieldName 'Password' -Value (Protect-AdapterSettingValue -InstallPaths $installPaths -Value $defaultValues.MRSqlUserPassword)

	$query += Get-UpdateAdapterQuery -AdapterId '492252C3-A2E5-48B1-84DD-277402F97930' -FieldName 'AOSServer' -Value $aosurl

	Invoke-SqlQuery -ConnectionString $ConnectionString -Query $query -ResultReader (Get-ExecuteNonQueryReader)
	Write-MRInfoMessage "Completed updating AX and Data Mart adapter settings" -Success
}

<#
	.Synopsis
	Publishes AX database settings.
#>

function Update-MRCompanySettings
{
	[CmdletBinding()]
	Param
	(
		# Connection string to the MR database
		[string]
		[ValidateNotNullOrEmpty()]
		$ConnectionString
	)

	Write-MRStepMessage "Updating MR adapter setting and company connections"
	$installPaths = Get-MRFilePaths
	$defaultValues = Get-MRDefaultValues
	$selectQuery = 'SELECT ID, GLEntityConnectionInformation FROM [Reporting].[ControlCompany]'
	$updateQuery = Get-UpdateAdapterQuery -AdapterId '492252C3-A2E5-48B1-84DD-277402F97930' -FieldName 'DataMartConnectionString' -Value (Protect-AdapterSettingValue -InstallPaths $installPaths -Value $ConnectionString)
	$resultReader = {
		Param
		(
			[System.Data.SqlClient.SqlCommand]
			$SqlCmd
		)

		[System.Data.SqlClient.SqlDataReader]$reader = $null
		$reader = $SqlCmd.ExecuteReader()
		while($reader.Read())
		{
			[xml]$data = $reader[1]
			$entitySetting = $data.SelectSingleNode("//EntitySetting[@Name='SQL Server']").FirstChild.'#text' = $defaultValues.MRSqlServerName
			$entitySetting = $data.SelectSingleNode("//EntitySetting[@Name='DDM Database']").FirstChild.'#text' = $defaultValues.MRDatabaseName
			$entitySetting = $data.SelectSingleNode("//EntitySetting[@Name='SQL User']").FirstChild.'#text' = $defaultValues.MRSqlUserName
			$entitySetting = $data.SelectSingleNode("//EntitySetting[@Name='SQL Password']").FirstChild.'#text' = (Protect-String -InstallPaths $installPaths -Value $defaultValues.MRSqlUserPassword)
			Set-Variable -Name updateQuery -Value ($updateQuery += "UPDATE Reporting.ControlCompany SET GLEntityConnectionInformation = '$($data.OuterXml)' WHERE ID = '$($reader[0])'") -Scope 1
		}
	}

	Invoke-SqlQuery -ConnectionString $ConnectionString -Query $selectQuery -ResultReader $resultReader
	Invoke-SqlQuery -ConnectionString $ConnectionString -Query $updateQuery -ResultReader (Get-ExecuteNonQueryReader)
	Write-MRInfoMessage "Completed MR adapter setting and company connections" -Success
}

function Update-ChangeTracking
{
    Write-MRStepMessage 'Adding AX database change tracking (Add-AXDatabaseChangeTracking)'
    $addAXDatabaseChangeTrackingParams = Get-AddAXDatabaseChangeTrackingParams
    if((Get-Command Add-AXDatabaseChangeTracking).Parameters.Keys.Contains('SkipVirtualTableResolution'))
	{
		$addAXDatabaseChangeTrackingParams += @{'SkipVirtualTableResolution' = $true}
	}

    $installedVersion = Get-BinaryVersion
    if ($installedVersion -ge [version]'7.2')
    {
        Add-AXDatabaseChangeTracking @addAXDatabaseChangeTrackingParams
        Write-MRInfoMessage 'Completed update to change tracking' -Success

        Write-MRStepMessage 'Adding reporting database change tracking (Add-MRDatabaseChangeTracking)'
        $addMRDatabaseChangeTrackingParams = Get-AddMRDatabaseChangeTrackingParams
        Add-MRDatabaseChangeTracking @addMRDatabaseChangeTrackingParams
        Write-MRInfoMessage 'Completed update to change tracking' -Success
    }
}

function Update-IntegrationSource
{
	[CmdletBinding()]
	Param
	(
		# Connection string to the MR database
		[string]
		[ValidateNotNullOrEmpty()]
		$ConnectionString
	)

	$loggerTaskGuid = [System.Guid]::NewGuid().ToString()
	$loggerTaskMessage = 'Update integration source.'
	Log-Event -EventType Start -message $loggerTaskMessage -guid $loggerTaskGuid

	Write-MRStepMessage 'Updating integration source'
	try
	{
		# Find the expected integration source from adapter settings that points to the current environment
		$adapterQuery = "SELECT TOP 1 Settings FROM [Connector].[MapCategoryAdapterSettings] WHERE AdapterId = 'E3E10D70-FDAB-480C-952E-8397524F9236'"
		[xml]$adapterSettingXml = Invoke-SqlQuery -ConnectionString $ConnectionString -Query $adapterQuery -ResultReader (Get-ExecuteScalarReader)
		$matchingfieldDefinition = $adapterSettingXml.settingsCollection.ArrayOfSettingsValue.SettingsValue | Where-Object {$_.fieldDefinition.Name -match "AOSServer"}
		$expectedIntegrationSource = $matchingfieldDefinition.Value

		Write-MRStepMessage "Expected integration source is: '$expectedIntegrationSource'."

		# Log all existing integration sources in MR database
		$existingIntegrationSourceQuery = 'SELECT Name FROM [Reporting].[ControlIntegrationSource]'
		$resultReader = {
			Param
			(
				[System.Data.SqlClient.SqlCommand]
				$SqlCmd
			)

			[System.Data.SqlClient.SqlDataReader]$reader = $null
			$reader = $SqlCmd.ExecuteReader()
			while($reader.Read())
			{
				[string]$data = $reader[0]

				if($data -ne $expectedIntegrationSource)
				{
					Write-MRStepMessage "Unexpected integration sources '$data' is found. The related integration source data will be deleted from MR database."
				}
				else
				{
					Write-MRStepMessage "Expected integration sources '$data' is found in MR database."
				}
			}
		}
		Invoke-SqlQuery -ConnectionString $ConnectionString -Query $existingIntegrationSourceQuery -ResultReader $resultReader

		# Remove unexpected integration sources from MR database
		$query = @"
DECLARE @badSourceId int
DECLARE @goodSourceID int
DECLARE @name NVARCHAR(255)
DECLARE @expectedIntegrationSource NVARCHAR(255) = '$expectedIntegrationSource'

SELECT @goodSourceID = (SELECT TOP 1 ID FROM Reporting.ControlIntegrationSource WHERE Name = @expectedIntegrationSource)
IF(@goodSourceID IS NULL)
BEGIN
	INSERT INTO Reporting.ControlIntegrationSource VALUES (@expectedIntegrationSource,':0')
	SELECT @goodSourceID = (SELECT TOP 1 ID FROM Reporting.ControlIntegrationSource WHERE Name = @expectedIntegrationSource)
    
    UPDATE [Connector].[Map] SET [ReaderToken] = NULL, [LastQuerySuccess] = '1900-01-01'
		FROM [Scheduling].[Task] WITH (NOLOCK)
		INNER JOIN [Scheduling].[TaskType] WITH (NOLOCK) ON [Task].[TypeId] = [TaskType].[Id]
		INNER JOIN [Connector].[Map] WITH (NOLOCK) ON [Task].[Id] = [Map].[MapId]
		WHERE Task.Name like '%Organization Hierarchies to Tree' and TaskType.Name like '%Map Task%'

	UPDATE [Scheduling].[Trigger] SET [Trigger].[RunImmediately] = 1 
		FROM [Scheduling].[Task] WITH (NOLOCK)
		INNER JOIN [Scheduling].[TaskType] WITH (NOLOCK) ON [Task].[TypeId] = [TaskType].[Id]
		INNER JOIN [Scheduling].[Trigger] WITH (NOLOCK) ON [Task].[TriggerId] = [Scheduling].[Trigger].[Id]
		WHERE Task.Name like '%Organization Hierarchies to Tree' and TaskType.Name like '%Map Task%'
END

DECLARE integrationSourceCursor CURSOR LOCAL FAST_FORWARD FOR
SELECT ID, Name
FROM Reporting.ControlIntegrationSource	WHERE ID != @goodSourceID
OPEN integrationSourceCursor
FETCH NEXT FROM integrationSourceCursor INTO @badSourceId, @name
WHILE (@@FETCH_STATUS = 0)
BEGIN
	-- Re-associate trees that are in use
	DECLARE @treeId uniqueidentifier
	DECLARE @oldIntegrationKey uniqueidentifier
	DECLARE @folderName NVARCHAR(255)
	DECLARE fixOldTreesCursor CURSOR LOCAL FAST_FORWARD FOR
	SELECT ctm.ID, cfi.IntegrationKey, cfi.Name FROM Reporting.ControlTreeMaster ctm 
		join Reporting.ControlFolder cf ON ctm.FolderID = cf.ID
		join Reporting.ControlReport cr ON cr.ReportingTreeID = ctm.ID
		left join Reporting.ControlFolderIntegration cfi on cfi.FolderID = cf.ID
		WHERE cf.FolderType = 3 and cf.SpecificationSetID is NULL and cfi.SourceID = @badSourceId
	OPEN fixOldTreesCursor
	FETCH NEXT FROM fixOldTreesCursor INTO @treeId, @oldIntegrationKey, @folderName
	WHILE (@@FETCH_STATUS = 0)
	BEGIN
		DECLARE @newTreeId uniqueidentifier 
		SET @newTreeId = (SELECT top 1 ctm.ID FROM Reporting.ControlTreeMaster ctm 
			join Reporting.ControlFolder cf ON ctm.FolderID = cf.ID	
			join Reporting.ControlTreeIntegration ti on ctm.ID = ti.TreeID
			join Reporting.ControlFolderIntegration cfi on cfi.FolderID = cf.ID
			WHERE cf.FolderType = 3 and cf.SpecificationSetID is NULL and cfi.SourceID = @goodSourceID and cfi.Name = @folderName
			ORDER BY ti.EffectiveDate ASC)
		IF @newTreeId IS NULL
		BEGIN
			-- since it's null just update to the new source
			print 'No matching tree was found.'
			BEGIN TRY	
				BEGIN TRAN UpdateIntegrationSource	
					UPDATE Reporting.ControlTreeIntegration SET SourceID = @goodSourceID WHERE IntegrationKey = @oldIntegrationKey and TreeID = @treeId						
					UPDATE Reporting.ControlFolderIntegration SET SourceID = @goodSourceID from Reporting.ControlFolderIntegration 
						INNER JOIN Reporting.ControlTreeMaster ON [ControlFolderIntegration].FolderID = [ControlTreeMaster].FolderID 
						WHERE IntegrationKey = @oldIntegrationKey and ControlTreeMaster.ID = @treeId				
				COMMIT TRAN UpdateIntegrationSource 
			END TRY
			BEGIN CATCH
				IF (@@TRANCOUNT > 0)
				BEGIN
				  print 'Failed to correct the integration source for the existing integrated tree, all changes reversed.'--
				  ROLLBACK TRANSACTION UpdateIntegrationSource				  
				END 
				-- remove the tree reference from report definition
				UPDATE Reporting.ControlReport SET ReportingTreeID = NULL, StartingUnitID = NULL WHERE ReportingTreeID = @treeId				
			END CATCH
		END
		ELSE
		BEGIN
			-- we have a new tree to use, update the tree reference from report definition instead
			print 'Found matching tree.'
			UPDATE Reporting.ControlReport SET ReportingTreeID = @newTreeId, StartingUnitID = NULL WHERE ReportingTreeID = @treeId
		END
		FETCH NEXT FROM fixOldTreesCursor INTO @treeId, @oldIntegrationKey, @folderName
	END
	CLOSE fixOldTreesCursor
	DEALLOCATE fixOldTreesCursor

	-- Clear the reset of the references from the old integration source
	Delete from [Reporting].[SecurityUserIntegration] where SourceID = @badSourceId 
	Delete from [Reporting].[ControlCompanyIntegration] where SourceID = @badSourceId 
	Delete from [Reporting].[SecurityCompanyPermissionIntegration] where SourceID = @badSourceId 
	Delete from [Reporting].[SecurityCompanyPermissionStaging] where SourceID = @badSourceId 
	Delete from [Reporting].[ControlTreeIntegration] where SourceID = @badSourceId
	Delete from [Reporting].[ControlConfiguredIntegration] where SourceID = @badSourceId
	Delete from [Reporting].[ControlTreeMaster] where FolderID in (select FolderID from Reporting.ControlFolderIntegration where SourceID = @badSourceId) 
	Delete from [Reporting].[ControlFolder] where ID in (select FolderID from Reporting.ControlFolderIntegration where SourceID = @badSourceId)
	Delete from [Reporting].[ControlFolderIntegration] where SourceID = @badSourceId
FETCH NEXT FROM integrationSourceCursor INTO @badSourceId, @name
END
CLOSE integrationSourceCursor
DEALLOCATE integrationSourceCursor

Delete from [Reporting].[ControlIntegrationSource] where ID != @goodSourceID
"@
		Invoke-SqlQuery -ConnectionString $ConnectionString -Query $query -ResultReader (Get-ExecuteNonQueryReader)
		Write-MRInfoMessage 'Completed updating integration source' -Success
	}
	finally
	{
		Log-Event -EventType Stop -message $loggerTaskMessage -guid $loggerTaskGuid
	}
}

function Get-MRFilePaths
{
	$registryView = [Microsoft.Win32.RegistryView]::Default
	if([Environment]::Is64BitOperatingSystem)
	{
		# If OS is x64, always force x64 registry
		$registryView = [Microsoft.Win32.RegistryView]::Registry64
	}

	$baseKey = [Microsoft.Win32.RegistryKey]::OpenBaseKey([Microsoft.Win32.RegistryHive]::LocalMachine, $registryView)
	$mrServerRegKey = $baseKey.OpenSubKey('Software\Microsoft\Dynamics\ManagementReporter\21\Server')
	[string]$mrInstallLocation = $null
	if(!$mrServerRegKey)
	{
		# See if the MSI is installed and pull the InstallLocation from that, fail-safe if the registry gets messed up
		$product = Get-MRServerInstallProduct
		if(!$product)
		{
			throw 'MR server is not installed'
		}
		else
		{
			$mrInstallLocation = $product.InstallLocation
		}
	}
	else
	{
		$mrInstallLocation = $mrServerRegKey.GetValue('InstallLocation')
	}

	$paths = [pscustomobject]@{
		Server    = ''
		ClickOnce = ''
		Connector = ''
		Console = ''
		InstallLocation = ''
		MRDeploy  = ''
		ApplicationService = ''
		ApplicationServiceConnectionsConfig = ''
		ApplicationServiceSettingsConfig = ''
		ServicesConnectionsConfig = ''
		ServicesSettingsConfig = ''
		Services = ''
	}

	$paths.InstallLocation = $mrInstallLocation
	$paths.Server = Join-Path -Path $paths.InstallLocation -ChildPath 'Server'
	$paths.Services = Join-Path -Path $paths.Server -ChildPath 'Services'
	$paths.ApplicationService = Join-Path -Path $paths.Server -ChildPath 'ApplicationService'
	$paths.ClickOnce = Join-Path -Path $paths.Server -ChildPath 'ClickOnceClient'
	$paths.Connector = Join-Path -Path $paths.Server -ChildPath 'Connector'
	$paths.Console = Join-Path -Path $paths.Server -ChildPath 'Console'
	$paths.MRDeploy = Join-Path -Path $paths.Server -ChildPath 'MRDeploy'
	$paths.ApplicationServiceConnectionsConfig = Join-Path -Path $paths.ApplicationService -ChildPath 'bin\MRServiceHost.connections.config'
	$paths.ApplicationServiceSettingsConfig = Join-Path -Path $paths.ApplicationService -ChildPath 'bin\MRServiceHost.settings.config'
	$paths.ServicesConnectionsConfig = Join-Path -Path $paths.Services -ChildPath 'MRServiceHost.connections.config'
	$paths.ServicesSettingsConfig = Join-Path -Path $paths.Services -ChildPath 'MRServiceHost.settings.config'
	return $paths
}

filter Out-Log
{
	if($LogFilePath)
	{
		$fileOutput = $null
		# Teeing to a variable to prevent 'The process cannot access the file _ because it is used by another process'
		$_ | Tee-Object -Variable fileOutput | Out-Host

		if($fileOutput)
		{
			$retryOutFile = 5
			while($retryOutFile -gt 0)
			{
				try
				{
					$retryOutFile--
					$fileOutput | Out-File -FilePath $LogFilePath -Append -Force -NoClobber
					$retryOutFile = 0
				}
				catch
				{
					if($retryOutFile -eq 0)
					{
						# Write warning on last retry
						$errorMessage = $_ | Out-String
						Write-Warning $errorMessage
					}
				}
			}
		}
	}
	else
	{
		$_ | Out-Host
	}
}

function Update-DefaultValues
{
	[CmdletBinding()]
	Param
	(
		# Settings xml
		[xml]
		[ValidateNotNullOrEmpty()]
		$Settings
	)

	Set-MRDefaultValues -Settings @{
		'MRSqlServerName'=$NewMRDatabaseServerName;
		'MRDatabaseName'=$NewMRDatabaseName;
		'MRSqlUserName'=$NewMRAdminUserName;
		'MRSqlUserPassword'=$NewMRAdminUserPassword;
		'MRSqlRuntimeUserName'=$NewMRRuntimeUserName;
		'MRSqlRuntimeUserPassword'=$NewMRRuntimeUserPassword;
		'AXDatabaseName'=$NewAosDatabaseName;
		'AosSqlServerName'=$NewAosDatabaseServerName;
		'AXSqlUserName'=$NewAxAdminUserName;
		'AXSqlUserPassword'=$NewAxAdminUserPassword;
		'AXSqlRuntimeUserName'=$NewAxMRRuntimeUserName;
		'AXSqlRuntimeUserPassword'=$NewAxMRRuntimeUserPassword;
		'SqlTimeoutSeconds'=$SqlTimeoutSeconds;
		'SSDTTimeoutSeconds'=$SqlTimeoutSeconds;
	}

	Write-MRInfoMessage -Message 'Fetching data encryption and data signing certificate thumbprints.'
	$encryptionThumbprint = Get-SettingsConfigValue -SettingsXml $Settings -SettingName 'DataEncryptionCertificateThumbprint'
	$signingThumbprint = Get-DataSigningCertificateThumbprint -SettingsXml $Settings -DataEncryptionCertificateThumbprint $encryptionThumbprint
	Set-MRDefaultValues -Settings @{'DataEncryptionCertThumbprint'=$encryptionThumbprint}
	Set-MRDefaultValues -SettingName 'DataSigningCertThumbprint' -SettingValue $signingThumbprint -WarnInsteadOfError
}

function Start-Execution
{
	Write-Host "Logging can be found at $LogFilePath"
	$taskGuid = [System.Guid]::NewGuid().ToString()
	$taskMessage = 'Configure MR Database'
	Log-Event -EventType Start -message $taskMessage -guid $taskGuid

	try
	{
		$installPaths = Get-MRFilePaths
        $connectionsConfigFilePath = Get-ConnectionConfigPath -InstallPaths $installPaths
		$modulePath = $installPaths.MRDeploy
		Import-Module $modulePath

		$settingsConfigFilePath = $null
		if(!(Test-Path -Path $installPaths.ApplicationServiceConnectionsConfig))
		{
			throw 'Script can only be run on the MRApplicationService box, typically AOS.'
		}

		$settingsConfigFilePath = $installPaths.ApplicationServiceSettingsConfig

		Write-MRInfoMessage -Message 'Load settings config and update default values'
		[xml]$settingscontents = Get-Content $settingsConfigFilePath -Raw
		Update-DefaultValues -Settings $settingsContents
		$defaultValues = Get-MRDefaultValues

		Write-MRStepMessage 'Load the current connection settings'
		[System.Data.SqlClient.SqlConnectionStringBuilder] $mrDatabaseConnection = Get-DecryptedConnectionString -InstallPaths $installPaths -ConnectionsConfigFilePath $connectionsConfigFilePath
		Set-MRDefaultValues -SettingName 'MRSqlTrustServerCertConnection' -SettingValue ([string]($mrDatabaseConnection.TrustServerCertificate))
		Set-MRDefaultValues -SettingName 'MRSqlEncryptConnection' -SettingValue $mrDatabaseConnection.Encrypt
		if (-not $mrDatabaseConnection.IntegratedSecurity)
		{
			$mrDatabaseConnection."User ID" = $defaultValues.MRSqlUserName
			$mrDatabaseConnection."Password" = $defaultValues.MRSqlUserPassword
		}

		Write-MRStepMessage 'Update the connection settings in the database'
		Update-DeploymentConfig
		Update-AdapterSettings -ConnectionString $mrDatabaseConnection.ConnectionString -Settings $settingsContents
		Update-MRCompanySettings -ConnectionString $mrDatabaseConnection.ConnectionString
		Write-SchemaUserPrivileges
		$securePassword = ConvertTo-SecureString $NewMRAdminUserPassword -AsPlainText -Force
		$mrCredentials = New-Object System.Management.Automation.PSCredential -ArgumentList $NewMRAdminUserName, $securePassword
		$signingThumbprint = $null
		if ((Get-MRDefaultValueNames) -contains 'DataSigningCertThumbprint')
		{
			$signingThumbprint = $defaultValues.DataSigningCertThumbprint
		}
		else
		{
			$signingThumbprint = $defaultValues.DataEncryptionCertThumbprint
		}

		Update-ChangeTracking
		Update-UserRoles -ConnectionString $mrDatabaseConnection.ConnectionString -DataEncryptionCertificateThumbprint $defaultValues.DataEncryptionCertThumbprint -DataSigningCertificateThumbprint $signingThumbprint
		Update-IntegrationSource -ConnectionString $mrDatabaseConnection.ConnectionString
		Reset-ReportDefinitionMaps -ServerInstance $NewMRDatabaseServerName -DatabaseName $NewMRDatabaseName -Credential $mrCredentials -DataEncryptionCertificateThumbprint $defaultValues.DataEncryptionCertThumbprint -DataSigningCertificateThumbprint $signingThumbprint
	}
	catch
	{
		Write-LogMessage -Message "An error ocurred while running the script, check the event logs."
		Write-ErrorDetail -ErrorThrown $_
		throw
	}
	finally
	{
		Log-Event -EventType Stop -message $taskMessage -guid $taskGuid
		Write-MRInfoMessage 'Configure MR Database Script End'
		Remove-Module 'MRDeploy'
	}
}

Set-StrictMode -Version 3
Start-Execution *>&1 | Out-Log
# SIG # Begin signature block
# MIIjrQYJKoZIhvcNAQcCoIIjnjCCI5oCAQExDzANBglghkgBZQMEAgEFADB5Bgor
# BgEEAYI3AgEEoGswaTA0BgorBgEEAYI3AgEeMCYCAwEAAAQQH8w7YFlLCE63JNLG
# KX7zUQIBAAIBAAIBAAIBAAIBADAxMA0GCWCGSAFlAwQCAQUABCBlxB44cTXsZ+ge
# 6GJK1XQP0j5xDCqT0V2McX2grBx/G6CCDYEwggX/MIID56ADAgECAhMzAAABUZ6N
# j0Bxow5BAAAAAAFRMA0GCSqGSIb3DQEBCwUAMH4xCzAJBgNVBAYTAlVTMRMwEQYD
# VQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNy
# b3NvZnQgQ29ycG9yYXRpb24xKDAmBgNVBAMTH01pY3Jvc29mdCBDb2RlIFNpZ25p
# bmcgUENBIDIwMTEwHhcNMTkwNTAyMjEzNzQ2WhcNMjAwNTAyMjEzNzQ2WjB0MQsw
# CQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9u
# ZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMR4wHAYDVQQDExVNaWNy
# b3NvZnQgQ29ycG9yYXRpb24wggEiMA0GCSqGSIb3DQEBAQUAA4IBDwAwggEKAoIB
# AQCVWsaGaUcdNB7xVcNmdfZiVBhYFGcn8KMqxgNIvOZWNH9JYQLuhHhmJ5RWISy1
# oey3zTuxqLbkHAdmbeU8NFMo49Pv71MgIS9IG/EtqwOH7upan+lIq6NOcw5fO6Os
# +12R0Q28MzGn+3y7F2mKDnopVu0sEufy453gxz16M8bAw4+QXuv7+fR9WzRJ2CpU
# 62wQKYiFQMfew6Vh5fuPoXloN3k6+Qlz7zgcT4YRmxzx7jMVpP/uvK6sZcBxQ3Wg
# B/WkyXHgxaY19IAzLq2QiPiX2YryiR5EsYBq35BP7U15DlZtpSs2wIYTkkDBxhPJ
# IDJgowZu5GyhHdqrst3OjkSRAgMBAAGjggF+MIIBejAfBgNVHSUEGDAWBgorBgEE
# AYI3TAgBBggrBgEFBQcDAzAdBgNVHQ4EFgQUV4Iarkq57esagu6FUBb270Zijc8w
# UAYDVR0RBEkwR6RFMEMxKTAnBgNVBAsTIE1pY3Jvc29mdCBPcGVyYXRpb25zIFB1
# ZXJ0byBSaWNvMRYwFAYDVQQFEw0yMzAwMTIrNDU0MTM1MB8GA1UdIwQYMBaAFEhu
# ZOVQBdOCqhc3NyK1bajKdQKVMFQGA1UdHwRNMEswSaBHoEWGQ2h0dHA6Ly93d3cu
# bWljcm9zb2Z0LmNvbS9wa2lvcHMvY3JsL01pY0NvZFNpZ1BDQTIwMTFfMjAxMS0w
# Ny0wOC5jcmwwYQYIKwYBBQUHAQEEVTBTMFEGCCsGAQUFBzAChkVodHRwOi8vd3d3
# Lm1pY3Jvc29mdC5jb20vcGtpb3BzL2NlcnRzL01pY0NvZFNpZ1BDQTIwMTFfMjAx
# MS0wNy0wOC5jcnQwDAYDVR0TAQH/BAIwADANBgkqhkiG9w0BAQsFAAOCAgEAWg+A
# rS4Anq7KrogslIQnoMHSXUPr/RqOIhJX+32ObuY3MFvdlRElbSsSJxrRy/OCCZdS
# se+f2AqQ+F/2aYwBDmUQbeMB8n0pYLZnOPifqe78RBH2fVZsvXxyfizbHubWWoUf
# NW/FJlZlLXwJmF3BoL8E2p09K3hagwz/otcKtQ1+Q4+DaOYXWleqJrJUsnHs9UiL
# crVF0leL/Q1V5bshob2OTlZq0qzSdrMDLWdhyrUOxnZ+ojZ7UdTY4VnCuogbZ9Zs
# 9syJbg7ZUS9SVgYkowRsWv5jV4lbqTD+tG4FzhOwcRQwdb6A8zp2Nnd+s7VdCuYF
# sGgI41ucD8oxVfcAMjF9YX5N2s4mltkqnUe3/htVrnxKKDAwSYliaux2L7gKw+bD
# 1kEZ/5ozLRnJ3jjDkomTrPctokY/KaZ1qub0NUnmOKH+3xUK/plWJK8BOQYuU7gK
# YH7Yy9WSKNlP7pKj6i417+3Na/frInjnBkKRCJ/eYTvBH+s5guezpfQWtU4bNo/j
# 8Qw2vpTQ9w7flhH78Rmwd319+YTmhv7TcxDbWlyteaj4RK2wk3pY1oSz2JPE5PNu
# Nmd9Gmf6oePZgy7Ii9JLLq8SnULV7b+IP0UXRY9q+GdRjM2AEX6msZvvPCIoG0aY
# HQu9wZsKEK2jqvWi8/xdeeeSI9FN6K1w4oVQM4Mwggd6MIIFYqADAgECAgphDpDS
# AAAAAAADMA0GCSqGSIb3DQEBCwUAMIGIMQswCQYDVQQGEwJVUzETMBEGA1UECBMK
# V2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0
# IENvcnBvcmF0aW9uMTIwMAYDVQQDEylNaWNyb3NvZnQgUm9vdCBDZXJ0aWZpY2F0
# ZSBBdXRob3JpdHkgMjAxMTAeFw0xMTA3MDgyMDU5MDlaFw0yNjA3MDgyMTA5MDla
# MH4xCzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdS
# ZWRtb25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xKDAmBgNVBAMT
# H01pY3Jvc29mdCBDb2RlIFNpZ25pbmcgUENBIDIwMTEwggIiMA0GCSqGSIb3DQEB
# AQUAA4ICDwAwggIKAoICAQCr8PpyEBwurdhuqoIQTTS68rZYIZ9CGypr6VpQqrgG
# OBoESbp/wwwe3TdrxhLYC/A4wpkGsMg51QEUMULTiQ15ZId+lGAkbK+eSZzpaF7S
# 35tTsgosw6/ZqSuuegmv15ZZymAaBelmdugyUiYSL+erCFDPs0S3XdjELgN1q2jz
# y23zOlyhFvRGuuA4ZKxuZDV4pqBjDy3TQJP4494HDdVceaVJKecNvqATd76UPe/7
# 4ytaEB9NViiienLgEjq3SV7Y7e1DkYPZe7J7hhvZPrGMXeiJT4Qa8qEvWeSQOy2u
# M1jFtz7+MtOzAz2xsq+SOH7SnYAs9U5WkSE1JcM5bmR/U7qcD60ZI4TL9LoDho33
# X/DQUr+MlIe8wCF0JV8YKLbMJyg4JZg5SjbPfLGSrhwjp6lm7GEfauEoSZ1fiOIl
# XdMhSz5SxLVXPyQD8NF6Wy/VI+NwXQ9RRnez+ADhvKwCgl/bwBWzvRvUVUvnOaEP
# 6SNJvBi4RHxF5MHDcnrgcuck379GmcXvwhxX24ON7E1JMKerjt/sW5+v/N2wZuLB
# l4F77dbtS+dJKacTKKanfWeA5opieF+yL4TXV5xcv3coKPHtbcMojyyPQDdPweGF
# RInECUzF1KVDL3SV9274eCBYLBNdYJWaPk8zhNqwiBfenk70lrC8RqBsmNLg1oiM
# CwIDAQABo4IB7TCCAekwEAYJKwYBBAGCNxUBBAMCAQAwHQYDVR0OBBYEFEhuZOVQ
# BdOCqhc3NyK1bajKdQKVMBkGCSsGAQQBgjcUAgQMHgoAUwB1AGIAQwBBMAsGA1Ud
# DwQEAwIBhjAPBgNVHRMBAf8EBTADAQH/MB8GA1UdIwQYMBaAFHItOgIxkEO5FAVO
# 4eqnxzHRI4k0MFoGA1UdHwRTMFEwT6BNoEuGSWh0dHA6Ly9jcmwubWljcm9zb2Z0
# LmNvbS9wa2kvY3JsL3Byb2R1Y3RzL01pY1Jvb0NlckF1dDIwMTFfMjAxMV8wM18y
# Mi5jcmwwXgYIKwYBBQUHAQEEUjBQME4GCCsGAQUFBzAChkJodHRwOi8vd3d3Lm1p
# Y3Jvc29mdC5jb20vcGtpL2NlcnRzL01pY1Jvb0NlckF1dDIwMTFfMjAxMV8wM18y
# Mi5jcnQwgZ8GA1UdIASBlzCBlDCBkQYJKwYBBAGCNy4DMIGDMD8GCCsGAQUFBwIB
# FjNodHRwOi8vd3d3Lm1pY3Jvc29mdC5jb20vcGtpb3BzL2RvY3MvcHJpbWFyeWNw
# cy5odG0wQAYIKwYBBQUHAgIwNB4yIB0ATABlAGcAYQBsAF8AcABvAGwAaQBjAHkA
# XwBzAHQAYQB0AGUAbQBlAG4AdAAuIB0wDQYJKoZIhvcNAQELBQADggIBAGfyhqWY
# 4FR5Gi7T2HRnIpsLlhHhY5KZQpZ90nkMkMFlXy4sPvjDctFtg/6+P+gKyju/R6mj
# 82nbY78iNaWXXWWEkH2LRlBV2AySfNIaSxzzPEKLUtCw/WvjPgcuKZvmPRul1LUd
# d5Q54ulkyUQ9eHoj8xN9ppB0g430yyYCRirCihC7pKkFDJvtaPpoLpWgKj8qa1hJ
# Yx8JaW5amJbkg/TAj/NGK978O9C9Ne9uJa7lryft0N3zDq+ZKJeYTQ49C/IIidYf
# wzIY4vDFLc5bnrRJOQrGCsLGra7lstnbFYhRRVg4MnEnGn+x9Cf43iw6IGmYslmJ
# aG5vp7d0w0AFBqYBKig+gj8TTWYLwLNN9eGPfxxvFX1Fp3blQCplo8NdUmKGwx1j
# NpeG39rz+PIWoZon4c2ll9DuXWNB41sHnIc+BncG0QaxdR8UvmFhtfDcxhsEvt9B
# xw4o7t5lL+yX9qFcltgA1qFGvVnzl6UJS0gQmYAf0AApxbGbpT9Fdx41xtKiop96
# eiL6SJUfq/tHI4D1nvi/a7dLl+LrdXga7Oo3mXkYS//WsyNodeav+vyL6wuA6mk7
# r/ww7QRMjt/fdW1jkT3RnVZOT7+AVyKheBEyIXrvQQqxP/uozKRdwaGIm1dxVk5I
# RcBCyZt2WwqASGv9eZ/BvW1taslScxMNelDNMYIVgjCCFX4CAQEwgZUwfjELMAkG
# A1UEBhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQx
# HjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEoMCYGA1UEAxMfTWljcm9z
# b2Z0IENvZGUgU2lnbmluZyBQQ0EgMjAxMQITMwAAAVGejY9AcaMOQQAAAAABUTAN
# BglghkgBZQMEAgEFAKCB2DAZBgkqhkiG9w0BCQMxDAYKKwYBBAGCNwIBBDAcBgor
# BgEEAYI3AgELMQ4wDAYKKwYBBAGCNwIBFTAvBgkqhkiG9w0BCQQxIgQgQLFutyVj
# nE6xe5H+hvc6RHkKlTrTLOBwsxHpn+KX4wcwbAYKKwYBBAGCNwIBDDFeMFygPoA8
# AEEAcABwAGwAeQBSAGUAdABhAGkAbABEAEIAUwBjAHIAaQBwAHQASQBuAFMAUQBM
# AFMAVQAuAHAAcwAxoRqAGGh0dHA6Ly93d3cubWljcm9zb2Z0LmNvbTANBgkqhkiG
# 9w0BAQEFAASCAQBWQJ/ywdnF+2hMfZm7AUg95i1boZJRHHPMkrCPjg4AyrWm+TaF
# kB7DF/cZwDCdrjGKblYhIbSsgkVrX7E4X4ib5hWgrQXikpS/CMaP5c4nO5iiDpM0
# xOe/o0KlwZwiJC2auYgXY56MfLFcLdFxVV1ao3fh3u774cqRh1Gg/YBJblyi4n1R
# +ub47hqV77zYHO3MyOQNZDTuxdSzAMQECs/ERmvX/68AWM46SUEEs226bWbE2H32
# 0OFNE4x6/BpXD3sEiXcmEFgjDb2d1aUNav3Mxx1A3XuPVeI2hfUoM7JMQk5GHXLh
# KRLh9/pX9HGKh2kelcghZD/MFNPjDFo/8x0NoYIS4jCCEt4GCisGAQQBgjcDAwEx
# ghLOMIISygYJKoZIhvcNAQcCoIISuzCCErcCAQMxDzANBglghkgBZQMEAgEFADCC
# AVEGCyqGSIb3DQEJEAEEoIIBQASCATwwggE4AgEBBgorBgEEAYRZCgMBMDEwDQYJ
# YIZIAWUDBAIBBQAEIMNnfpgZT2d7S+BpsO/mvSXuLntXHAUDRr3cRWVHkQ27AgZd
# Xbd3TFkYEzIwMTkwOTE3MTkyMTAwLjA5NlowBIACAfSggdCkgc0wgcoxCzAJBgNV
# BAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4w
# HAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xJTAjBgNVBAsTHE1pY3Jvc29m
# dCBBbWVyaWNhIE9wZXJhdGlvbnMxJjAkBgNVBAsTHVRoYWxlcyBUU1MgRVNOOjIy
# NjQtRTMzRS03ODBDMSUwIwYDVQQDExxNaWNyb3NvZnQgVGltZS1TdGFtcCBTZXJ2
# aWNloIIOOTCCBPEwggPZoAMCAQICEzMAAADvTPJq2ssEnSwAAAAAAO8wDQYJKoZI
# hvcNAQELBQAwfDELMAkGA1UEBhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAO
# BgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEm
# MCQGA1UEAxMdTWljcm9zb2Z0IFRpbWUtU3RhbXAgUENBIDIwMTAwHhcNMTgxMDI0
# MjExNDE2WhcNMjAwMTEwMjExNDE2WjCByjELMAkGA1UEBhMCVVMxEzARBgNVBAgT
# Cldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29m
# dCBDb3Jwb3JhdGlvbjElMCMGA1UECxMcTWljcm9zb2Z0IEFtZXJpY2EgT3BlcmF0
# aW9uczEmMCQGA1UECxMdVGhhbGVzIFRTUyBFU046MjI2NC1FMzNFLTc4MEMxJTAj
# BgNVBAMTHE1pY3Jvc29mdCBUaW1lLVN0YW1wIFNlcnZpY2UwggEiMA0GCSqGSIb3
# DQEBAQUAA4IBDwAwggEKAoIBAQC1OGyDlNGBwjomVJrEi9QmI+PF8k1u2KLCjioc
# NRIwURHMx4Pi/2sKIJ/jgjGh0isFP0BXUdKp8IYH/9bg2mlupq7AvMuBRkOyPMaj
# TMieY8fl+2e7X5RRHsC+TpWQ8/6KTRL3WWCgKtm+JJPOxqiMFfAXgweee6XD3l7n
# 6VKdnnRwHFYr8sT4X1sY/DTXuz4hc8Hs2RTgy8YdN0nEdD51DV6xaC2IgkeBQxNx
# rWlN9uMuUah9GY4iNeNP+J1rVi2H0ZTD5kpwvAlM2RRupjCe+oCTLJbOkMPC4aP5
# S2hSiJ9TPVPhMssit1uuaeeGMGbkVyP7KuJS4vHx9gWYr14JAgMBAAGjggEbMIIB
# FzAdBgNVHQ4EFgQUTGQrSjM4PMd3ZBkTCkSYhPZNKS0wHwYDVR0jBBgwFoAU1WM6
# XIoxkPNDe3xGG8UzaFqFbVUwVgYDVR0fBE8wTTBLoEmgR4ZFaHR0cDovL2NybC5t
# aWNyb3NvZnQuY29tL3BraS9jcmwvcHJvZHVjdHMvTWljVGltU3RhUENBXzIwMTAt
# MDctMDEuY3JsMFoGCCsGAQUFBwEBBE4wTDBKBggrBgEFBQcwAoY+aHR0cDovL3d3
# dy5taWNyb3NvZnQuY29tL3BraS9jZXJ0cy9NaWNUaW1TdGFQQ0FfMjAxMC0wNy0w
# MS5jcnQwDAYDVR0TAQH/BAIwADATBgNVHSUEDDAKBggrBgEFBQcDCDANBgkqhkiG
# 9w0BAQsFAAOCAQEAdb/GQr7owKPezpR4YRqsePnedCshIdIZ6uoSa2acLliawqJ6
# kSxA7eZMeMslpxUWjDlq2M9ALpnWQ4tA2wnOqA0w0EwyDAWP4auUqN4M56HyPdxc
# DVOo9raNLFQLAd1lH5ZyaMfTfgrHtNU7kKyt6TeBcr1fO7QtUdWLw/50QSDX6xBm
# 7jSKnft3xFC53fcy3xUfYBRvvxuuiJgdN/pYJALeS4yXdF7GxK6YLvFMm0EZDj5b
# 0Osd7qkzsdfsPi5YV/l4lqMzinjehoaQs2sCKT97tV7UjnZ0B9rHc6fUHD6Uq5A5
# 37z1oXh1I6LcoYeGc6MNigpLBPaSo+JmK4RqoTCCBnEwggRZoAMCAQICCmEJgSoA
# AAAAAAIwDQYJKoZIhvcNAQELBQAwgYgxCzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpX
# YXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNyb3NvZnQg
# Q29ycG9yYXRpb24xMjAwBgNVBAMTKU1pY3Jvc29mdCBSb290IENlcnRpZmljYXRl
# IEF1dGhvcml0eSAyMDEwMB4XDTEwMDcwMTIxMzY1NVoXDTI1MDcwMTIxNDY1NVow
# fDELMAkGA1UEBhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1Jl
# ZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEmMCQGA1UEAxMd
# TWljcm9zb2Z0IFRpbWUtU3RhbXAgUENBIDIwMTAwggEiMA0GCSqGSIb3DQEBAQUA
# A4IBDwAwggEKAoIBAQCpHQ28dxGKOiDs/BOX9fp/aZRrdFQQ1aUKAIKF++18aEss
# X8XD5WHCdrc+Zitb8BVTJwQxH0EbGpUdzgkTjnxhMFmxMEQP8WCIhFRDDNdNuDgI
# s0Ldk6zWczBXJoKjRQ3Q6vVHgc2/JGAyWGBG8lhHhjKEHnRhZ5FfgVSxz5NMksHE
# pl3RYRNuKMYa+YaAu99h/EbBJx0kZxJyGiGKr0tkiVBisV39dx898Fd1rL2KQk1A
# UdEPnAY+Z3/1ZsADlkR+79BL/W7lmsqxqPJ6Kgox8NpOBpG2iAg16HgcsOmZzTzn
# L0S6p/TcZL2kAcEgCZN4zfy8wMlEXV4WnAEFTyJNAgMBAAGjggHmMIIB4jAQBgkr
# BgEEAYI3FQEEAwIBADAdBgNVHQ4EFgQU1WM6XIoxkPNDe3xGG8UzaFqFbVUwGQYJ
# KwYBBAGCNxQCBAweCgBTAHUAYgBDAEEwCwYDVR0PBAQDAgGGMA8GA1UdEwEB/wQF
# MAMBAf8wHwYDVR0jBBgwFoAU1fZWy4/oolxiaNE9lJBb186aGMQwVgYDVR0fBE8w
# TTBLoEmgR4ZFaHR0cDovL2NybC5taWNyb3NvZnQuY29tL3BraS9jcmwvcHJvZHVj
# dHMvTWljUm9vQ2VyQXV0XzIwMTAtMDYtMjMuY3JsMFoGCCsGAQUFBwEBBE4wTDBK
# BggrBgEFBQcwAoY+aHR0cDovL3d3dy5taWNyb3NvZnQuY29tL3BraS9jZXJ0cy9N
# aWNSb29DZXJBdXRfMjAxMC0wNi0yMy5jcnQwgaAGA1UdIAEB/wSBlTCBkjCBjwYJ
# KwYBBAGCNy4DMIGBMD0GCCsGAQUFBwIBFjFodHRwOi8vd3d3Lm1pY3Jvc29mdC5j
# b20vUEtJL2RvY3MvQ1BTL2RlZmF1bHQuaHRtMEAGCCsGAQUFBwICMDQeMiAdAEwA
# ZQBnAGEAbABfAFAAbwBsAGkAYwB5AF8AUwB0AGEAdABlAG0AZQBuAHQALiAdMA0G
# CSqGSIb3DQEBCwUAA4ICAQAH5ohRDeLG4Jg/gXEDPZ2joSFvs+umzPUxvs8F4qn+
# +ldtGTCzwsVmyWrf9efweL3HqJ4l4/m87WtUVwgrUYJEEvu5U4zM9GASinbMQEBB
# m9xcF/9c+V4XNZgkVkt070IQyK+/f8Z/8jd9Wj8c8pl5SpFSAK84Dxf1L3mBZdmp
# tWvkx872ynoAb0swRCQiPM/tA6WWj1kpvLb9BOFwnzJKJ/1Vry/+tuWOM7tiX5rb
# V0Dp8c6ZZpCM/2pif93FSguRJuI57BlKcWOdeyFtw5yjojz6f32WapB4pm3S4Zz5
# Hfw42JT0xqUKloakvZ4argRCg7i1gJsiOCC1JeVk7Pf0v35jWSUPei45V3aicaoG
# ig+JFrphpxHLmtgOR5qAxdDNp9DvfYPw4TtxCd9ddJgiCGHasFAeb73x4QDf5zEH
# pJM692VHeOj4qEir995yfmFrb3epgcunCaw5u+zGy9iCtHLNHfS4hQEegPsbiSpU
# ObJb2sgNVZl6h3M7COaYLeqN4DMuEin1wC9UJyH3yKxO2ii4sanblrKnQqLJzxlB
# TeCG+SqaoxFmMNO7dDJL32N79ZmKLxvHIa9Zta7cRDyXUHHXodLFVeNp3lfB0d4w
# wP3M5k37Db9dT+mdHhk4L7zPWAUu7w2gUDXa7wknHNWzfjUeCLraNtvTX4/edIhJ
# EqGCAsswggI0AgEBMIH4oYHQpIHNMIHKMQswCQYDVQQGEwJVUzETMBEGA1UECBMK
# V2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0
# IENvcnBvcmF0aW9uMSUwIwYDVQQLExxNaWNyb3NvZnQgQW1lcmljYSBPcGVyYXRp
# b25zMSYwJAYDVQQLEx1UaGFsZXMgVFNTIEVTTjoyMjY0LUUzM0UtNzgwQzElMCMG
# A1UEAxMcTWljcm9zb2Z0IFRpbWUtU3RhbXAgU2VydmljZaIjCgEBMAcGBSsOAwIa
# AxUAJaUg4C3nylyCiC/Q0S10vrXOIV2ggYMwgYCkfjB8MQswCQYDVQQGEwJVUzET
# MBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UEChMV
# TWljcm9zb2Z0IENvcnBvcmF0aW9uMSYwJAYDVQQDEx1NaWNyb3NvZnQgVGltZS1T
# dGFtcCBQQ0EgMjAxMDANBgkqhkiG9w0BAQUFAAIFAOErJS8wIhgPMjAxOTA5MTcx
# NzI2MDdaGA8yMDE5MDkxODE3MjYwN1owdDA6BgorBgEEAYRZCgQBMSwwKjAKAgUA
# 4SslLwIBADAHAgEAAgIM/jAHAgEAAgIRfDAKAgUA4Sx2rwIBADA2BgorBgEEAYRZ
# CgQCMSgwJjAMBgorBgEEAYRZCgMCoAowCAIBAAIDB6EgoQowCAIBAAIDAYagMA0G
# CSqGSIb3DQEBBQUAA4GBAICvjNizyp6q+0KudfjKZh+9G/K4gSGnQP8sD99SZNJf
# VsuaJr6HHAb4jJnsH0G/qeo7S1ChsaH0eorMzPpl49zWkDWVCvyusaKU5H4ME3/c
# ikBeofdDhsXIilwnDTqvzvaKFpPoBybJ4VpfVHrmiKRFq/GdJjRlE8nqbUPtDdsh
# MYIDDTCCAwkCAQEwgZMwfDELMAkGA1UEBhMCVVMxEzARBgNVBAgTCldhc2hpbmd0
# b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3Jh
# dGlvbjEmMCQGA1UEAxMdTWljcm9zb2Z0IFRpbWUtU3RhbXAgUENBIDIwMTACEzMA
# AADvTPJq2ssEnSwAAAAAAO8wDQYJYIZIAWUDBAIBBQCgggFKMBoGCSqGSIb3DQEJ
# AzENBgsqhkiG9w0BCRABBDAvBgkqhkiG9w0BCQQxIgQgaICn2M+oyiRFPdChg2l+
# eGTTTKtM+tHiFIozA8y5Ti0wgfoGCyqGSIb3DQEJEAIvMYHqMIHnMIHkMIG9BCCg
# SeqlVZI1WeamrpyUp7YrS49qricKTpYhMLEE3+55ujCBmDCBgKR+MHwxCzAJBgNV
# BAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4w
# HAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xJjAkBgNVBAMTHU1pY3Jvc29m
# dCBUaW1lLVN0YW1wIFBDQSAyMDEwAhMzAAAA70zyatrLBJ0sAAAAAADvMCIEILhq
# iUnLUDBcrh4OxCOOWpvQOOJIR1AbgFnI4TaG5cABMA0GCSqGSIb3DQEBCwUABIIB
# AE0wUXhfDJAaYQf18gNwPkWL1eK7Ys9XHUYDObs5yu15aWx7CwlA/Yk6QksuJP8V
# TkVLSREhzsWJ1xk0TZI8FmGSy5uN+ARtRAgqLWNA2NihkJmd1OY5NTsqDMCnIZir
# mmm//hGrP2CKHGV7XYXc/k1BkgRQPAJzlAaaSyODMZ6n/IyKtyqj0Yi3D0invPhs
# Oz8tyCG4ssvzc2F9349fMk+zmJy274nfnmLOsCjfNWDkcprgAnE5CLFSufI+S1ec
# EtUYAsR8HHpfGu9PQ1+bmqlnsq9UxxXJdcLNgvN1bcIo3Byjxm4Qt11NJRnSCLs2
# zvBrQb7roPzmZBsA6T15fN4=
# SIG # End signature block
