<#
.Synopsis
Job that runs the required steps to configure a hotfix or update
#>
[CmdletBinding()]
Param
(
	# Directory to place logs. Passed in when upgrade is triggered through LCS.
	[string]
	$LogDir,

	# SQL command timeout, override this to cause a shorter timeout
	[int]
	[ValidateRange(0,[int]::MaxValue)]
	$SqlTimeoutSeconds = 6600
)

# Determine the current folder, $PSScriptRoot and $PSCommandPath do not give the same results when executed in the runbook
$script:currentFolder = (Get-ChildItem -Path (Split-Path -Path $PSScriptRoot -Parent) -Recurse -Filter JobAutoGlobalUpdateMR.ps1 | Select-Object -First 1).Directory.FullName
$commonUpgradeFunctionsPath = Join-Path -Path $script:currentFolder -ChildPath "CommonMRUpgradeFunctions.ps1"
$commonUpgradeFunctionsPath = Resolve-Path -Path $commonUpgradeFunctionsPath
. "$commonUpgradeFunctionsPath"

if (!$LogDir)
{
	$LogDir = Get-LogPath -ResolvedRunbookLogFolder '$RunbookLogFolder'
}

Set-LogPath -LogDir $LogDir -LogFileName 'JobAutoGlobalUpdateMR'
Write-EnvironmentDataToLog


function Update-GraphApiAdapterSettings
{
	[CmdletBinding()]
	Param
	(
		[string]
		[ValidateNotNullOrEmpty()]
		$ConnectionString,

		# Application config settings in xml format
		[xml]
		$ConfigSettingsContents
	)

	Write-LogMessage -Message "Updating AX adapter settings related to GraphAPI"

	$GraphApplicationId = (Get-SettingsConfigValue -SettingsXml $ConfigSettingsContents -SettingName 'GraphApplicationId')
	$GraphAadInstance = (Get-SettingsConfigValue -SettingsXml $ConfigSettingsContents -SettingName 'GraphAADInstance')
	$GraphTenantId = (Get-SettingsConfigValue -SettingsXml $ConfigSettingsContents -SettingName 'GraphTenantId')
	$GraphCertThumbprint = (Get-SettingsConfigValue -SettingsXml $ConfigSettingsContents -SettingName 'GraphCertThumbprint')
	$GraphResource = (Get-SettingsConfigValue -SettingsXml $ConfigSettingsContents -SettingName 'GraphResource')

	# If none of the graphAPI setting existed in the config settings, then this is not a 7.2 install
	# Skip writing the graphAPI adapter settings in that case
	if( [string]::IsNullOrEmpty($GraphApplicationId) -and
		[string]::IsNullOrEmpty($GraphAadInstance) -and
		[string]::IsNullOrEmpty($GraphTenantId) -and
		[string]::IsNullOrEmpty($GraphCertThumbprint) -and
		[string]::IsNullOrEmpty($GraphResource))
	{
		Write-LogMessage -Message "No GraphAPI settings found, skipping update of related adapter settings."
		return
	}

$graphApiQuery = @"
-- Insert AAD Group API related settings
IF NOT EXISTS (SELECT * from [Connector].[MapCategoryAdapterSettings] where AdapterId = 'E3E10D70-FDAB-480C-952E-8397524F9236' AND 
cast (Settings as xml).exist('declare namespace DI="http://www.microsoft.com/2009/Dynamics/Integration"; /SettingsCollection/DI:ArrayOfSettingsValue/DI:SettingsValue[DI:FieldDefinition/@Name="GraphApplicationId"]') = 1 )
BEGIN
	Update [Connector].[MapCategoryAdapterSettings] SET
	Settings.modify('
	declare namespace DI="http://www.microsoft.com/2009/Dynamics/Integration";
	insert <DI:SettingsValue><DI:FieldDefinition Name="GraphApplicationId" TypeName="string" DisplayName="Azure AD GRAPH API client Id " Description="Azure AD GRAPH API client Id " IsRequired="false" IsReadOnly="false" /><DI:Attributes /><DI:Value>$GraphApplicationId</DI:Value></DI:SettingsValue>
	into (/SettingsCollection/DI:ArrayOfSettingsValue)[1]')
	where AdapterId = 'E3E10D70-FDAB-480C-952E-8397524F9236'

	Update [Connector].[MapCategoryAdapterSettings] SET
	Settings.modify('
	declare namespace DI="http://www.microsoft.com/2009/Dynamics/Integration";
	insert <DI:SettingsValue><DI:FieldDefinition Name="GraphTenantId" TypeName="string" DisplayName="Azure AD GRAPH API tenant Id" Description="Azure AD GRAPH API tenant Id" IsRequired="false" IsReadOnly="false" /><DI:Attributes /><DI:Value>$GraphTenantId</DI:Value></DI:SettingsValue>
	into (/SettingsCollection/DI:ArrayOfSettingsValue)[1]')
	where AdapterId = 'E3E10D70-FDAB-480C-952E-8397524F9236'

	Update [Connector].[MapCategoryAdapterSettings] SET
	Settings.modify('
	declare namespace DI="http://www.microsoft.com/2009/Dynamics/Integration";
	insert <DI:SettingsValue><DI:FieldDefinition Name="GraphAADInstance" TypeName="string" DisplayName="Azure AD GRAPH API AAD instance Id" Description="Azure AD GRAPH API AAD instance Id" IsRequired="false" IsReadOnly="false" /><DI:Attributes /><DI:Value>$GraphAadInstance</DI:Value></DI:SettingsValue>
	into (/SettingsCollection/DI:ArrayOfSettingsValue)[1]')
	where AdapterId = 'E3E10D70-FDAB-480C-952E-8397524F9236'

	Update [Connector].[MapCategoryAdapterSettings] SET
	Settings.modify('
	declare namespace DI="http://www.microsoft.com/2009/Dynamics/Integration";
	insert <DI:SettingsValue><DI:FieldDefinition Name="GraphCertThumbprint" TypeName="string" DisplayName="Azure AD GRAPH API authentication certificate thumbprint" Description="Azure AD GRAPH API authentication certificate thumbprint" IsRequired="false" IsReadOnly="false" /><DI:Attributes /><DI:Value>$GraphCertThumbprint</DI:Value></DI:SettingsValue>
	into (/SettingsCollection/DI:ArrayOfSettingsValue)[1]')
	where AdapterId = 'E3E10D70-FDAB-480C-952E-8397524F9236'

	Update [Connector].[MapCategoryAdapterSettings] SET
	Settings.modify('
	declare namespace DI="http://www.microsoft.com/2009/Dynamics/Integration";
	insert <DI:SettingsValue><DI:FieldDefinition Name="GraphResource" TypeName="string" DisplayName="Azure AD GRAPH API resource URI value" Description="Azure AD GRAPH API resource URI value" IsRequired="false" IsReadOnly="false" /><DI:Attributes /><DI:Value>$GraphResource</DI:Value></DI:SettingsValue>
	into (/SettingsCollection/DI:ArrayOfSettingsValue)[1]')
	where AdapterId = 'E3E10D70-FDAB-480C-952E-8397524F9236'
END
ELSE
BEGIN
	Update [Connector].[MapCategoryAdapterSettings] SET
	Settings.modify('
	declare namespace DI="http://www.microsoft.com/2009/Dynamics/Integration";
	replace value of (/SettingsCollection/DI:ArrayOfSettingsValue/DI:SettingsValue[DI:FieldDefinition/@Name=("GraphResource")]/DI:Value/text())[1] with ("$GraphResource")')
	where AdapterId = 'E3E10D70-FDAB-480C-952E-8397524F9236'
END
"@

	Invoke-SqlQuery -ConnectionString $ConnectionString -Query $graphApiQuery -ResultReader (Get-ExecuteNonQueryReader)

	Write-LogMessage -Message "Completed updating the GraphAPI adapter settings."
}

function Update-AdapterSettings
{
	[CmdletBinding()]
	Param
	(
		# SQL server instance name.
		[Parameter(ValueFromPipelineByPropertyName = $true,Position = 0)]
		[string]
		[ValidateNotNullOrEmpty()]
		$ServerInstance,

		 # Database name.
		[Parameter(ValueFromPipelineByPropertyName = $true,Position = 1)]
		[string]
		[ValidateNotNullOrEmpty()]
		$DatabaseName,

		# SQL credential.
		[Parameter(ValueFromPipelineByPropertyName = $true,Position = 2)]
		[pscredential]
		$Credential,

		# Application config settings in xml format
		[Parameter(ValueFromPipelineByPropertyName = $true,Position = 3)]
		[xml]
		$ConfigSettingsContents
	)

	#Check if the current machine is AOS
	if(Test-Path -Path $installPaths.ApplicationServiceSettingsConfig )
	{
		Write-LogMessage -Message "Updating AX adapter setting stored in database $DatabaseName"
		$CertUserName = (Get-MRDefaultValues).AXCertUserName
		$ProviderName = (Get-MRDefaultValues).AXSTSProviderName

		# Excute SQL query to update AX adapter setting value
		$query = @"
Update [Connector].[MapCategoryAdapterSettings] SET 
Settings.modify('
	declare namespace DI="http://www.microsoft.com/2009/Dynamics/Integration";
	replace value of (/SettingsCollection/DI:ArrayOfSettingsValue/DI:SettingsValue[DI:FieldDefinition/@Name=("CertUserName")]/DI:Value/text())[1] with ("$CertUserName")
')
where AdapterId = 'E3E10D70-FDAB-480C-952E-8397524F9236'

Update [Connector].[MapCategoryAdapterSettings] SET
Settings.modify('
	declare namespace DI="http://www.microsoft.com/2009/Dynamics/Integration";
	replace value of (/SettingsCollection/DI:ArrayOfSettingsValue/DI:SettingsValue[DI:FieldDefinition/@Name=("ProviderName")]/DI:Value/text())[1] with ("$ProviderName")
')
where AdapterId = 'E3E10D70-FDAB-480C-952E-8397524F9236'

-- Remove the 'IsAX7Integration' setting from the MR Connector.Adapter and Connector.MapCategoryAdapterSettings
UPDATE Connector.Adapter
set Settings.modify('
	declare namespace DI="http://www.microsoft.com/2009/Dynamics/Integration";
	delete(/SettingsCollection/DI:ArrayOfSettingsValue/DI:SettingsValue[DI:FieldDefinition/@Name="IsAX7Integration"])
')
where Id = '492252C3-A2E5-48B1-84DD-277402F97930'

UPDATE Connector.MapCategoryAdapterSettings
set Settings.modify('
	declare namespace DI="http://www.microsoft.com/2009/Dynamics/Integration";
	delete(/SettingsCollection/DI:ArrayOfSettingsValue/DI:SettingsValue[DI:FieldDefinition/@Name="IsAX7Integration"])
	')
where AdapterId = '492252C3-A2E5-48B1-84DD-277402F97930'
"@

		$connectionString = Get-ConnectionString -Server $ServerInstance -Database $DatabaseName -Credential $Credential
		Invoke-SqlQuery -ConnectionString $connectionString -Query $query -ResultReader (Get-ExecuteNonQueryReader)
		Update-GraphApiAdapterSettings -ConnectionString $connectionString -ConfigSettingsContents $ConfigSettingsContents
		Write-LogMessage -Message "Completed updating AX adapter setting"
	}
}

function Update-PreDatabaseUpgrade
{
	[CmdletBinding()]
	Param
	(
		# SQL server instance name.
		[Parameter(ValueFromPipelineByPropertyName = $true,Position = 0)]
		[string]
		[ValidateNotNullOrEmpty()]
		$ServerInstance,

		 # Database name.
		[Parameter(ValueFromPipelineByPropertyName = $true,Position = 1)]
		[string]
		[ValidateNotNullOrEmpty()]
		$DatabaseName,

		# SQL credential.
		[Parameter(ValueFromPipelineByPropertyName = $true,Position = 2)]
		[pscredential]
		$Credential
	)

	#Check if the current machine is AOS
	if(Test-Path -Path $installPaths.ApplicationServiceSettingsConfig )
	{
		Write-LogMessage -Message 'Starting Pre-Database-Update actions.'
		$dllPath = Join-Path -Path  (Get-MRFilePaths).Server -ChildPath 'Console\Microsoft.Dynamics.Performance.Deployment.Database.dll'
		$assembly = [System.Reflection.Assembly]::LoadFile($dllPath)
		$pda = $assembly.GetTypes() | Where-Object { $_.name -eq 'PreDeploymentActions' }
		if(-not $pda)
		{
			Write-LogMessage -Message 'PreDeploymentActions class not found, skipping pre-database-update action.'
			return
		}

		if(-not ($pda.GetFields() | Where-Object { $_.name -eq 'DropUnnamedConstraintQuery' }))
		{
			Write-LogMessage -Message 'DropUnnamedConstraintQuery field not found, skipping pre-database-update action.'
			return
		}

		Add-Type -Path $dllPath
		$query = [Microsoft.Dynamics.Performance.Deployment.Database.PreDeploymentActions]::DropUnnamedConstraintQuery
		$connectionString = Get-ConnectionString -Server $ServerInstance -Database $DatabaseName -Credential $Credential
		Invoke-SqlQuery -ConnectionString $connectionString -Query $query -ResultReader (Get-ExecuteNonQueryReader)
		Write-LogMessage -Message 'Completed Pre-Database-Update actions.'
	}
}

function Do-DatamartResetIfNecessary
{
	[CmdletBinding()]
	Param
	(
		# Connection string to the MR database.
		[string]
		[ValidateNotNullOrEmpty()]
		$ConnectionString
    )

    Write-LogMessage -Message "Checking if Datamart reset is required."
    Write-LogMessage -Message "Checking SQL Azure Edition for Financial Reporting database"
    $commandTimeout = 120
    $databaseTierQuery = "SELECT DATABASEPROPERTYEX(DB_NAME(), 'Edition')"
    $databaseTier = Invoke-SqlQuery -ConnectionString $ConnectionString -CommandTimeout $commandTimeout -Query $databaseTierQuery -ResultReader (Get-ExecuteScalarReader)

    if([string]::IsNullOrEmpty($databaseTier) -or $databaseTier -ne 'Standard')
    {
        Write-LogMessage -Message "Datamart reset is not required."
        return
    }

    $isMRInUseQuery = "SELECT count(*) FROM [Reporting].[Report]"
    $isMRInUse = Invoke-SqlQuery -ConnectionString $ConnectionString -CommandTimeout $commandTimeout  -Query $isMRInUseQuery -ResultReader (Get-ExecuteScalarReader) 
    if($isMRInUse -eq 0)
    {
        $commandTimeoutInSeconds = 600
        $schemaQuery = @"
                SELECT * FROM ( 
                    SELECT 
                        SCHEMA_NAME([o].[schema_id])    AS [SchemaName],
                        [si].[object_id]                AS [ColumnSourceId],
                        [o].[name]                      AS [ColumnSourceName],
                        [o].[type]                      AS [ColumnSourceType],
                        [ic].[column_id]                AS [ColumnId],
                        [c].[name]                      AS [ColumnName],
                        [si].[index_id]                 AS [IndexId],
                        [si].[name]                     AS [IndexName],
                        [ds].[type]                     AS [DataspaceType],
                        [ds].[data_space_id]            AS [DataspaceId],
                        [ds].[name]                     AS [DataspaceName],
                        [si].[fill_factor]              AS [FillFactor],
                        [si].[is_padded]                AS [IsPadded],
                        [si].[is_disabled]              AS [IsDisabled],
                        [si].[allow_page_locks]         AS [DoAllowPageLocks],
                        [si].[allow_row_locks]          AS [DoAllowRowLocks],
                        [sit].[cells_per_object]        AS [CellsPerObject],
                        [sit].[bounding_box_xmin]       AS [XMin],
                        [sit].[bounding_box_xmax]       AS [XMax],
                        [sit].[bounding_box_ymin]       AS [YMin],
                        [sit].[bounding_box_ymax]       AS [YMax],
                        [sit].[level_1_grid]            AS [Level1Grid],
                        [sit].[level_2_grid]            AS [Level2Grid],
                        [sit].[level_3_grid]            AS [Level3Grid],
                        [sit].[level_4_grid]            AS [Level4Grid],
                        [sit].[tessellation_scheme]     AS [TessellationScheme],
                        [s].[no_recompute]              AS [NoRecomputeStatistics],
                        [p].[data_compression]          AS [DataCompressionId],
                        CONVERT(bit, CASE WHEN [ti].[data_space_id] = [ds].[data_space_id] THEN 1 ELSE 0 END)
                                                        AS [EqualsParentDataSpace]
                    FROM
                        [sys].[spatial_indexes]          AS [si] WITH (NOLOCK)
                        INNER JOIN [sys].[objects]       AS [o] WITH (NOLOCK) ON [si].[object_id] = [o].[object_id]
                        INNER JOIN [sys].[spatial_index_tessellations] [sit] WITH (NOLOCK) ON [si].[object_id] = [sit].[object_id] AND [si].[index_id] = [sit].[index_id]
                        INNER JOIN [sys].[data_spaces]   AS [ds] WITH (NOLOCK) ON [ds].[data_space_id] = [si].[data_space_id] 
                        INNER JOIN [sys].[index_columns] AS [ic] WITH (NOLOCK) ON [si].[object_id] = [ic].[object_id] AND [si].[index_id] = [ic].[index_id]
                        INNER JOIN [sys].[columns]       AS [c] WITH (NOLOCK) ON [si].[object_id] = [c].[object_id] AND [ic].[column_id] = [c].[column_id]
                        INNER JOIN [sys].[objects]       AS [o2] WITH (NOLOCK) ON [o2].[parent_object_id] = [si].[object_id]
                        INNER JOIN [sys].[stats]         AS [s] WITH (NOLOCK) ON [o2].[object_id] = [s].[object_id] AND [s].[name] = [si].[name]
                        INNER JOIN [sys].[partitions]    AS [p] WITH (NOLOCK) ON [p].[object_id] = [o2].[object_id] AND [p].[partition_number] = 1
                        LEFT  JOIN [sys].[indexes]       AS [ti] WITH (NOLOCK) ON [o].[object_id] = [ti].[object_id]
                        LEFT JOIN [sys].[tables]         AS [t] WITH (NOLOCK) ON [t].[object_id] = [si].[object_id]
                    WHERE [si].[is_hypothetical] = 0
                        AND [ti].[index_id] < 2
                        AND OBJECTPROPERTY([o].[object_id], N'IsSystemTable') = 0
                        AND ([t].[is_filetable] = 0 OR [t].[is_filetable] IS NULL)
                        AND ([o].[is_ms_shipped] = 0 AND NOT EXISTS (SELECT *
                                                        FROM [sys].[extended_properties]
                                                        WHERE     [major_id] = [o].[object_id]
                                                              AND [minor_id] = 0
                                                              AND [class] = 1
                                                              AND [name] = N'microsoft_database_tools_support'
                                                       ))
                    ) AS [_results]
"@

        try
        {
            Invoke-SqlQuery -ConnectionString $ConnectionString -CommandTimeout $commandTimeoutInSeconds -Query $schemaQuery -ResultReader (Get-ExecuteScalarReader) 
        }
        catch
        {
            if($_.FullyQualifiedErrorId -eq  'SqlException,Microsoft.PowerShell.Commands.InvokeCommandCommand' -and  $_.Exception.InnerException -ne $null -and $_.Exception.InnerException.Number -eq -2)
            { 
                Write-LogMessage -Message "Datamart reset started."
                try
                {
                    Reset-DatamartIntegration -Reason SERVICING -ReasonDetail "Query against sys schema table timed out possibly due to too many staging tables." -Confirm:$false
                }
                catch
                {
                    Write-LogMessage -Message "Exception thrown while doing datamart reset. $_"
                }

                Write-LogMessage -Message "Datamart reset completed."
            }
        }
    }
}

function Start-Execution
{
	$installPaths = Get-MRFilePaths
	$upgradeToVersion = Get-BinaryVersion

	# Try to replace the deployment assemblies that are slipstreamed
	$assemblyReplacementSourceFolder = Join-Path -Path (Split-Path -Path $script:currentFolder -Parent) -ChildPath '\ReplacementAssembly'
	$tempDir = "$script:currentFolder\temp"
	try
	{
		# For Bug286387: [slipstream] Patch deployment assemblies to prevent dropping and re-adding Primary key constraints on S0 deployments
		if ($upgradeToVersion -ge [version]'7.3.0') # Replacement assembly is only compatible from 7.3 onwards
		{
			ReplaceAssembly -AssemblyFileName 'Microsoft.Dynamics.Performance.Deployment.Database.dll' -SourcePath $assemblyReplacementSourceFolder -TargetPath $installPaths.InstallLocation
		}

		# For Bug275507: [ICMs] Long running schema upgrades exceeding downtime
		# Applies to versions where the db is less than 7.3.2, due to Bug303415 we cannot replace less than 7.3.0
		$versionFilePath = Join-Path -Path $tempDir -ChildPath 'installedAssemblyVersion.txt'
		if(Test-Path -Path $versionFilePath)
		{
			$upgradeFromVersion = [version](Get-Content $versionFilePath -Raw)
			if ($upgradeFromVersion -lt [version]'7.3.2.1' `
				-and $upgradeToVersion -lt [version]'10.0.1.2'`
				-and $upgradeToVersion -gt $upgradeFromVersion)
			{
				ReplaceAssembly -AssemblyFileName 'Microsoft.Dynamics.Performance.Deployment.Commands.Database.dll' -SourcePath $assemblyReplacementSourceFolder -TargetPath $installPaths.InstallLocation
			}
		}
		else
		{
			Write-LogMessage -Message "File: $versionFilePath does not exist." -Warning
		}
	}
	catch
	{
		# Failed to replace deployment assemblies does not fail the upgrade.
		Write-LogMessage -Message 'An error was encountered while replacing deployment assemblies.' -Error
		Write-ErrorDetail -ErrorThrown $_
	}
	finally
	{
		# Clean up the temp folder, which was created during the binary upgrade step.
		Remove-Item -Path $tempDir -Recurse -Force -ErrorAction SilentlyContinue
	}
    
	$modulePath = $installPaths.MRDeploy
	Import-Module $modulePath
	Set-MRDefaultValues -SettingName 'SqlTimeoutSeconds' -SettingValue $SqlTimeoutSeconds
	Set-MRDefaultValues -SettingName 'SSDTTimeoutSeconds' -SettingValue $SqlTimeoutSeconds
	$updateDatabaseTaskGuid = [System.Guid]::NewGuid().ToString()
	$updateDatabaseTaskMessage = 'MR Database Upgrade'

	Log-Event -EventType Start -message $updateDatabaseTaskMessage -guid $updateDatabaseTaskGuid
	Write-LogMessage -Message 'Starting process to upgrade Financial Reporting databases'
	try
	{
		Write-LogMessage -Message 'Fetching Financial Reporting connection string'
		$connectionsConfigFilePath = $null
		$settingsConfigFilePath = $null
		if(Test-Path -Path $installPaths.ApplicationServiceConnectionsConfig)
		{
			$connectionsConfigFilePath = $installPaths.ApplicationServiceConnectionsConfig
			$settingsConfigFilePath = $installPaths.ApplicationServiceSettingsConfig
		}
		else
		{
			$connectionsConfigFilePath = $installPaths.ServicesConnectionsConfig
			$settingsConfigFilePath = $installPaths.ServicesSettingsConfig
		}

		Add-AssemblyResolver

		$connectionString = Get-DecryptedConnectionString -InstallPaths $installPaths -ConnectionsConfigFilePath $connectionsConfigFilePath
		$initialConnectionString = New-Object System.Data.SqlClient.SqlConnectionStringBuilder -ArgumentList $connectionString

		Set-MRDefaultValues -Settings @{
			'MRSqlServerName'=$initialConnectionString.DataSource;
			'MRDatabaseName'=$initialConnectionString.InitialCatalog;
			'SqlTimeoutSeconds'=$SqlTimeoutSeconds;
			'MRSqlTrustServerCertConnection'=[string]($initialConnectionString.TrustServerCertificate);
			'MRSqlEncryptConnection' = $initialConnectionString.Encrypt
		}

		Write-LogMessage -Message 'Fetching data encryption and data signing certificate thumbprints.'
		[xml]$settingscontents = Get-Content $settingsConfigFilePath -Raw
		$dataEncryptionThumbprint = Get-SettingsConfigValue -SettingsXml $settingscontents -SettingName 'DataEncryptionCertificateThumbprint'
		Set-MRDefaultValues -Settings @{ 'DataEncryptionCertThumbprint' = $dataEncryptionThumbprint }

		$dataSigningThumbprint = Get-DataSigningCertificateThumbprint -SettingsXml $settingscontents -DataEncryptionCertificateThumbprint $dataEncryptionThumbprint
		if ((Get-MRDefaultValueNames) -contains 'DataSigningCertThumbprint')
		{
			Set-MRDefaultValues -Settings @{ 'DataSigningCertThumbprint' = $dataSigningThumbprint }
		}

		if($initialConnectionString.IntegratedSecurity)
		{
			Write-LogMessage -Message 'Integrated security is being used for SQL connections. Running as a non-deployment user may result in errors.' -Warning
			$mrAdminSqlConnectionString = $initialConnectionString
		}
		else
		{
			$mrAdminSqlConnectionString = Get-PrivilegedConnectionString -InitialConnectionString $initialConnectionString.ConnectionString -DataEncryptionCertificateThumbprint $dataEncryptionThumbprint -DataSigningCertificateThumbprint $dataSigningThumbprint
			Set-MRDefaultValues -Settings @{'MRSqlRuntimeUserName'=$initialConnectionString.UserID;'MRSqlRuntimeUserPassword'=$initialConnectionString.Password;'MRSqlUserName'=$mrAdminSqlConnectionString.UserID;'MRSqlUserPassword'=$mrAdminSqlConnectionString.Password}
		}

		$defaultValues = Get-MRDefaultValues
		$updateSchemeUserPrivilegeParams = Get-UpdateSchemaUserPrivilegeParams
		Write-LogMessage -Message 'Attempting to update schema user privilege data.'
		Update-SchemaUserPrivilege @updateSchemeUserPrivilegeParams
		Write-LogMessage -Message 'Completed update of schema user privilege data.'

		# Check schema version vs AppliedUpgradesVersion
		$schemaVersion = Invoke-SqlQuery -ConnectionString $mrAdminSqlConnectionString -Query "select Value from Reporting.ControlProperties where Name = 'SchemaVersion'" -ResultReader (Get-ExecuteScalarReader)
		$appliedUpgradesVersion = Invoke-SqlQuery -ConnectionString $mrAdminSqlConnectionString -Query "select Value from Reporting.ControlProperties where Name = 'AppliedUpgradesVersion'" -ResultReader (Get-ExecuteScalarReader)
		Write-LogMessage -Message "Checking Database SchemaVersion: $schemaVersion; Applied Upgrades Version: $appliedUpgradesVersion"
		$needsDbUpgrade = -not $schemaVersion -or -not $appliedUpgradesVersion -or [version]$schemaVersion -gt [version]$appliedUpgradesVersion

		# Check schema version vs package version
		$targetVersion = New-Object -TypeName System.Version -ArgumentList $upgradeToVersion.Major,$upgradeToVersion.Minor,$upgradeToVersion.Build
		Write-LogMessage -Message "Checking Database SchemaVersion: $schemaVersion; Binary Version: $targetVersion"
		$needsDbUpgrade = $needsDbUpgrade -or -not $schemaVersion -or $targetVersion -gt [version]$schemaVersion

		if(-not $needsDbUpgrade)
		{
			Write-LogMessage -Message "Database update not needed."
		}
		else
		{
			Write-LogMessage -Message "Database update needed: SchemaVersion: $schemaVersion, AppliedUpgradesVersion: $appliedUpgradesVersion to TargetVersion: $targetVersion"

            # Do Datamart reset if Financial Reporting database tier is S0, there are too many staging tables and Financial Reporting application is not in use.
            Do-DatamartResetIfNecessary -ConnectionString $mrAdminSqlConnectionString

			$publishDatabaseParams = Get-PublishDatabaseParams -DatabaseType Reporting
			$credentials = $null
			if(!$publishDatabaseParams.UseIntegratedAuthentication)
			{
				$securePassword = ConvertTo-SecureString $mrAdminSqlConnectionString.Password -AsPlainText -Force
				$credentials = New-Object System.Management.Automation.PSCredential -ArgumentList $mrAdminSqlConnectionString.UserID, $securePassword
			}

			Write-LogMessage -Message 'Starting update of data integrations.'
			$webConfigFilePath = Join-Path -Path $installPaths.Server -ChildPath 'ApplicationService\web.config'
			$appServiceBinPath = Join-Path -Path $installPaths.Server -ChildPath 'ApplicationService\bin'
			$consolePluginPath = Join-Path -Path $installPaths.Console -ChildPath 'Plugins'
			$assemblyProbingPaths = @($appServiceBinPath, $installPaths.Console, $consolePluginPath)
			Update-AdapterSettings -ServerInstance $mrAdminSqlConnectionString.DataSource -DatabaseName $mrAdminSqlConnectionString.InitialCatalog -Credential:$credentials -ConfigSettingsContents $settingscontents
			Update-AXIntegrationGroup -DatabaseConnectionString $mrAdminSqlConnectionString.ConnectionString -ApplicationBasePath $installPaths.Server -ConfigurationFilePath $webConfigFilePath -AssemblyProbingPath ($assemblyProbingPaths -join ";") -Retries $defaultValues.RetryCount -SqlCommandTimeoutSeconds $defaultValues.SqlTimeoutSeconds
			Reset-ReportDefinitionMaps -ServerInstance $mrAdminSqlConnectionString.DataSource -DatabaseName $mrAdminSqlConnectionString.InitialCatalog -Credential:$credentials -DataEncryptionCertificateThumbprint $defaultValues.DataEncryptionCertThumbprint -DataSigningCertificateThumbprint $dataSigningThumbprint
			Write-LogMessage -Message 'Completed update of data integrations.'

			Update-PreDatabaseUpgrade -ServerInstance $mrAdminSqlConnectionString.DataSource -DatabaseName $mrAdminSqlConnectionString.InitialCatalog -Credential:$credentials

			Write-LogMessage -Message 'Updating Financial Reporting database'
			Write-LogMessage -Message 'Attempting to publish database'
			$updated = Publish-Database @publishDatabaseParams
			if(!$updated)
			{
				throw 'Unable to update the Financial Reporting database.'
			}

			Write-LogMessage -Message 'Financial Reporting Database Updated'
		}

		# Add ReportingIntegrationUser Role to AX DB, provision GeneralUser on MR DB
		Update-UserRoles -ConnectionString $mrAdminSqlConnectionString -DataEncryptionCertificateThumbprint $defaultValues.DataEncryptionCertThumbprint -DataSigningCertificateThumbprint $dataSigningThumbprint

		# Setup change tracking on MR database
		Write-LogMessage 'Adding reporting database change tracking (Add-MRDatabaseChangeTracking)'
		$addMRDatabaseChangeTrackingParams = Get-AddMRDatabaseChangeTrackingParams
		Add-MRDatabaseChangeTracking @addMRDatabaseChangeTrackingParams

		Write-LogMessage -Message 'Completed upgrade of Financial Reporting databases'
		Log-Event -EventType Stop -message $updateDatabaseTaskMessage -guid $updateDatabaseTaskGuid
	}
	catch
	{
		Write-ErrorDetail -ErrorThrown $_
		# throw a new exception to avoid background jobs getting stuck
		throw 'An error was encountered while updating the Financial Reporting components.'
	}
	finally
	{
		Remove-AssemblyResolver
		Remove-Module 'MRDeploy'
		Log-Event -EventType Stop -message $updateDatabaseTaskMessage -guid $updateDatabaseTaskGuid
	}
}

Start-Execution *>&1 | Out-Log
# SIG # Begin signature block
# MIIjsAYJKoZIhvcNAQcCoIIjoTCCI50CAQExDzANBglghkgBZQMEAgEFADB5Bgor
# BgEEAYI3AgEEoGswaTA0BgorBgEEAYI3AgEeMCYCAwEAAAQQH8w7YFlLCE63JNLG
# KX7zUQIBAAIBAAIBAAIBAAIBADAxMA0GCWCGSAFlAwQCAQUABCBTPzoLhy5hQQbS
# b4J+LEg2TpUcjGewsLDmgZFgviP0JaCCDYEwggX/MIID56ADAgECAhMzAAABUZ6N
# j0Bxow5BAAAAAAFRMA0GCSqGSIb3DQEBCwUAMH4xCzAJBgNVBAYTAlVTMRMwEQYD
# VQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNy
# b3NvZnQgQ29ycG9yYXRpb24xKDAmBgNVBAMTH01pY3Jvc29mdCBDb2RlIFNpZ25p
# bmcgUENBIDIwMTEwHhcNMTkwNTAyMjEzNzQ2WhcNMjAwNTAyMjEzNzQ2WjB0MQsw
# CQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9u
# ZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMR4wHAYDVQQDExVNaWNy
# b3NvZnQgQ29ycG9yYXRpb24wggEiMA0GCSqGSIb3DQEBAQUAA4IBDwAwggEKAoIB
# AQCVWsaGaUcdNB7xVcNmdfZiVBhYFGcn8KMqxgNIvOZWNH9JYQLuhHhmJ5RWISy1
# oey3zTuxqLbkHAdmbeU8NFMo49Pv71MgIS9IG/EtqwOH7upan+lIq6NOcw5fO6Os
# +12R0Q28MzGn+3y7F2mKDnopVu0sEufy453gxz16M8bAw4+QXuv7+fR9WzRJ2CpU
# 62wQKYiFQMfew6Vh5fuPoXloN3k6+Qlz7zgcT4YRmxzx7jMVpP/uvK6sZcBxQ3Wg
# B/WkyXHgxaY19IAzLq2QiPiX2YryiR5EsYBq35BP7U15DlZtpSs2wIYTkkDBxhPJ
# IDJgowZu5GyhHdqrst3OjkSRAgMBAAGjggF+MIIBejAfBgNVHSUEGDAWBgorBgEE
# AYI3TAgBBggrBgEFBQcDAzAdBgNVHQ4EFgQUV4Iarkq57esagu6FUBb270Zijc8w
# UAYDVR0RBEkwR6RFMEMxKTAnBgNVBAsTIE1pY3Jvc29mdCBPcGVyYXRpb25zIFB1
# ZXJ0byBSaWNvMRYwFAYDVQQFEw0yMzAwMTIrNDU0MTM1MB8GA1UdIwQYMBaAFEhu
# ZOVQBdOCqhc3NyK1bajKdQKVMFQGA1UdHwRNMEswSaBHoEWGQ2h0dHA6Ly93d3cu
# bWljcm9zb2Z0LmNvbS9wa2lvcHMvY3JsL01pY0NvZFNpZ1BDQTIwMTFfMjAxMS0w
# Ny0wOC5jcmwwYQYIKwYBBQUHAQEEVTBTMFEGCCsGAQUFBzAChkVodHRwOi8vd3d3
# Lm1pY3Jvc29mdC5jb20vcGtpb3BzL2NlcnRzL01pY0NvZFNpZ1BDQTIwMTFfMjAx
# MS0wNy0wOC5jcnQwDAYDVR0TAQH/BAIwADANBgkqhkiG9w0BAQsFAAOCAgEAWg+A
# rS4Anq7KrogslIQnoMHSXUPr/RqOIhJX+32ObuY3MFvdlRElbSsSJxrRy/OCCZdS
# se+f2AqQ+F/2aYwBDmUQbeMB8n0pYLZnOPifqe78RBH2fVZsvXxyfizbHubWWoUf
# NW/FJlZlLXwJmF3BoL8E2p09K3hagwz/otcKtQ1+Q4+DaOYXWleqJrJUsnHs9UiL
# crVF0leL/Q1V5bshob2OTlZq0qzSdrMDLWdhyrUOxnZ+ojZ7UdTY4VnCuogbZ9Zs
# 9syJbg7ZUS9SVgYkowRsWv5jV4lbqTD+tG4FzhOwcRQwdb6A8zp2Nnd+s7VdCuYF
# sGgI41ucD8oxVfcAMjF9YX5N2s4mltkqnUe3/htVrnxKKDAwSYliaux2L7gKw+bD
# 1kEZ/5ozLRnJ3jjDkomTrPctokY/KaZ1qub0NUnmOKH+3xUK/plWJK8BOQYuU7gK
# YH7Yy9WSKNlP7pKj6i417+3Na/frInjnBkKRCJ/eYTvBH+s5guezpfQWtU4bNo/j
# 8Qw2vpTQ9w7flhH78Rmwd319+YTmhv7TcxDbWlyteaj4RK2wk3pY1oSz2JPE5PNu
# Nmd9Gmf6oePZgy7Ii9JLLq8SnULV7b+IP0UXRY9q+GdRjM2AEX6msZvvPCIoG0aY
# HQu9wZsKEK2jqvWi8/xdeeeSI9FN6K1w4oVQM4Mwggd6MIIFYqADAgECAgphDpDS
# AAAAAAADMA0GCSqGSIb3DQEBCwUAMIGIMQswCQYDVQQGEwJVUzETMBEGA1UECBMK
# V2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0
# IENvcnBvcmF0aW9uMTIwMAYDVQQDEylNaWNyb3NvZnQgUm9vdCBDZXJ0aWZpY2F0
# ZSBBdXRob3JpdHkgMjAxMTAeFw0xMTA3MDgyMDU5MDlaFw0yNjA3MDgyMTA5MDla
# MH4xCzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdS
# ZWRtb25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xKDAmBgNVBAMT
# H01pY3Jvc29mdCBDb2RlIFNpZ25pbmcgUENBIDIwMTEwggIiMA0GCSqGSIb3DQEB
# AQUAA4ICDwAwggIKAoICAQCr8PpyEBwurdhuqoIQTTS68rZYIZ9CGypr6VpQqrgG
# OBoESbp/wwwe3TdrxhLYC/A4wpkGsMg51QEUMULTiQ15ZId+lGAkbK+eSZzpaF7S
# 35tTsgosw6/ZqSuuegmv15ZZymAaBelmdugyUiYSL+erCFDPs0S3XdjELgN1q2jz
# y23zOlyhFvRGuuA4ZKxuZDV4pqBjDy3TQJP4494HDdVceaVJKecNvqATd76UPe/7
# 4ytaEB9NViiienLgEjq3SV7Y7e1DkYPZe7J7hhvZPrGMXeiJT4Qa8qEvWeSQOy2u
# M1jFtz7+MtOzAz2xsq+SOH7SnYAs9U5WkSE1JcM5bmR/U7qcD60ZI4TL9LoDho33
# X/DQUr+MlIe8wCF0JV8YKLbMJyg4JZg5SjbPfLGSrhwjp6lm7GEfauEoSZ1fiOIl
# XdMhSz5SxLVXPyQD8NF6Wy/VI+NwXQ9RRnez+ADhvKwCgl/bwBWzvRvUVUvnOaEP
# 6SNJvBi4RHxF5MHDcnrgcuck379GmcXvwhxX24ON7E1JMKerjt/sW5+v/N2wZuLB
# l4F77dbtS+dJKacTKKanfWeA5opieF+yL4TXV5xcv3coKPHtbcMojyyPQDdPweGF
# RInECUzF1KVDL3SV9274eCBYLBNdYJWaPk8zhNqwiBfenk70lrC8RqBsmNLg1oiM
# CwIDAQABo4IB7TCCAekwEAYJKwYBBAGCNxUBBAMCAQAwHQYDVR0OBBYEFEhuZOVQ
# BdOCqhc3NyK1bajKdQKVMBkGCSsGAQQBgjcUAgQMHgoAUwB1AGIAQwBBMAsGA1Ud
# DwQEAwIBhjAPBgNVHRMBAf8EBTADAQH/MB8GA1UdIwQYMBaAFHItOgIxkEO5FAVO
# 4eqnxzHRI4k0MFoGA1UdHwRTMFEwT6BNoEuGSWh0dHA6Ly9jcmwubWljcm9zb2Z0
# LmNvbS9wa2kvY3JsL3Byb2R1Y3RzL01pY1Jvb0NlckF1dDIwMTFfMjAxMV8wM18y
# Mi5jcmwwXgYIKwYBBQUHAQEEUjBQME4GCCsGAQUFBzAChkJodHRwOi8vd3d3Lm1p
# Y3Jvc29mdC5jb20vcGtpL2NlcnRzL01pY1Jvb0NlckF1dDIwMTFfMjAxMV8wM18y
# Mi5jcnQwgZ8GA1UdIASBlzCBlDCBkQYJKwYBBAGCNy4DMIGDMD8GCCsGAQUFBwIB
# FjNodHRwOi8vd3d3Lm1pY3Jvc29mdC5jb20vcGtpb3BzL2RvY3MvcHJpbWFyeWNw
# cy5odG0wQAYIKwYBBQUHAgIwNB4yIB0ATABlAGcAYQBsAF8AcABvAGwAaQBjAHkA
# XwBzAHQAYQB0AGUAbQBlAG4AdAAuIB0wDQYJKoZIhvcNAQELBQADggIBAGfyhqWY
# 4FR5Gi7T2HRnIpsLlhHhY5KZQpZ90nkMkMFlXy4sPvjDctFtg/6+P+gKyju/R6mj
# 82nbY78iNaWXXWWEkH2LRlBV2AySfNIaSxzzPEKLUtCw/WvjPgcuKZvmPRul1LUd
# d5Q54ulkyUQ9eHoj8xN9ppB0g430yyYCRirCihC7pKkFDJvtaPpoLpWgKj8qa1hJ
# Yx8JaW5amJbkg/TAj/NGK978O9C9Ne9uJa7lryft0N3zDq+ZKJeYTQ49C/IIidYf
# wzIY4vDFLc5bnrRJOQrGCsLGra7lstnbFYhRRVg4MnEnGn+x9Cf43iw6IGmYslmJ
# aG5vp7d0w0AFBqYBKig+gj8TTWYLwLNN9eGPfxxvFX1Fp3blQCplo8NdUmKGwx1j
# NpeG39rz+PIWoZon4c2ll9DuXWNB41sHnIc+BncG0QaxdR8UvmFhtfDcxhsEvt9B
# xw4o7t5lL+yX9qFcltgA1qFGvVnzl6UJS0gQmYAf0AApxbGbpT9Fdx41xtKiop96
# eiL6SJUfq/tHI4D1nvi/a7dLl+LrdXga7Oo3mXkYS//WsyNodeav+vyL6wuA6mk7
# r/ww7QRMjt/fdW1jkT3RnVZOT7+AVyKheBEyIXrvQQqxP/uozKRdwaGIm1dxVk5I
# RcBCyZt2WwqASGv9eZ/BvW1taslScxMNelDNMYIVhTCCFYECAQEwgZUwfjELMAkG
# A1UEBhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQx
# HjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEoMCYGA1UEAxMfTWljcm9z
# b2Z0IENvZGUgU2lnbmluZyBQQ0EgMjAxMQITMwAAAVGejY9AcaMOQQAAAAABUTAN
# BglghkgBZQMEAgEFAKCB2DAZBgkqhkiG9w0BCQMxDAYKKwYBBAGCNwIBBDAcBgor
# BgEEAYI3AgELMQ4wDAYKKwYBBAGCNwIBFTAvBgkqhkiG9w0BCQQxIgQgGKL8tZMl
# JxLl4m05bjtQFxOZsnKOzbPcAF1zhryPLm8wbAYKKwYBBAGCNwIBDDFeMFygPoA8
# AEEAcABwAGwAeQBSAGUAdABhAGkAbABEAEIAUwBjAHIAaQBwAHQASQBuAFMAUQBM
# AFMAVQAuAHAAcwAxoRqAGGh0dHA6Ly93d3cubWljcm9zb2Z0LmNvbTANBgkqhkiG
# 9w0BAQEFAASCAQBkuNvv7Hn+j7IJfR5wH+inVrEFhvpVWXWER7Dn8eUyTBwAbF6u
# mQ8sK4ZOpl+el/tsEjJ5Ay//zWeUX/7JyUFCUgEQ+HipFzyPyIg7E8pZ2nIQetQk
# V+PqyrvBpGzTDHRDGUiWILZL0KLZtspQaTcENGsATEwTpQBM5V+avDO4QCie9ZVo
# irL+L2mm1b3P5rzFeya3XhtO9OQwR2wMTcxxoQQjVcEePV/FTbjcUdSQP3EfruzL
# 2o/E1J1TQeDtDTdIKaa6EOjZJcCWkrdmcigLVefgxmDCowQlylQfU7kI3c56LbMH
# wLTts9/9G1BMMWkhYwMykNGCL/WM2B8OH1Q+oYIS5TCCEuEGCisGAQQBgjcDAwEx
# ghLRMIISzQYJKoZIhvcNAQcCoIISvjCCEroCAQMxDzANBglghkgBZQMEAgEFADCC
# AVEGCyqGSIb3DQEJEAEEoIIBQASCATwwggE4AgEBBgorBgEEAYRZCgMBMDEwDQYJ
# YIZIAWUDBAIBBQAEIAO6kgJ/8J5E7gsr60hdK+iRYYcQ/nOosjD21GtE8jlcAgZd
# XrmPyqQYEzIwMTkwOTE3MTkyMDAwLjA1MlowBIACAfSggdCkgc0wgcoxCzAJBgNV
# BAYTAlVTMQswCQYDVQQIEwJXQTEQMA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UEChMV
# TWljcm9zb2Z0IENvcnBvcmF0aW9uMS0wKwYDVQQLEyRNaWNyb3NvZnQgSXJlbGFu
# ZCBPcGVyYXRpb25zIExpbWl0ZWQxJjAkBgNVBAsTHVRoYWxlcyBUU1MgRVNOOjJB
# RDQtNEI5Mi1GQTAxMSUwIwYDVQQDExxNaWNyb3NvZnQgVGltZS1TdGFtcCBzZXJ2
# aWNloIIOPDCCBPEwggPZoAMCAQICEzMAAADXr1puwKo9zrYAAAAAANcwDQYJKoZI
# hvcNAQELBQAwfDELMAkGA1UEBhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAO
# BgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEm
# MCQGA1UEAxMdTWljcm9zb2Z0IFRpbWUtU3RhbXAgUENBIDIwMTAwHhcNMTgwODIz
# MjAyNjUwWhcNMTkxMTIzMjAyNjUwWjCByjELMAkGA1UEBhMCVVMxCzAJBgNVBAgT
# AldBMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9y
# YXRpb24xLTArBgNVBAsTJE1pY3Jvc29mdCBJcmVsYW5kIE9wZXJhdGlvbnMgTGlt
# aXRlZDEmMCQGA1UECxMdVGhhbGVzIFRTUyBFU046MkFENC00QjkyLUZBMDExJTAj
# BgNVBAMTHE1pY3Jvc29mdCBUaW1lLVN0YW1wIHNlcnZpY2UwggEiMA0GCSqGSIb3
# DQEBAQUAA4IBDwAwggEKAoIBAQDdiIha4gkM4bDfHbchZGKOIuASSGISvvwK0tIA
# kL7hIbtG1r0X+Ybzt0lI3Hcy6C/ozxZIHPLtDUdLX2+E6XtGj8xHw6Q1xJWQbxts
# MvdLoszc51rkwPIIBfGzFMQB7iYhH9U1QPGGVRWEiMD3ZGdpkDkH7q8nPMgqzVjT
# dkHWynVaqdNMjst9lhKUBVHsptgAjOoNdcwX/Xz9CRxetlzi6hzLuFuZ47rnFIjq
# MPf7GnkbzdwvUXvoiMdP7PVATtW1M0l7Ny1VxcpTnUBrIlqaIl9O3pgggjoPLLfZ
# j+exulZi8K/E5ZVHJ3YIZ7LMUvQgTNPLs6eN4yJvwW5yuWC9AgMBAAGjggEbMIIB
# FzAdBgNVHQ4EFgQU37inVSf/92m8M1ZjNmtNKaDqVTgwHwYDVR0jBBgwFoAU1WM6
# XIoxkPNDe3xGG8UzaFqFbVUwVgYDVR0fBE8wTTBLoEmgR4ZFaHR0cDovL2NybC5t
# aWNyb3NvZnQuY29tL3BraS9jcmwvcHJvZHVjdHMvTWljVGltU3RhUENBXzIwMTAt
# MDctMDEuY3JsMFoGCCsGAQUFBwEBBE4wTDBKBggrBgEFBQcwAoY+aHR0cDovL3d3
# dy5taWNyb3NvZnQuY29tL3BraS9jZXJ0cy9NaWNUaW1TdGFQQ0FfMjAxMC0wNy0w
# MS5jcnQwDAYDVR0TAQH/BAIwADATBgNVHSUEDDAKBggrBgEFBQcDCDANBgkqhkiG
# 9w0BAQsFAAOCAQEATAtoUsT5ALWyTHGwnNqeeoO4CCjRB7i0OLPeQcjv7JWTA9Qf
# 0OzONpepqV8vwxElyOMYNMRi8MQEVckDi1DpwqzJAh8WSImjaBAg9h0F9YwOuRtG
# DWF3r6BE72QOiJ8KtWRUFF2vPszCKQK2Zon9gu3OGivAmmBy+5LnC8kq75c7uKM4
# /Zr1LrbCinPF7GZBCGkRwQzRlLQp81N9eCmOBKpDdPjesqHGPb8MAk50HA1lme/z
# RAn6RAkF4+DWOL/rNu5fLh51PjxgQPn3gUT4Q/ah1dR9yoPN0lcNnPPx9vAJ5v2s
# mw0n1ajgw4FOvCqbDLj8qs12l6t4xqT617ltMDCCBnEwggRZoAMCAQICCmEJgSoA
# AAAAAAIwDQYJKoZIhvcNAQELBQAwgYgxCzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpX
# YXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNyb3NvZnQg
# Q29ycG9yYXRpb24xMjAwBgNVBAMTKU1pY3Jvc29mdCBSb290IENlcnRpZmljYXRl
# IEF1dGhvcml0eSAyMDEwMB4XDTEwMDcwMTIxMzY1NVoXDTI1MDcwMTIxNDY1NVow
# fDELMAkGA1UEBhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1Jl
# ZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEmMCQGA1UEAxMd
# TWljcm9zb2Z0IFRpbWUtU3RhbXAgUENBIDIwMTAwggEiMA0GCSqGSIb3DQEBAQUA
# A4IBDwAwggEKAoIBAQCpHQ28dxGKOiDs/BOX9fp/aZRrdFQQ1aUKAIKF++18aEss
# X8XD5WHCdrc+Zitb8BVTJwQxH0EbGpUdzgkTjnxhMFmxMEQP8WCIhFRDDNdNuDgI
# s0Ldk6zWczBXJoKjRQ3Q6vVHgc2/JGAyWGBG8lhHhjKEHnRhZ5FfgVSxz5NMksHE
# pl3RYRNuKMYa+YaAu99h/EbBJx0kZxJyGiGKr0tkiVBisV39dx898Fd1rL2KQk1A
# UdEPnAY+Z3/1ZsADlkR+79BL/W7lmsqxqPJ6Kgox8NpOBpG2iAg16HgcsOmZzTzn
# L0S6p/TcZL2kAcEgCZN4zfy8wMlEXV4WnAEFTyJNAgMBAAGjggHmMIIB4jAQBgkr
# BgEEAYI3FQEEAwIBADAdBgNVHQ4EFgQU1WM6XIoxkPNDe3xGG8UzaFqFbVUwGQYJ
# KwYBBAGCNxQCBAweCgBTAHUAYgBDAEEwCwYDVR0PBAQDAgGGMA8GA1UdEwEB/wQF
# MAMBAf8wHwYDVR0jBBgwFoAU1fZWy4/oolxiaNE9lJBb186aGMQwVgYDVR0fBE8w
# TTBLoEmgR4ZFaHR0cDovL2NybC5taWNyb3NvZnQuY29tL3BraS9jcmwvcHJvZHVj
# dHMvTWljUm9vQ2VyQXV0XzIwMTAtMDYtMjMuY3JsMFoGCCsGAQUFBwEBBE4wTDBK
# BggrBgEFBQcwAoY+aHR0cDovL3d3dy5taWNyb3NvZnQuY29tL3BraS9jZXJ0cy9N
# aWNSb29DZXJBdXRfMjAxMC0wNi0yMy5jcnQwgaAGA1UdIAEB/wSBlTCBkjCBjwYJ
# KwYBBAGCNy4DMIGBMD0GCCsGAQUFBwIBFjFodHRwOi8vd3d3Lm1pY3Jvc29mdC5j
# b20vUEtJL2RvY3MvQ1BTL2RlZmF1bHQuaHRtMEAGCCsGAQUFBwICMDQeMiAdAEwA
# ZQBnAGEAbABfAFAAbwBsAGkAYwB5AF8AUwB0AGEAdABlAG0AZQBuAHQALiAdMA0G
# CSqGSIb3DQEBCwUAA4ICAQAH5ohRDeLG4Jg/gXEDPZ2joSFvs+umzPUxvs8F4qn+
# +ldtGTCzwsVmyWrf9efweL3HqJ4l4/m87WtUVwgrUYJEEvu5U4zM9GASinbMQEBB
# m9xcF/9c+V4XNZgkVkt070IQyK+/f8Z/8jd9Wj8c8pl5SpFSAK84Dxf1L3mBZdmp
# tWvkx872ynoAb0swRCQiPM/tA6WWj1kpvLb9BOFwnzJKJ/1Vry/+tuWOM7tiX5rb
# V0Dp8c6ZZpCM/2pif93FSguRJuI57BlKcWOdeyFtw5yjojz6f32WapB4pm3S4Zz5
# Hfw42JT0xqUKloakvZ4argRCg7i1gJsiOCC1JeVk7Pf0v35jWSUPei45V3aicaoG
# ig+JFrphpxHLmtgOR5qAxdDNp9DvfYPw4TtxCd9ddJgiCGHasFAeb73x4QDf5zEH
# pJM692VHeOj4qEir995yfmFrb3epgcunCaw5u+zGy9iCtHLNHfS4hQEegPsbiSpU
# ObJb2sgNVZl6h3M7COaYLeqN4DMuEin1wC9UJyH3yKxO2ii4sanblrKnQqLJzxlB
# TeCG+SqaoxFmMNO7dDJL32N79ZmKLxvHIa9Zta7cRDyXUHHXodLFVeNp3lfB0d4w
# wP3M5k37Db9dT+mdHhk4L7zPWAUu7w2gUDXa7wknHNWzfjUeCLraNtvTX4/edIhJ
# EqGCAs4wggI3AgEBMIH4oYHQpIHNMIHKMQswCQYDVQQGEwJVUzELMAkGA1UECBMC
# V0ExEDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3Jh
# dGlvbjEtMCsGA1UECxMkTWljcm9zb2Z0IElyZWxhbmQgT3BlcmF0aW9ucyBMaW1p
# dGVkMSYwJAYDVQQLEx1UaGFsZXMgVFNTIEVTTjoyQUQ0LTRCOTItRkEwMTElMCMG
# A1UEAxMcTWljcm9zb2Z0IFRpbWUtU3RhbXAgc2VydmljZaIjCgEBMAcGBSsOAwIa
# AxUAzTZ24jTRpyU2peucTVbl/F0HEa2ggYMwgYCkfjB8MQswCQYDVQQGEwJVUzET
# MBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UEChMV
# TWljcm9zb2Z0IENvcnBvcmF0aW9uMSYwJAYDVQQDEx1NaWNyb3NvZnQgVGltZS1T
# dGFtcCBQQ0EgMjAxMDANBgkqhkiG9w0BAQUFAAIFAOErfqQwIhgPMjAxOTA5MTcy
# MzQ3NDhaGA8yMDE5MDkxODIzNDc0OFowdzA9BgorBgEEAYRZCgQBMS8wLTAKAgUA
# 4St+pAIBADAKAgEAAgIhtgIB/zAHAgEAAgIRYTAKAgUA4SzQJAIBADA2BgorBgEE
# AYRZCgQCMSgwJjAMBgorBgEEAYRZCgMCoAowCAIBAAIDB6EgoQowCAIBAAIDAYag
# MA0GCSqGSIb3DQEBBQUAA4GBAIBBgwsM+CPjl+LOl7f70rOqeGi0Yi75UEOfYMVQ
# Po5a/9Bl+Anpa+h/u+Ip1mlOuAt+NNdfFY2pKov3/DLe04DP3EWIyNCB4sumVEis
# vrQTgCXRgp3OmOnT7nyp0dpJy+p59z9wn0y1I6Qnhm/tyEI7iHx12fGtBE9nknsv
# nms7MYIDDTCCAwkCAQEwgZMwfDELMAkGA1UEBhMCVVMxEzARBgNVBAgTCldhc2hp
# bmd0b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jw
# b3JhdGlvbjEmMCQGA1UEAxMdTWljcm9zb2Z0IFRpbWUtU3RhbXAgUENBIDIwMTAC
# EzMAAADXr1puwKo9zrYAAAAAANcwDQYJYIZIAWUDBAIBBQCgggFKMBoGCSqGSIb3
# DQEJAzENBgsqhkiG9w0BCRABBDAvBgkqhkiG9w0BCQQxIgQg7iIkDetRtydhuOhn
# 428FBctMJk2MnO2sadVvESBAz+IwgfoGCyqGSIb3DQEJEAIvMYHqMIHnMIHkMIG9
# BCCljmAMJw9BHv3eSih0+yhBcs7IauKTg/VixBFGziTjODCBmDCBgKR+MHwxCzAJ
# BgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25k
# MR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xJjAkBgNVBAMTHU1pY3Jv
# c29mdCBUaW1lLVN0YW1wIFBDQSAyMDEwAhMzAAAA169absCqPc62AAAAAADXMCIE
# IN4TLo7X2UxXfSttJz6N3RmzIQjwELkFxFxfH5QLrsQGMA0GCSqGSIb3DQEBCwUA
# BIIBAKEGLsA1P4tOgU7g68gQFRAnE6ceDU2OQywKmxexFvkHnG/ZDWfV9cK/GNBb
# K531N2zoNIpkru36wcNtDL2U+0XcaxWZDyEE5eOGc1JTrMEJ1ICWgUYFXna0lch5
# 4crM5cS7+ADm4WV1hGwKEQlsFfjtExdI3Wpx6l5N+zH/tuMeKyTJQEvCrlPSo2bj
# R8DH+DBHvyGfxgfy3aSJfOf75mxHEB6H9Ktoq5SKfPCNWiKUoF9s8ioSW5oBj0+U
# mMW+bheNoXIhe2nhxw4+jztaOG8spbKnzs7HzbR1bO+yxZKs3WZCk8dTDpgetwVy
# KQkxl2ilyHPmqYTguscqc5Q0+qg=
# SIG # End signature block
