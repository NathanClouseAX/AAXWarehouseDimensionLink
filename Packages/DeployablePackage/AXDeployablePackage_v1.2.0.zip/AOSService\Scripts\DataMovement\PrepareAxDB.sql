-- Prepare\ensure that database is sql azure database

update sysglobalconfiguration
set value = 'SQLAZURE' 
where name = 'BACKENDDB' 

update sysglobalconfiguration 
set value = 1 
where name = 'TEMPTABLEINAXDB'