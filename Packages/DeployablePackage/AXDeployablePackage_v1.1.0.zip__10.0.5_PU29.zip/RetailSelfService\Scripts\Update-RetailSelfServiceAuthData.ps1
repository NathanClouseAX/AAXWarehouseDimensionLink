<#
SAMPLE CODE NOTICE

THIS SAMPLE CODE IS MADE AVAILABLE AS IS.  MICROSOFT MAKES NO WARRANTIES, WHETHER EXPRESS OR IMPLIED, 
OF FITNESS FOR A PARTICULAR PURPOSE, OF ACCURACY OR COMPLETENESS OF RESPONSES, OF RESULTS, OR CONDITIONS OF MERCHANTABILITY.
THE ENTIRE RISK OF THE USE OR THE RESULTS FROM THE USE OF THIS SAMPLE CODE REMAINS WITH THE USER.  
NO TECHNICAL SUPPORT IS PROVIDED.  YOU MAY NOT DISTRIBUTE THIS CODE UNLESS YOU HAVE A LICENSE AGREEMENT WITH MICROSOFT THAT ALLOWS YOU TO DO SO.
#>

param(
    [string]$logFile = 'Update-RetailSelfServiceAuthData.log'
)

$ErrorActionPreference = 'Stop'

function Log-TimedMessage([string]$message)
{
    Write-Host ('{0}: {1}' -f (Get-Date -DisplayHint Time), $message)
}

function Create-XmlForSetupUtility(
    [string]$newUsername = $(Throw 'newUsername is required!'),
    [string]$newUserPassword = $(Throw 'newUserPassword is required!'),
    [string]$newSqlServerName = $(Throw 'newSqlServerName is required!'),
    [string]$newDatabaseName = $(Throw 'newDatabaseName is required!')
)
{
    $newEncodedPassword = [System.Convert]::ToBase64String([System.Text.Encoding]::UTF8.GetBytes($newUserPassword))
    $methodInputXmlString = 
    @'
<?xml version="1.0" encoding="UTF-8"?>
<Configuration>
    <AuthServicingDetails>
        <NewSqlServerName>{0}</NewSqlServerName>
        <NewDatabaseName>{1}</NewDatabaseName>
        <NewUsername>{2}</NewUsername>
        <NewUserPassword>{3}</NewUserPassword>
    </AuthServicingDetails>
</Configuration>
'@  -f $newSqlServerName, $newDatabaseName, $newUsername, $newEncodedPassword

    return $methodInputXmlString
}

function Remove-ItemSafe(
    [string]$path
)
{
    if ($path -and (Test-Path -Path $path))
    {
        Remove-Item -Path $path -Force
    }
}

function Backup-AllAOSWebServiceFiles(
    [string]$backupFolderPath,
    [string]$websiteName,
    [string]$logFile
)
{
    Write-Log ('Backing up all AOS Service files to {0}.' -f $backupFolderPath) $logFile
    Backup-WebSite -Name $websiteName -BackupFolder $backupFolderPath
    Write-Log 'Backing up complete.' $logFile
}

function Update-AOSConfigFiles(
    [string]$AOSWebsitePhysicalPath = $(throw 'AOSWebsitePhysicalPath is required.'),
    [string]$oldRetailRTSAuthenticationCertificateThumbprint = $(throw 'oldRetailRTSAuthenticationCertificateThumbprint is required.'),
    [string]$newRetailRTSAuthenticationCertificateThumbprint = $(throw 'newRetailRTSAuthenticationCertificateThumbprint is required.'),
    [string]$logFile = $(throw 'logFile is required.')
)
{
    # Update wif.config
    $wifConfigPath = Join-Path -Path $AOSWebsitePhysicalPath -ChildPath 'wif.config'
    [xml]$wifConfigContent = Get-Content -Path $wifConfigPath

    $wifThumbprintNode = $wifConfigContent.'system.identityModel'.identityConfiguration.securityTokenHandlers.securityTokenHandlerConfiguration.issuerNameRegistry.authority |
                                                %{$_.keys.add} | where thumbprint -eq $oldRetailRTSAuthenticationCertificateThumbprint
    if ($wifThumbprintNode)
    {
        $wifThumbprintNode.thumbprint = $newRetailRTSAuthenticationCertificateThumbprint
    }

    $wifConfigContent.Save($wifConfigPath)
    Write-Log 'Successfully updated wif.config' $logFile
    
    # Update web.config
    $webConfigPath = Join-Path -Path $AOSWebsitePhysicalPath -ChildPath 'web.config'
    [xml]$webConfigContent = Get-Content -Path $webConfigPath

    $claimIssuerRestrictionsNode = $webConfigContent.configuration.claimIssuerRestrictions.issuerRestrictions.add | where name -eq $oldRetailRTSAuthenticationCertificateThumbprint
    if ($claimIssuerRestrictionsNode)
    {
        $claimIssuerRestrictionsNode.name = $newRetailRTSAuthenticationCertificateThumbprint
    }

    $appSettingsNode = $webConfigContent.configuration.appSettings.add | where key -eq 'Infrastructure.TrustedCertificates'
    $listOfThumbprints = $appSettingsNode.value -split ';'
    $newListOfThumbprints = @()

    foreach($thumbprint in $listOfThumbprints)
    {
        if ($thumbprint -eq $oldRetailRTSAuthenticationCertificateThumbprint)
        {
            $newListOfThumbprints += $newRetailRTSAuthenticationCertificateThumbprint
        }
        else
        {
            $newListOfThumbprints += $thumbprint
        }
    }

    $appSettingsNode.value = ($newListOfThumbprints -join ';')
    $webConfigContent.Save($webConfigPath)
    Write-Log 'Successfully updated web.config' $logFile
}

function Update-ChannelDbConnectionStringInAxDb(
    $parametersFromAosWebConfig = $(throw 'parametersFromAosWebConfig is required.'),
    [string]$AOSWebsitePhysicalPath = $(throw 'AOSWebsitePhysicalPath is required.'),
    [string]$AOSWebConfigFilePath = $(throw 'AOSWebConfigFilePath is required.'),
    [string]$newRetailDataSyncUser = $(throw 'newRetailDataSyncUser is required.'),
    [string]$newRetailDataSyncUserPassword = $(throw 'newRetailDataSyncUserPassword is required.'),
    [string]$channelDatabaseServerName = $(throw 'channelDatabaseServerName is required.'),
    [string]$channelDatabaseName = $(throw 'channelDatabaseName is required.'),
    [string]$inputXmlFilePath = $(throw 'inputXmlFilePath is required.'),
    [string]$logFile = $(throw 'logFile is required.')
)
{
    # Get file path to AX deployment setup utility and its config file.
    $AXDeploymentSetupUtilityFilePath = Get-AXDeploymentUtilityFilesPath -AOSWebsitePhysicalPath $AOSWebsitePhysicalPath -UtilityFileName 'Microsoft.Dynamics.AX.Deployment.Setup.exe'
    Write-Log ('Microsoft.Dynamics.AX.Deployment.Setup.exe located at:{0}{1}' -f [System.Environment]::NewLine, $AXDeploymentSetupUtilityFilePath) -logFile $logFile

    $AXDeploymentUtilityConfigFilePath = Get-AXDeploymentUtilityFilesPath -AOSWebsitePhysicalPath $AOSWebsitePhysicalPath -UtilityFileName 'Microsoft.Dynamics.AX.Deployment.Setup.exe.config'
    Write-Log ('Microsoft.Dynamics.AX.Deployment.Setup.exe.config located at:{0}{1}' -f [System.Environment]::NewLine, $AXDeploymentUtilityConfigFilePath) -logFile $logFile

    # Perform AX deployment setup utility config file update with appropriate azure storage connection string from aos web.config
    Update-AXDeploymentUtilityConfigFile -AOSWebConfigFilePath $AOSWebConfigFilePath -AXDeploymentUtilityConfigFilePath $AXDeploymentUtilityConfigFilePath -logFile $logFile

    $usePassedServerName = CheckIf-UserProvidedValidSqlServerData -sqlServerDataString $channelDatabaseServerName
    $usePassedDatabaseName = CheckIf-UserProvidedValidSqlServerData -sqlServerDataString $channelDatabaseName

    # Set the server name and/ or database name to empty string so that AX can recognize it as invalid data.
    if (!$usePassedServerName)
    {
        $channelDatabaseServerName = " "
    }
    if (!$usePassedDatabaseName)
    {
        $channelDatabaseName = " "
    }

    # Generate XML to pass down to AX deployment setup utility.
    $methodInputXmlString = Create-XmlForSetupUtility -newUsername $newRetailDataSyncUser `
                                                      -newUserPassword $newRetailDataSyncUserPassword `
                                                      -newSqlServerName $channelDatabaseServerName `
                                                      -newDatabaseName $channelDatabaseName

    # Save above XML to Temp File and return temp file location
    Set-Content -Value $methodInputXmlString -Path $inputXmlFilePath -Force
    Write-Log ('Saved method input xml to temp location: {0}' -f $inputXmlFilePath) -logFile $logFile

    # Call AX Deployment setup.
    Call-AXDeploymentSetupUtility -parametersFromAosWebConfig $parametersFromAosWebConfig `
                                  -methodInputXmlFilePath $inputXmlFilePath `
                                  -AXDeploymentSetupUtilityFilePath $AXDeploymentSetupUtilityFilePath `
                                  -className 'RetailServicingOrchestrator' `
                                  -methodName 'execute' `
                                  -LogFile $logFile
}

function Update-SQLDatabaseUserRoles(
    [boolean]$wereNewRetailDataSyncUserCredentialsSpecified,
    [boolean]$wereNewRetailRuntimeUserCredentialsSpecified,
    
    [string]$oldRetailDataSyncUser = $(throw 'oldRetailDataSyncUser is required.'),
    [string]$newRetailDataSyncUser = $(throw 'newRetailDataSyncUser is required.'),
    [string]$oldRetailRuntimeUser = $(throw 'oldRetailRuntimeUser is required.'),
    [string]$newRetailRuntimeUser = $(throw 'newRetailRuntimeUser is required.'),
    $parametersFromAosWebConfig = $(throw 'parametersFromAosWebConfig is required.'),
    [string]$logFile = $(throw 'logFile is required.')
)
{
    if ($wereNewRetailDataSyncUserCredentialsSpecified)
    {
        Write-Log ('Starting to copy database user roles from {0} to user {1}.' -f $oldRetailDataSyncUser, $newRetailDataSyncUser) -logFile $logFile
        Invoke-ScriptAndRedirectOutput `
                        -scriptBlock `
                        {
                            Copy-DatabaseUserRoles -copyRolesFromUser $oldRetailDataSyncUser `
                                                   -copyRolesToUser $newRetailDataSyncUser `
                                                   -sqlServerInstanceName $parametersFromAosWebConfig['AosDatabaseServer'] `
                                                   -databaseName $parametersFromAosWebConfig['AosDatabaseName'] `
                                                   -dbAccessUser $parametersFromAosWebConfig['AosDatabaseUser'] `
                                                   -dbAccessUserPassword $parametersFromAosWebConfig['AosDatabasePass']
                        } `
                        -logFile $logFile
                        

        Write-Log ('Database user role copy successful for user {0}.' -f $newRetailDataSyncUser) -logFile $logFile
    }

    if ($wereNewRetailRuntimeUserCredentialsSpecified)
    {
        Write-Log ('Starting to copy database user roles from {0} to user {1}.' -f $oldRetailRuntimeUser, $newRetailRuntimeUser) -logFile $logFile
        Invoke-ScriptAndRedirectOutput `
                        -scriptBlock `
                        {
                            Copy-DatabaseUserRoles -copyRolesFromUser $oldRetailRuntimeUser `
                                                   -copyRolesToUser $newRetailRuntimeUser `
                                                   -sqlServerInstanceName $parametersFromAosWebConfig['AosDatabaseServer'] `
                                                   -databaseName $parametersFromAosWebConfig['AosDatabaseName'] `
                                                   -dbAccessUser $parametersFromAosWebConfig['AosDatabaseUser'] `
                                                   -dbAccessUserPassword $parametersFromAosWebConfig['AosDatabasePass']
                        } `
                        -logFile $logFile

        Write-Log ('Database user role copy successful for user {0}.' -f $newRetailRuntimeUser) -logFile $logFile
    }
}

try
{
    $serviceModelName = 'RetailServer'
    $scriptDir = Split-Path -Path $MyInvocation.MyCommand.Path -Parent
    $packageRootPath = Split-Path -Path (Split-Path -Path $scriptDir -Parent) -Parent

    # Import all requisite modules.
    . $scriptDir\Common-Database.ps1

    Import-Module (Join-Path -Path $scriptDir -ChildPath 'Common-Servicing.psm1') -DisableNameChecking
    Import-Module (Join-Path -Path $scriptDir -ChildPath 'CommonRollbackUtilities.psm1') -DisableNameChecking

    Import-Module (Join-Path -Path $scriptDir -ChildPath 'SelfServiceConfiguration.psm1') -DisableNameChecking
    Load-RotationInfoModule -packageRootPath $packageRootPath

    # Step 1: Read rotationInfo
    $rotationInfo = Get-RotationInfo -serviceModelName $serviceModelName -packageRootPath $packageRootPath
    if ($rotationInfo -eq $null)
    {
        Write-Log ('Servicing template information not found for {0}. Skipping servicing.' -f $serviceModelName) $logFile
        exit 0
    }

    $rotationInfoDecryptor = Get-RotationInfoDecryptor -rotationInfo $rotationInfo

    # Read all required certificate thumbprints
    $newRetailRTSAuthenticationCertificateThumbprint = GetValueFor-CertificateThumbprintWithKey -key 'NewRetailRTSAuthenticationCertificate' -rotationInfo $rotationInfo
    $oldRetailRTSAuthenticationCertificateThumbprint = GetValueFor-CertificateThumbprintWithKey -key 'OldRetailRTSAuthenticationCertificate' -rotationInfo $rotationInfo

    # Check to validate certificate status
    $isNewRTSAuthenticationCertTargettedForInstallation = $false
    if ($newRetailRTSAuthenticationCertificateThumbprint)
    {
        $isNewRTSAuthenticationCertTargettedForInstallation = $rotationInfo.Certificates.Thumbprint.Contains($newRetailRTSAuthenticationCertificateThumbprint)
    }

    # Read all the key value pairs from the rotation template.
    $oldRetailDataSyncUser         = GetValueFor-KeyValuePairWithKey -key 'OldRetailDataSyncUser.Username' -rotationInfo $rotationInfo -rotationInfoDecryptor $rotationInfoDecryptor
    $oldRetailRuntimeUser          = GetValueFor-KeyValuePairWithKey -key 'OldRetailRuntimeUser.Username' -rotationInfo $rotationInfo -rotationInfoDecryptor $rotationInfoDecryptor

    $newRetailDataSyncUser         = GetValueFor-KeyValuePairWithKey -key 'NewRetailDataSyncUser.Username' -rotationInfo $rotationInfo -rotationInfoDecryptor $rotationInfoDecryptor
    $newRetailDataSyncUserPassword = GetValueFor-KeyValuePairWithKey -key 'NewRetailDataSyncUser.Password' -rotationInfo $rotationInfo -rotationInfoDecryptor $rotationInfoDecryptor
    $newRetailRuntimeUser          = GetValueFor-KeyValuePairWithKey -key 'NewRetailRuntimeUser.Username' -rotationInfo $rotationInfo -rotationInfoDecryptor $rotationInfoDecryptor

    $channelDatabaseServerName     = GetValueFor-KeyValuePairWithKey -key 'ChannelDatabaseServerName' -rotationInfo $rotationInfo -rotationInfoDecryptor $rotationInfoDecryptor
    $channelDatabaseName           = GetValueFor-KeyValuePairWithKey -key 'ChannelDatabaseName' -rotationInfo $rotationInfo -rotationInfoDecryptor $rotationInfoDecryptor

    $wereNewRetailDataSyncUserCredentialsSpecified = CheckIf-UserProvidedValidCredentialData -credentialString $newRetailDataSyncUser
    $wereOldRetailDataSyncUserCredentialsSpecified = CheckIf-UserProvidedValidCredentialData -credentialString $oldRetailDataSyncUser
    $wereNewRetailRuntimeUserCredentialsSpecified  = CheckIf-UserProvidedValidCredentialData -credentialString $newRetailRuntimeUser
    $wereOldRetailRuntimeUserCredentialsSpecified  = CheckIf-UserProvidedValidCredentialData -credentialString $oldRetailRuntimeUser
    
    # Step 2: Check if user provided any new RetailDataSyncUser or RetailRuntimeUser
    if (-not($wereNewRetailDataSyncUserCredentialsSpecified -or $wereNewRetailRuntimeUserCredentialsSpecified -or $isNewRTSAuthenticationCertTargettedForInstallation))
    {
        Write-Log 'No updatable data was provided. Skipping update.' -logFile $logFile
        exit 0
    }

    # Step 3 : Perform all required credential and certificate validations.
    if ($wereNewRetailDataSyncUserCredentialsSpecified -and (-not($wereOldRetailDataSyncUserCredentialsSpecified)))
    {
        throw 'Old Retail DataSyncUser has not been specified.'
    }

    if ($wereNewRetailRuntimeUserCredentialsSpecified -and (-not($wereOldRetailRuntimeUserCredentialsSpecified)))
    {
        throw 'Old Retail RuntimeUser has not been specified.'
    }

    if ($isNewRTSAuthenticationCertTargettedForInstallation -and (-not($oldRetailRTSAuthenticationCertificateThumbprint)))
    {
        throw 'OldRetailRTSAuthenticationCertificate thumbprint has not been specified.' 
    }

    # Step 4 : Update database roles for new user.
    # Step 4.1 : We need to read AOS web.config to get requisite data.
    # Derive AOS web config file path.
    $AOSWebsitePhysicalPath = Get-WebsitePhysicalPath -webSiteName (Get-AOSWebsiteName)
    $AOSWebConfigFilePath   = Get-AOSWebConfigFilePath -AOSWebsitePhysicalPath $AOSWebsitePhysicalPath
    Write-Log ('AOS web.config located at:{0}{1}' -f [System.Environment]::NewLine, $AOSWebConfigFilePath) -logFile $logFile

    # Get all the parameters from Aos web.config required to update sql database roles AND run AX deployment setup utility.
    $parametersFromAosWebConfig = Get-RequisiteParametersFromAosWebConfig -AOSWebConfigFilePath $AOSWebConfigFilePath

    # Step 4.2 : Update sql database role updates.
    Update-SQLDatabaseUserRoles -wereNewRetailDataSyncUserCredentialsSpecified $wereNewRetailDataSyncUserCredentialsSpecified `
                                -wereNewRetailRuntimeUserCredentialsSpecified $wereNewRetailRuntimeUserCredentialsSpecified `
                                -oldRetailDataSyncUser $oldRetailDataSyncUser `
                                -newRetailDataSyncUser $newRetailDataSyncUser `
                                -oldRetailRuntimeUser $oldRetailRuntimeUser `
                                -newRetailRuntimeUser $newRetailRuntimeUser `
                                -parametersFromAosWebConfig $parametersFromAosWebConfig `
                                -logFile $logFile

    # Step 5: Update AOS web.config and wif.config with updated RTS authentication certificate thumbprint
    if ($isNewRTSAuthenticationCertTargettedForInstallation)
    {
        # Backup web.config and wif.config before making any changes.
        Write-Log ('Backing up any files which might be modified to {0}.' -f $backupFolderPath) $logFile

        #Note: $RunbookBackupFolder variable is populated directly from runbook.
        Backup-AllAOSWebServiceFiles -backupFolderPath $RunbookBackupFolder -websiteName (Get-AOSWebsiteName) -logFile $logFile

        # Update wif.config and web.config
        Update-AOSConfigFiles -AOSWebsitePhysicalPath $AOSWebsitePhysicalPath `
                              -oldRetailRTSAuthenticationCertificateThumbprint $oldRetailRTSAuthenticationCertificateThumbprint `
                              -newRetailRTSAuthenticationCertificateThumbprint $newRetailRTSAuthenticationCertificateThumbprint `
                              -logFile $logFile
    }

    # Step 6: If new RetailDataSyncUser credentials are provided, then update channel database data in AxDB.
    $methodInputXmlFilePath = [System.IO.Path]::GetTempFileName()
    if ($wereNewRetailDataSyncUserCredentialsSpecified)
    {
        Update-ChannelDbConnectionStringInAxDb -parametersFromAosWebConfig $parametersFromAosWebConfig `
                                               -AOSWebsitePhysicalPath $AOSWebsitePhysicalPath `
                                               -AOSWebConfigFilePath $AOSWebConfigFilePath `
                                               -newRetailDataSyncUser $newRetailDataSyncUser `
                                               -newRetailDataSyncUserPassword $newRetailDataSyncUserPassword `
                                               -channelDatabaseServerName $channelDatabaseServerName `
                                               -channelDatabaseName $channelDatabaseName `
                                               -inputXmlFilePath $methodInputXmlFilePath `
                                               -logFile $logFile
    }

    Write-Log 'Retail SelfService authentication data update complete.' -logFile $logFile
}
catch
{
    Write-Log ($global:error[0] | Format-List * -Force | Out-String -Width 4096) -logFile $logFile
    $ScriptLine = "{0}{1}" -f $MyInvocation.MyCommand.Path.ToString(), [System.Environment]::NewLine

    # RollBackChanges
    Write-Log 'Rolling back changes. Replacing files from the backup folder if any.' -logFile $logFile
    #Note: $RunbookBackupFolder variable is populated directly from runbook.
    Restore-WebSite -Name (Get-AOSWebsiteName) -BackupFolder $RunbookBackupFolder
    
    # Set a non-zero unique exit code for Update-RetailSelfServiceAuthData.ps1 failure
    $exitCode = 27003
    Write-Log ("Executed:{0}$ScriptLine{0}Exiting with error code $exitCode." -f [System.Environment]::NewLine) -logFile $logFile
    exit $exitCode
}
finally
{
    Remove-ItemSafe -path $methodInputXmlFilePath
}
# SIG # Begin signature block
# MIIjoAYJKoZIhvcNAQcCoIIjkTCCI40CAQExDzANBglghkgBZQMEAgEFADB5Bgor
# BgEEAYI3AgEEoGswaTA0BgorBgEEAYI3AgEeMCYCAwEAAAQQH8w7YFlLCE63JNLG
# KX7zUQIBAAIBAAIBAAIBAAIBADAxMA0GCWCGSAFlAwQCAQUABCD3T3RndR45mEx7
# TAG0/2jznZr5lC/wADboOqkS54D1PKCCDYEwggX/MIID56ADAgECAhMzAAABUZ6N
# j0Bxow5BAAAAAAFRMA0GCSqGSIb3DQEBCwUAMH4xCzAJBgNVBAYTAlVTMRMwEQYD
# VQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNy
# b3NvZnQgQ29ycG9yYXRpb24xKDAmBgNVBAMTH01pY3Jvc29mdCBDb2RlIFNpZ25p
# bmcgUENBIDIwMTEwHhcNMTkwNTAyMjEzNzQ2WhcNMjAwNTAyMjEzNzQ2WjB0MQsw
# CQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9u
# ZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMR4wHAYDVQQDExVNaWNy
# b3NvZnQgQ29ycG9yYXRpb24wggEiMA0GCSqGSIb3DQEBAQUAA4IBDwAwggEKAoIB
# AQCVWsaGaUcdNB7xVcNmdfZiVBhYFGcn8KMqxgNIvOZWNH9JYQLuhHhmJ5RWISy1
# oey3zTuxqLbkHAdmbeU8NFMo49Pv71MgIS9IG/EtqwOH7upan+lIq6NOcw5fO6Os
# +12R0Q28MzGn+3y7F2mKDnopVu0sEufy453gxz16M8bAw4+QXuv7+fR9WzRJ2CpU
# 62wQKYiFQMfew6Vh5fuPoXloN3k6+Qlz7zgcT4YRmxzx7jMVpP/uvK6sZcBxQ3Wg
# B/WkyXHgxaY19IAzLq2QiPiX2YryiR5EsYBq35BP7U15DlZtpSs2wIYTkkDBxhPJ
# IDJgowZu5GyhHdqrst3OjkSRAgMBAAGjggF+MIIBejAfBgNVHSUEGDAWBgorBgEE
# AYI3TAgBBggrBgEFBQcDAzAdBgNVHQ4EFgQUV4Iarkq57esagu6FUBb270Zijc8w
# UAYDVR0RBEkwR6RFMEMxKTAnBgNVBAsTIE1pY3Jvc29mdCBPcGVyYXRpb25zIFB1
# ZXJ0byBSaWNvMRYwFAYDVQQFEw0yMzAwMTIrNDU0MTM1MB8GA1UdIwQYMBaAFEhu
# ZOVQBdOCqhc3NyK1bajKdQKVMFQGA1UdHwRNMEswSaBHoEWGQ2h0dHA6Ly93d3cu
# bWljcm9zb2Z0LmNvbS9wa2lvcHMvY3JsL01pY0NvZFNpZ1BDQTIwMTFfMjAxMS0w
# Ny0wOC5jcmwwYQYIKwYBBQUHAQEEVTBTMFEGCCsGAQUFBzAChkVodHRwOi8vd3d3
# Lm1pY3Jvc29mdC5jb20vcGtpb3BzL2NlcnRzL01pY0NvZFNpZ1BDQTIwMTFfMjAx
# MS0wNy0wOC5jcnQwDAYDVR0TAQH/BAIwADANBgkqhkiG9w0BAQsFAAOCAgEAWg+A
# rS4Anq7KrogslIQnoMHSXUPr/RqOIhJX+32ObuY3MFvdlRElbSsSJxrRy/OCCZdS
# se+f2AqQ+F/2aYwBDmUQbeMB8n0pYLZnOPifqe78RBH2fVZsvXxyfizbHubWWoUf
# NW/FJlZlLXwJmF3BoL8E2p09K3hagwz/otcKtQ1+Q4+DaOYXWleqJrJUsnHs9UiL
# crVF0leL/Q1V5bshob2OTlZq0qzSdrMDLWdhyrUOxnZ+ojZ7UdTY4VnCuogbZ9Zs
# 9syJbg7ZUS9SVgYkowRsWv5jV4lbqTD+tG4FzhOwcRQwdb6A8zp2Nnd+s7VdCuYF
# sGgI41ucD8oxVfcAMjF9YX5N2s4mltkqnUe3/htVrnxKKDAwSYliaux2L7gKw+bD
# 1kEZ/5ozLRnJ3jjDkomTrPctokY/KaZ1qub0NUnmOKH+3xUK/plWJK8BOQYuU7gK
# YH7Yy9WSKNlP7pKj6i417+3Na/frInjnBkKRCJ/eYTvBH+s5guezpfQWtU4bNo/j
# 8Qw2vpTQ9w7flhH78Rmwd319+YTmhv7TcxDbWlyteaj4RK2wk3pY1oSz2JPE5PNu
# Nmd9Gmf6oePZgy7Ii9JLLq8SnULV7b+IP0UXRY9q+GdRjM2AEX6msZvvPCIoG0aY
# HQu9wZsKEK2jqvWi8/xdeeeSI9FN6K1w4oVQM4Mwggd6MIIFYqADAgECAgphDpDS
# AAAAAAADMA0GCSqGSIb3DQEBCwUAMIGIMQswCQYDVQQGEwJVUzETMBEGA1UECBMK
# V2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0
# IENvcnBvcmF0aW9uMTIwMAYDVQQDEylNaWNyb3NvZnQgUm9vdCBDZXJ0aWZpY2F0
# ZSBBdXRob3JpdHkgMjAxMTAeFw0xMTA3MDgyMDU5MDlaFw0yNjA3MDgyMTA5MDla
# MH4xCzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdS
# ZWRtb25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xKDAmBgNVBAMT
# H01pY3Jvc29mdCBDb2RlIFNpZ25pbmcgUENBIDIwMTEwggIiMA0GCSqGSIb3DQEB
# AQUAA4ICDwAwggIKAoICAQCr8PpyEBwurdhuqoIQTTS68rZYIZ9CGypr6VpQqrgG
# OBoESbp/wwwe3TdrxhLYC/A4wpkGsMg51QEUMULTiQ15ZId+lGAkbK+eSZzpaF7S
# 35tTsgosw6/ZqSuuegmv15ZZymAaBelmdugyUiYSL+erCFDPs0S3XdjELgN1q2jz
# y23zOlyhFvRGuuA4ZKxuZDV4pqBjDy3TQJP4494HDdVceaVJKecNvqATd76UPe/7
# 4ytaEB9NViiienLgEjq3SV7Y7e1DkYPZe7J7hhvZPrGMXeiJT4Qa8qEvWeSQOy2u
# M1jFtz7+MtOzAz2xsq+SOH7SnYAs9U5WkSE1JcM5bmR/U7qcD60ZI4TL9LoDho33
# X/DQUr+MlIe8wCF0JV8YKLbMJyg4JZg5SjbPfLGSrhwjp6lm7GEfauEoSZ1fiOIl
# XdMhSz5SxLVXPyQD8NF6Wy/VI+NwXQ9RRnez+ADhvKwCgl/bwBWzvRvUVUvnOaEP
# 6SNJvBi4RHxF5MHDcnrgcuck379GmcXvwhxX24ON7E1JMKerjt/sW5+v/N2wZuLB
# l4F77dbtS+dJKacTKKanfWeA5opieF+yL4TXV5xcv3coKPHtbcMojyyPQDdPweGF
# RInECUzF1KVDL3SV9274eCBYLBNdYJWaPk8zhNqwiBfenk70lrC8RqBsmNLg1oiM
# CwIDAQABo4IB7TCCAekwEAYJKwYBBAGCNxUBBAMCAQAwHQYDVR0OBBYEFEhuZOVQ
# BdOCqhc3NyK1bajKdQKVMBkGCSsGAQQBgjcUAgQMHgoAUwB1AGIAQwBBMAsGA1Ud
# DwQEAwIBhjAPBgNVHRMBAf8EBTADAQH/MB8GA1UdIwQYMBaAFHItOgIxkEO5FAVO
# 4eqnxzHRI4k0MFoGA1UdHwRTMFEwT6BNoEuGSWh0dHA6Ly9jcmwubWljcm9zb2Z0
# LmNvbS9wa2kvY3JsL3Byb2R1Y3RzL01pY1Jvb0NlckF1dDIwMTFfMjAxMV8wM18y
# Mi5jcmwwXgYIKwYBBQUHAQEEUjBQME4GCCsGAQUFBzAChkJodHRwOi8vd3d3Lm1p
# Y3Jvc29mdC5jb20vcGtpL2NlcnRzL01pY1Jvb0NlckF1dDIwMTFfMjAxMV8wM18y
# Mi5jcnQwgZ8GA1UdIASBlzCBlDCBkQYJKwYBBAGCNy4DMIGDMD8GCCsGAQUFBwIB
# FjNodHRwOi8vd3d3Lm1pY3Jvc29mdC5jb20vcGtpb3BzL2RvY3MvcHJpbWFyeWNw
# cy5odG0wQAYIKwYBBQUHAgIwNB4yIB0ATABlAGcAYQBsAF8AcABvAGwAaQBjAHkA
# XwBzAHQAYQB0AGUAbQBlAG4AdAAuIB0wDQYJKoZIhvcNAQELBQADggIBAGfyhqWY
# 4FR5Gi7T2HRnIpsLlhHhY5KZQpZ90nkMkMFlXy4sPvjDctFtg/6+P+gKyju/R6mj
# 82nbY78iNaWXXWWEkH2LRlBV2AySfNIaSxzzPEKLUtCw/WvjPgcuKZvmPRul1LUd
# d5Q54ulkyUQ9eHoj8xN9ppB0g430yyYCRirCihC7pKkFDJvtaPpoLpWgKj8qa1hJ
# Yx8JaW5amJbkg/TAj/NGK978O9C9Ne9uJa7lryft0N3zDq+ZKJeYTQ49C/IIidYf
# wzIY4vDFLc5bnrRJOQrGCsLGra7lstnbFYhRRVg4MnEnGn+x9Cf43iw6IGmYslmJ
# aG5vp7d0w0AFBqYBKig+gj8TTWYLwLNN9eGPfxxvFX1Fp3blQCplo8NdUmKGwx1j
# NpeG39rz+PIWoZon4c2ll9DuXWNB41sHnIc+BncG0QaxdR8UvmFhtfDcxhsEvt9B
# xw4o7t5lL+yX9qFcltgA1qFGvVnzl6UJS0gQmYAf0AApxbGbpT9Fdx41xtKiop96
# eiL6SJUfq/tHI4D1nvi/a7dLl+LrdXga7Oo3mXkYS//WsyNodeav+vyL6wuA6mk7
# r/ww7QRMjt/fdW1jkT3RnVZOT7+AVyKheBEyIXrvQQqxP/uozKRdwaGIm1dxVk5I
# RcBCyZt2WwqASGv9eZ/BvW1taslScxMNelDNMYIVdTCCFXECAQEwgZUwfjELMAkG
# A1UEBhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQx
# HjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEoMCYGA1UEAxMfTWljcm9z
# b2Z0IENvZGUgU2lnbmluZyBQQ0EgMjAxMQITMwAAAVGejY9AcaMOQQAAAAABUTAN
# BglghkgBZQMEAgEFAKCByDAZBgkqhkiG9w0BCQMxDAYKKwYBBAGCNwIBBDAcBgor
# BgEEAYI3AgELMQ4wDAYKKwYBBAGCNwIBFTAvBgkqhkiG9w0BCQQxIgQgUDtpiwQV
# u60ge/kQL2abt9Q7aZvXqf0vHxOSbFN8vQswXAYKKwYBBAGCNwIBDDFOMEygLoAs
# AFIAZQB0AGEAaQBsAE0AaQBuAG8AcgBVAHAAZwByAGEAZABlAC4AcABzADGhGoAY
# aHR0cDovL3d3dy5taWNyb3NvZnQuY29tMA0GCSqGSIb3DQEBAQUABIIBAHBpnV5R
# jb/wTmXHqhQRlxX0mby3bLHHmlrNBvCB7uPYBNndGBtW9K+s8zVYattVLRCJMw5R
# mMkpYP+p/X4o4yw/9smLjCqKY0WkngO2fAlS6CAV+u5+JqlNEEUdQ8opmnrZ+xwB
# oOgI7xpd3OHsNUlXbpkNUGhFaDZUjZNKZ/wwrHqc+rvUVNDDL/AkizFcEEdh49V9
# oMzPiXq7LE3RVuqFDem8lHa1tXq/yhpdHo3QvkhHXlaIq8t2ZOjdtTY7lI7PBZNJ
# Q/INrx1quWZKY8BBE2lIQ6uC1aIWtdAOpwM28zN4SZb5OmKiVLpk/UCms3lvtcne
# 6YNhNLOYphJsT4yhghLlMIIS4QYKKwYBBAGCNwMDATGCEtEwghLNBgkqhkiG9w0B
# BwKgghK+MIISugIBAzEPMA0GCWCGSAFlAwQCAQUAMIIBUQYLKoZIhvcNAQkQAQSg
# ggFABIIBPDCCATgCAQEGCisGAQQBhFkKAwEwMTANBglghkgBZQMEAgEFAAQgnjET
# 9cQ7ThpNTh0R8P2eKscmnohqax0XuXhriZbDccwCBl1gildCXxgTMjAxOTA4Mjcw
# NzIzMzYuNTAzWjAEgAIB9KCB0KSBzTCByjELMAkGA1UEBhMCVVMxCzAJBgNVBAgT
# AldBMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9y
# YXRpb24xLTArBgNVBAsTJE1pY3Jvc29mdCBJcmVsYW5kIE9wZXJhdGlvbnMgTGlt
# aXRlZDEmMCQGA1UECxMdVGhhbGVzIFRTUyBFU046OEQ0MS00QkY3LUIzQjcxJTAj
# BgNVBAMTHE1pY3Jvc29mdCBUaW1lLVN0YW1wIHNlcnZpY2Wggg48MIIE8TCCA9mg
# AwIBAgITMwAAANmqlgpRy5tL5gAAAAAA2TANBgkqhkiG9w0BAQsFADB8MQswCQYD
# VQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEe
# MBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMSYwJAYDVQQDEx1NaWNyb3Nv
# ZnQgVGltZS1TdGFtcCBQQ0EgMjAxMDAeFw0xODA4MjMyMDI2NTJaFw0xOTExMjMy
# MDI2NTJaMIHKMQswCQYDVQQGEwJVUzELMAkGA1UECBMCV0ExEDAOBgNVBAcTB1Jl
# ZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEtMCsGA1UECxMk
# TWljcm9zb2Z0IElyZWxhbmQgT3BlcmF0aW9ucyBMaW1pdGVkMSYwJAYDVQQLEx1U
# aGFsZXMgVFNTIEVTTjo4RDQxLTRCRjctQjNCNzElMCMGA1UEAxMcTWljcm9zb2Z0
# IFRpbWUtU3RhbXAgc2VydmljZTCCASIwDQYJKoZIhvcNAQEBBQADggEPADCCAQoC
# ggEBAK4ui9Kjs3PXoxuSwLEk9YGfAovIVOp97Ss2P/YptQwd4LZIDTX1kur85PbI
# ce9W8O/wAmjU+p9vKiaXky74WfLth7lXztHz5EHeTqbGBIOqe5+zfDYRAqVlP4cR
# 6/GrKRSAxUiKrLSK4mQfl1bCTKEPToTTK39B4o1PqKx3e9DrW43zrcKcnEZ0IcEO
# 1FXpuhgyHcWmQY02KaTcYQxXddS+p5RbPgmk4QsPeQvhiLU9GaNJFnXopszlXwKD
# lNvivsxvx8bgVCXkiM2uhCDng2Cm4Pij2+jUjl3bCZd4KDmOklzgM2R/RpuhhwOn
# qzUNyb9X6mFMPRCD5JkYp0utxH0CAwEAAaOCARswggEXMB0GA1UdDgQWBBRQ651G
# Zqfcnx2nzjdoZHelFBuOPTAfBgNVHSMEGDAWgBTVYzpcijGQ80N7fEYbxTNoWoVt
# VTBWBgNVHR8ETzBNMEugSaBHhkVodHRwOi8vY3JsLm1pY3Jvc29mdC5jb20vcGtp
# L2NybC9wcm9kdWN0cy9NaWNUaW1TdGFQQ0FfMjAxMC0wNy0wMS5jcmwwWgYIKwYB
# BQUHAQEETjBMMEoGCCsGAQUFBzAChj5odHRwOi8vd3d3Lm1pY3Jvc29mdC5jb20v
# cGtpL2NlcnRzL01pY1RpbVN0YVBDQV8yMDEwLTA3LTAxLmNydDAMBgNVHRMBAf8E
# AjAAMBMGA1UdJQQMMAoGCCsGAQUFBwMIMA0GCSqGSIb3DQEBCwUAA4IBAQCeaDes
# 2uzE06QMWFAvYUpRNcicfeNJRJif1z4934nQkuhDK78ZwRCSGKpkocINNl0/+L6b
# BjfW+CY0BZ2Fz/lKzkw9PTMJYuyr0UL1D+KAklPQKmejzJyDBeLNWQrovNuKFEOx
# hRbTXo993dUDEQztuL9uwNjvzlfgQOKvH3WbEjb0GZMDysH3kFR9hrcYRT0ZiX/3
# hUgW3F3HbxRNpHA+d2fTbz9Ep7absJtkzQ2BOX8/WB1LV02BEEx/cLhHcRMisv3I
# DF+0QBgNUVWwPgjnFJEMAWKoLmzZ6WKad9MhyXRKASH50s1RGQ+4lrENFYPHdFST
# pHqmqvs0DLyXpoGCMIIGcTCCBFmgAwIBAgIKYQmBKgAAAAAAAjANBgkqhkiG9w0B
# AQsFADCBiDELMAkGA1UEBhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAOBgNV
# BAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEyMDAG
# A1UEAxMpTWljcm9zb2Z0IFJvb3QgQ2VydGlmaWNhdGUgQXV0aG9yaXR5IDIwMTAw
# HhcNMTAwNzAxMjEzNjU1WhcNMjUwNzAxMjE0NjU1WjB8MQswCQYDVQQGEwJVUzET
# MBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UEChMV
# TWljcm9zb2Z0IENvcnBvcmF0aW9uMSYwJAYDVQQDEx1NaWNyb3NvZnQgVGltZS1T
# dGFtcCBQQ0EgMjAxMDCCASIwDQYJKoZIhvcNAQEBBQADggEPADCCAQoCggEBAKkd
# Dbx3EYo6IOz8E5f1+n9plGt0VBDVpQoAgoX77XxoSyxfxcPlYcJ2tz5mK1vwFVMn
# BDEfQRsalR3OCROOfGEwWbEwRA/xYIiEVEMM1024OAizQt2TrNZzMFcmgqNFDdDq
# 9UeBzb8kYDJYYEbyWEeGMoQedGFnkV+BVLHPk0ySwcSmXdFhE24oxhr5hoC732H8
# RsEnHSRnEnIaIYqvS2SJUGKxXf13Hz3wV3WsvYpCTUBR0Q+cBj5nf/VmwAOWRH7v
# 0Ev9buWayrGo8noqCjHw2k4GkbaICDXoeByw6ZnNPOcvRLqn9NxkvaQBwSAJk3jN
# /LzAyURdXhacAQVPIk0CAwEAAaOCAeYwggHiMBAGCSsGAQQBgjcVAQQDAgEAMB0G
# A1UdDgQWBBTVYzpcijGQ80N7fEYbxTNoWoVtVTAZBgkrBgEEAYI3FAIEDB4KAFMA
# dQBiAEMAQTALBgNVHQ8EBAMCAYYwDwYDVR0TAQH/BAUwAwEB/zAfBgNVHSMEGDAW
# gBTV9lbLj+iiXGJo0T2UkFvXzpoYxDBWBgNVHR8ETzBNMEugSaBHhkVodHRwOi8v
# Y3JsLm1pY3Jvc29mdC5jb20vcGtpL2NybC9wcm9kdWN0cy9NaWNSb29DZXJBdXRf
# MjAxMC0wNi0yMy5jcmwwWgYIKwYBBQUHAQEETjBMMEoGCCsGAQUFBzAChj5odHRw
# Oi8vd3d3Lm1pY3Jvc29mdC5jb20vcGtpL2NlcnRzL01pY1Jvb0NlckF1dF8yMDEw
# LTA2LTIzLmNydDCBoAYDVR0gAQH/BIGVMIGSMIGPBgkrBgEEAYI3LgMwgYEwPQYI
# KwYBBQUHAgEWMWh0dHA6Ly93d3cubWljcm9zb2Z0LmNvbS9QS0kvZG9jcy9DUFMv
# ZGVmYXVsdC5odG0wQAYIKwYBBQUHAgIwNB4yIB0ATABlAGcAYQBsAF8AUABvAGwA
# aQBjAHkAXwBTAHQAYQB0AGUAbQBlAG4AdAAuIB0wDQYJKoZIhvcNAQELBQADggIB
# AAfmiFEN4sbgmD+BcQM9naOhIW+z66bM9TG+zwXiqf76V20ZMLPCxWbJat/15/B4
# vceoniXj+bzta1RXCCtRgkQS+7lTjMz0YBKKdsxAQEGb3FwX/1z5Xhc1mCRWS3Tv
# QhDIr79/xn/yN31aPxzymXlKkVIArzgPF/UveYFl2am1a+THzvbKegBvSzBEJCI8
# z+0DpZaPWSm8tv0E4XCfMkon/VWvL/625Y4zu2JfmttXQOnxzplmkIz/amJ/3cVK
# C5Em4jnsGUpxY517IW3DnKOiPPp/fZZqkHimbdLhnPkd/DjYlPTGpQqWhqS9nhqu
# BEKDuLWAmyI4ILUl5WTs9/S/fmNZJQ96LjlXdqJxqgaKD4kWumGnEcua2A5HmoDF
# 0M2n0O99g/DhO3EJ3110mCIIYdqwUB5vvfHhAN/nMQekkzr3ZUd46PioSKv33nJ+
# YWtvd6mBy6cJrDm77MbL2IK0cs0d9LiFAR6A+xuJKlQ5slvayA1VmXqHczsI5pgt
# 6o3gMy4SKfXAL1QnIffIrE7aKLixqduWsqdCosnPGUFN4Ib5KpqjEWYw07t0Mkvf
# Y3v1mYovG8chr1m1rtxEPJdQcdeh0sVV42neV8HR3jDA/czmTfsNv11P6Z0eGTgv
# vM9YBS7vDaBQNdrvCScc1bN+NR4Iuto229Nfj950iEkSoYICzjCCAjcCAQEwgfih
# gdCkgc0wgcoxCzAJBgNVBAYTAlVTMQswCQYDVQQIEwJXQTEQMA4GA1UEBxMHUmVk
# bW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMS0wKwYDVQQLEyRN
# aWNyb3NvZnQgSXJlbGFuZCBPcGVyYXRpb25zIExpbWl0ZWQxJjAkBgNVBAsTHVRo
# YWxlcyBUU1MgRVNOOjhENDEtNEJGNy1CM0I3MSUwIwYDVQQDExxNaWNyb3NvZnQg
# VGltZS1TdGFtcCBzZXJ2aWNloiMKAQEwBwYFKw4DAhoDFQC//EreiaQMh6prbQbz
# f59LukktoaCBgzCBgKR+MHwxCzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5n
# dG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9y
# YXRpb24xJjAkBgNVBAMTHU1pY3Jvc29mdCBUaW1lLVN0YW1wIFBDQSAyMDEwMA0G
# CSqGSIb3DQEBBQUAAgUA4Q79TjAiGA8yMDE5MDgyNzA4NTIzMFoYDzIwMTkwODI4
# MDg1MjMwWjB3MD0GCisGAQQBhFkKBAExLzAtMAoCBQDhDv1OAgEAMAoCAQACAhvu
# AgH/MAcCAQACAhF/MAoCBQDhEE7OAgEAMDYGCisGAQQBhFkKBAIxKDAmMAwGCisG
# AQQBhFkKAwKgCjAIAgEAAgMHoSChCjAIAgEAAgMBhqAwDQYJKoZIhvcNAQEFBQAD
# gYEAoGa7jwIZeYfyKfp8C+tor8cduARzz63SFNy83IVv/Rv5H/93dJkMBJV8T1IR
# MxRhP31RgverndrDhuHVPnUONFd/sDcPJK4GAQURHzdivj63h4rP149GuGCm9S88
# yV3cp3Ydfn7h5mud3/R2dmZSQD/6MX5Y75qvjSXAa7AHXXcxggMNMIIDCQIBATCB
# kzB8MQswCQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMH
# UmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMSYwJAYDVQQD
# Ex1NaWNyb3NvZnQgVGltZS1TdGFtcCBQQ0EgMjAxMAITMwAAANmqlgpRy5tL5gAA
# AAAA2TANBglghkgBZQMEAgEFAKCCAUowGgYJKoZIhvcNAQkDMQ0GCyqGSIb3DQEJ
# EAEEMC8GCSqGSIb3DQEJBDEiBCD7Dq3uYwdvjaUeCOw2cWNhC609wvH7j5ew6zLV
# A78aqjCB+gYLKoZIhvcNAQkQAi8xgeowgecwgeQwgb0EINIsifIfKK2PQTe/ypSm
# yxPoEvAiCgjnk0WIaC0O2pNxMIGYMIGApH4wfDELMAkGA1UEBhMCVVMxEzARBgNV
# BAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jv
# c29mdCBDb3Jwb3JhdGlvbjEmMCQGA1UEAxMdTWljcm9zb2Z0IFRpbWUtU3RhbXAg
# UENBIDIwMTACEzMAAADZqpYKUcubS+YAAAAAANkwIgQgmAYBoqCCaOkCIZLJ+IIY
# YsJwJZ9QFK83Vem1P4B/P/wwDQYJKoZIhvcNAQELBQAEggEAhiebDcYyKttWYWTH
# 2PCvpKQ3Cc4thT9ALUWcJZPXFgt61BmQz2uJJNcf8Ll34BjCOkrLfeGr93STyGFn
# nlRwG84mM2PKFlEM5hSP8qTPe0NZPJF1r061Dk4FB/vhJr1BvKdPXYaDi4kSCtKH
# BfnL7ORKXu30ZOMbR6SWrMC8vc4X69FH39Hv6BoAz9abB9ku2lL1nchde1j4T+jj
# t8SUgBwBonEQsJuCFvS4LcymfhTW2ke4NXWz4VTs2cGBc6oCkGvKckdhY1XzjbVU
# INSVqbSqn+CsErQBs8zHfN6Fx5w3tkNsQLL+5NRXc2VufhWOr/MbJI0TE30g4GX6
# g5nF7w==
# SIG # End signature block
