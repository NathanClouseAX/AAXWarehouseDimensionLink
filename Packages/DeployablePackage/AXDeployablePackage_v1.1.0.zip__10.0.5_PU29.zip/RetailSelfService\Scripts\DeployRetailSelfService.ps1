<#
SAMPLE CODE NOTICE

THIS SAMPLE CODE IS MADE AVAILABLE AS IS.  MICROSOFT MAKES NO WARRANTIES, WHETHER EXPRESS OR IMPLIED, 
OF FITNESS FOR A PARTICULAR PURPOSE, OF ACCURACY OR COMPLETENESS OF RESPONSES, OF RESULTS, OR CONDITIONS OF MERCHANTABILITY.
THE ENTIRE RISK OF THE USE OR THE RESULTS FROM THE USE OF THIS SAMPLE CODE REMAINS WITH THE USER.  
NO TECHNICAL SUPPORT IS PROVIDED.  YOU MAY NOT DISTRIBUTE THIS CODE UNLESS YOU HAVE A LICENSE AGREEMENT WITH MICROSOFT THAT ALLOWS YOU TO DO SO.
#>

param(
    [string]$config = $(Throw 'config parameter required'),
    [string]$log = $(Throw 'log parameter required'))

function Copy-Files(
    [string]$SourceDirPath = $(Throw 'SourceDirPath parameter required'),
    [string]$DestinationDirPath = $(Throw 'DestinationDirPath parameter required'),
    [string]$FilesToCopy = '*',
    [string]$LogFile)
{
    $global:LASTEXITCODE = 0
    $output = robocopy.exe /E $SourceDirPath $DestinationDirPath $FilesToCopy

    $capturedExitCode = $global:LASTEXITCODE

    Write-Log $output -logFile $LogFile

    #Robocopy Exit codes related info: http://support.microsoft.com/kb/954404
    if(($capturedExitCode -ge 0) -and ($capturedExitCode -le 8))
    {
        Write-Log "[Robocopy] completed successfully." -logFile $LogFile
    }
    else
    {
        throw "[Robocopy] failed with exit code $capturedExitCode"
    }
}

function Copy-SelfServiceArtifacts(
    [string]$TargetPackagesPath = $(Throw 'TargetPackagesPath parameter required'),
    [string]$TargetScriptsPath = $(Throw 'TargetScriptsPath parameter required'),
    [string]$SourceDirectory = $(Throw 'SourceDirectory parameter required'),
    [string]$LogFile)
{
    Write-Log "Starting to copy self service artifacts." -logFile $LogFile

    # Source location for self-service packages and scripts
    $sourceSelfServicePkgLocation = Join-Path -Path $SourceDirectory -ChildPath 'Packages'
    $sourceSelfServiceScriptLocation = Join-Path -Path $SourceDirectory -ChildPath 'Scripts'

    Write-Log ("Copying self-service packages from: '{0}' to: '{1}'" -f $sourceSelfServicePkgLocation, $TargetPackagesPath) -logFile $LogFile
    Copy-Files $sourceSelfServicePkgLocation $TargetPackagesPath -logFile  $LogFile

    Write-Log ("Copying self-service scripts from: '{0}' to: '{1}'" -f $sourceSelfServiceScriptLocation, $TargetScriptsPath) -logFile $LogFile
    Copy-Files $sourceSelfServiceScriptLocation $TargetScriptsPath -logFile  $LogFile

    Write-Log "Finished copying self service artifacts." -logFile $LogFile
}

function ConvertDomainUser-ToSID(
    [string]$DomainUser = $(Throw 'DomainUser parameter is required')
)
{
    $domainName = $DomainUser.Split('\')[0]
    $userName = $DomainUser.Split('\')[1]

    $userObject = New-Object System.Security.Principal.NTAccount($domainName, $userName)
    $SIDString = $userObject.Translate([System.Security.Principal.SecurityIdentifier])

    return $SIDString.Value
}

function Add-UserPermissionsToFolder(
    [string]$Folder = $(Throw 'Folder parameter is required'),
    [string]$UserSID = $(Throw 'UserSID parameter is required')
)
{
    $identity = New-Object System.Security.Principal.SecurityIdentifier($UserSID)

    $acl = (Get-Item $Folder).GetAccessControl('Access')
    $aclRule = New-Object System.Security.AccessControl.FileSystemAccessRule($identity,'FullControl','ContainerInherit,ObjectInherit','None','Allow')

    $acl.SetAccessRule($aclRule)
    $acl | Set-Acl $Folder
}

function Configure-SelfServicePackages(
    [string]$SelfServicePackagesDirectory = $(Throw 'SelfServicePackagesDirectory parameter required'),
    [string]$SelfServiceScriptsDirectory = $(Throw 'SelfServiceScriptsDirectory parameter required'),
    [string]$AosWebsiteName = $(Throw 'AosWebsiteName parameter required'),
    [string]$AOSServiceUser = $(Throw 'AOSServiceUser parameter required'),
    [string]$LogFile = $(Throw 'LogFile parameter required'))
{
    # Add permissions for IIS_IUSRS and AOSServiceUser to self-service packages folder.
    Write-Log "Granting permissions to IIS_IUSRS." -logFile $LogFile

    Add-UserPermissionsToFolder -Folder $SelfServicePackagesDirectory -UserSID 'S-1-5-32-568'
    Write-Log ("Finished granting permissions to IIS_IUSRS for '{0}'" -f $SelfServicePackagesDirectory) -logFile $LogFile

    if ([System.String]::Equals($AOSServiceUser, "NETWORK_SERVICE", [System.StringComparison]::OrdinalIgnoreCase))
    {
        # "S-1-5-20" is a well-known SID for NETWORK_SERVICE. Please refer: http://msdn.microsoft.com/en-us/library/cc980032.aspx
        Write-Log "Granting permissions to NETWORK_SERVICE." -logFile $LogFile
        
        Add-UserPermissionsToFolder -Folder $SelfServicePackagesDirectory -UserSID 'S-1-5-20'
        Write-Log ("Finished granting permissions to NETWORK_SERVICE for '{0}'" -f $SelfServicePackagesDirectory) -logFile $LogFile
    }
    else
    {
        $userSID = ConvertDomainUser-ToSID -DomainUser  $AOSServiceUser
        Write-Log ("Granting permissions to '{0}'." -f $AOSServiceUser) -logFile $LogFile

        Add-UserPermissionsToFolder -Folder $SelfServicePackagesDirectory -UserSID $userSID
        Write-Log ("Finished granting permissions to '{0}' for '{1}'" -f $AOSServiceUser, $SelfServicePackagesDirectory) -logFile $LogFile
    }

    # Record Self-Service metadata in registry
    $selfServiceLocationRegistryPath = 'HKLM:\SOFTWARE\Microsoft\Dynamics\7.0\RetailSelfService'
    Write-Log ("Updating self service packages location in registry: '{0}'" -f $selfServiceLocationRegistryPath) -logFile $LogFile

    New-Item -Path $selfServiceLocationRegistryPath -ItemType Directory -Force
    New-ItemProperty -Path $selfServiceLocationRegistryPath -Name (Get-SelfServicePkgLocationRegKeyName) -Value $SelfServicePackagesDirectory
    New-ItemProperty -Path $selfServiceLocationRegistryPath -Name (Get-SelfServiceScriptsLocationRegKeyName) -Value $SelfServiceScriptsDirectory
    New-ItemProperty -Path $selfServiceLocationRegistryPath -Name (Get-SelfServiceAOSWebsiteRegKeyName) -Value $AosWebsiteName

    Write-Log "Finished updating self service packages location in registry." -logFile $LogFile
}

try
{
    $scriptDir = Split-Path -Path $MyInvocation.MyCommand.Path -Parent
    Import-Module (Join-Path -Path $scriptDir -ChildPath 'SelfServiceConfiguration.psm1') -DisableNameChecking

    $settings = @{}
    if (-not($config))
    {
        Write-Log -objectToLog 'The config parameter cannot be empty!' -logFile $log
        Throw 'The config parameter cannot be empty!'
    }

    # Decode all config values
    Write-Log -objectToLog ("Input configuration string: {0}" -f $config) -logFile $log
    $decodedConfig = [System.Text.Encoding]::UTF8.GetString([System.Convert]::FromBase64String($config))

    $settings = ConvertFrom-Json $decodedConfig
    Write-Log -objectToLog ("Decoded configuration string: {0}" -f $settings) -logFile $log

    # Read all decoded config values
    $AOSWebsiteName = $($settings.AOSWebsiteName)
    $AOSServiceUser = $($settings.AOSServiceUser)

    $targetPackagesFolder = $($settings.PackagesDropLocation)
    $targetScriptsFolder = $($settings.ScriptsDropLocation)

    # Copy Self-Service packages and scripts to correct location
    $retailSelfServiceRootFolder = (Get-Item $scriptDir).Parent.FullName
    Copy-SelfServiceArtifacts -TargetPackagesPath $targetPackagesFolder `
                              -TargetScriptsPath $targetScriptsFolder `
                              -SourceDirectory $retailSelfServiceRootFolder `
                              -LogFile $log

    # Configure Self-Service packages
    Configure-SelfServicePackages -SelfServicePackagesDirectory $targetPackagesFolder `
                                  -SelfServiceScriptsDirectory $targetScriptsFolder `
                                  -AosWebsiteName $AOSWebsiteName `
                                  -AOSServiceUser $AOSServiceUser `
                                  -logFile $log
}
catch
{
    Write-Log ($global:error[0] | Format-List * -Force | Out-String -Width 4096) -logFile $log
    $ScriptLine = "{0}{1}" -f $MyInvocation.MyCommand.Path.ToString(), [System.Environment]::NewLine

    # Set a non-zero unique exit code for RetailSelfService deploy failure
    $exitCode = 24741
    Write-Log ("Executed:{0}$ScriptLine{0}Exiting with error code $exitCode." -f [System.Environment]::NewLine) -logFile $log
    exit $exitCode
}


# SIG # Begin signature block
# MIIjoAYJKoZIhvcNAQcCoIIjkTCCI40CAQExDzANBglghkgBZQMEAgEFADB5Bgor
# BgEEAYI3AgEEoGswaTA0BgorBgEEAYI3AgEeMCYCAwEAAAQQH8w7YFlLCE63JNLG
# KX7zUQIBAAIBAAIBAAIBAAIBADAxMA0GCWCGSAFlAwQCAQUABCDc1RVooPUb/Qn2
# RjtBA4HhdyxywkNfVcE3oEW7dv1Ne6CCDYEwggX/MIID56ADAgECAhMzAAABUZ6N
# j0Bxow5BAAAAAAFRMA0GCSqGSIb3DQEBCwUAMH4xCzAJBgNVBAYTAlVTMRMwEQYD
# VQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNy
# b3NvZnQgQ29ycG9yYXRpb24xKDAmBgNVBAMTH01pY3Jvc29mdCBDb2RlIFNpZ25p
# bmcgUENBIDIwMTEwHhcNMTkwNTAyMjEzNzQ2WhcNMjAwNTAyMjEzNzQ2WjB0MQsw
# CQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9u
# ZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMR4wHAYDVQQDExVNaWNy
# b3NvZnQgQ29ycG9yYXRpb24wggEiMA0GCSqGSIb3DQEBAQUAA4IBDwAwggEKAoIB
# AQCVWsaGaUcdNB7xVcNmdfZiVBhYFGcn8KMqxgNIvOZWNH9JYQLuhHhmJ5RWISy1
# oey3zTuxqLbkHAdmbeU8NFMo49Pv71MgIS9IG/EtqwOH7upan+lIq6NOcw5fO6Os
# +12R0Q28MzGn+3y7F2mKDnopVu0sEufy453gxz16M8bAw4+QXuv7+fR9WzRJ2CpU
# 62wQKYiFQMfew6Vh5fuPoXloN3k6+Qlz7zgcT4YRmxzx7jMVpP/uvK6sZcBxQ3Wg
# B/WkyXHgxaY19IAzLq2QiPiX2YryiR5EsYBq35BP7U15DlZtpSs2wIYTkkDBxhPJ
# IDJgowZu5GyhHdqrst3OjkSRAgMBAAGjggF+MIIBejAfBgNVHSUEGDAWBgorBgEE
# AYI3TAgBBggrBgEFBQcDAzAdBgNVHQ4EFgQUV4Iarkq57esagu6FUBb270Zijc8w
# UAYDVR0RBEkwR6RFMEMxKTAnBgNVBAsTIE1pY3Jvc29mdCBPcGVyYXRpb25zIFB1
# ZXJ0byBSaWNvMRYwFAYDVQQFEw0yMzAwMTIrNDU0MTM1MB8GA1UdIwQYMBaAFEhu
# ZOVQBdOCqhc3NyK1bajKdQKVMFQGA1UdHwRNMEswSaBHoEWGQ2h0dHA6Ly93d3cu
# bWljcm9zb2Z0LmNvbS9wa2lvcHMvY3JsL01pY0NvZFNpZ1BDQTIwMTFfMjAxMS0w
# Ny0wOC5jcmwwYQYIKwYBBQUHAQEEVTBTMFEGCCsGAQUFBzAChkVodHRwOi8vd3d3
# Lm1pY3Jvc29mdC5jb20vcGtpb3BzL2NlcnRzL01pY0NvZFNpZ1BDQTIwMTFfMjAx
# MS0wNy0wOC5jcnQwDAYDVR0TAQH/BAIwADANBgkqhkiG9w0BAQsFAAOCAgEAWg+A
# rS4Anq7KrogslIQnoMHSXUPr/RqOIhJX+32ObuY3MFvdlRElbSsSJxrRy/OCCZdS
# se+f2AqQ+F/2aYwBDmUQbeMB8n0pYLZnOPifqe78RBH2fVZsvXxyfizbHubWWoUf
# NW/FJlZlLXwJmF3BoL8E2p09K3hagwz/otcKtQ1+Q4+DaOYXWleqJrJUsnHs9UiL
# crVF0leL/Q1V5bshob2OTlZq0qzSdrMDLWdhyrUOxnZ+ojZ7UdTY4VnCuogbZ9Zs
# 9syJbg7ZUS9SVgYkowRsWv5jV4lbqTD+tG4FzhOwcRQwdb6A8zp2Nnd+s7VdCuYF
# sGgI41ucD8oxVfcAMjF9YX5N2s4mltkqnUe3/htVrnxKKDAwSYliaux2L7gKw+bD
# 1kEZ/5ozLRnJ3jjDkomTrPctokY/KaZ1qub0NUnmOKH+3xUK/plWJK8BOQYuU7gK
# YH7Yy9WSKNlP7pKj6i417+3Na/frInjnBkKRCJ/eYTvBH+s5guezpfQWtU4bNo/j
# 8Qw2vpTQ9w7flhH78Rmwd319+YTmhv7TcxDbWlyteaj4RK2wk3pY1oSz2JPE5PNu
# Nmd9Gmf6oePZgy7Ii9JLLq8SnULV7b+IP0UXRY9q+GdRjM2AEX6msZvvPCIoG0aY
# HQu9wZsKEK2jqvWi8/xdeeeSI9FN6K1w4oVQM4Mwggd6MIIFYqADAgECAgphDpDS
# AAAAAAADMA0GCSqGSIb3DQEBCwUAMIGIMQswCQYDVQQGEwJVUzETMBEGA1UECBMK
# V2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0
# IENvcnBvcmF0aW9uMTIwMAYDVQQDEylNaWNyb3NvZnQgUm9vdCBDZXJ0aWZpY2F0
# ZSBBdXRob3JpdHkgMjAxMTAeFw0xMTA3MDgyMDU5MDlaFw0yNjA3MDgyMTA5MDla
# MH4xCzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdS
# ZWRtb25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xKDAmBgNVBAMT
# H01pY3Jvc29mdCBDb2RlIFNpZ25pbmcgUENBIDIwMTEwggIiMA0GCSqGSIb3DQEB
# AQUAA4ICDwAwggIKAoICAQCr8PpyEBwurdhuqoIQTTS68rZYIZ9CGypr6VpQqrgG
# OBoESbp/wwwe3TdrxhLYC/A4wpkGsMg51QEUMULTiQ15ZId+lGAkbK+eSZzpaF7S
# 35tTsgosw6/ZqSuuegmv15ZZymAaBelmdugyUiYSL+erCFDPs0S3XdjELgN1q2jz
# y23zOlyhFvRGuuA4ZKxuZDV4pqBjDy3TQJP4494HDdVceaVJKecNvqATd76UPe/7
# 4ytaEB9NViiienLgEjq3SV7Y7e1DkYPZe7J7hhvZPrGMXeiJT4Qa8qEvWeSQOy2u
# M1jFtz7+MtOzAz2xsq+SOH7SnYAs9U5WkSE1JcM5bmR/U7qcD60ZI4TL9LoDho33
# X/DQUr+MlIe8wCF0JV8YKLbMJyg4JZg5SjbPfLGSrhwjp6lm7GEfauEoSZ1fiOIl
# XdMhSz5SxLVXPyQD8NF6Wy/VI+NwXQ9RRnez+ADhvKwCgl/bwBWzvRvUVUvnOaEP
# 6SNJvBi4RHxF5MHDcnrgcuck379GmcXvwhxX24ON7E1JMKerjt/sW5+v/N2wZuLB
# l4F77dbtS+dJKacTKKanfWeA5opieF+yL4TXV5xcv3coKPHtbcMojyyPQDdPweGF
# RInECUzF1KVDL3SV9274eCBYLBNdYJWaPk8zhNqwiBfenk70lrC8RqBsmNLg1oiM
# CwIDAQABo4IB7TCCAekwEAYJKwYBBAGCNxUBBAMCAQAwHQYDVR0OBBYEFEhuZOVQ
# BdOCqhc3NyK1bajKdQKVMBkGCSsGAQQBgjcUAgQMHgoAUwB1AGIAQwBBMAsGA1Ud
# DwQEAwIBhjAPBgNVHRMBAf8EBTADAQH/MB8GA1UdIwQYMBaAFHItOgIxkEO5FAVO
# 4eqnxzHRI4k0MFoGA1UdHwRTMFEwT6BNoEuGSWh0dHA6Ly9jcmwubWljcm9zb2Z0
# LmNvbS9wa2kvY3JsL3Byb2R1Y3RzL01pY1Jvb0NlckF1dDIwMTFfMjAxMV8wM18y
# Mi5jcmwwXgYIKwYBBQUHAQEEUjBQME4GCCsGAQUFBzAChkJodHRwOi8vd3d3Lm1p
# Y3Jvc29mdC5jb20vcGtpL2NlcnRzL01pY1Jvb0NlckF1dDIwMTFfMjAxMV8wM18y
# Mi5jcnQwgZ8GA1UdIASBlzCBlDCBkQYJKwYBBAGCNy4DMIGDMD8GCCsGAQUFBwIB
# FjNodHRwOi8vd3d3Lm1pY3Jvc29mdC5jb20vcGtpb3BzL2RvY3MvcHJpbWFyeWNw
# cy5odG0wQAYIKwYBBQUHAgIwNB4yIB0ATABlAGcAYQBsAF8AcABvAGwAaQBjAHkA
# XwBzAHQAYQB0AGUAbQBlAG4AdAAuIB0wDQYJKoZIhvcNAQELBQADggIBAGfyhqWY
# 4FR5Gi7T2HRnIpsLlhHhY5KZQpZ90nkMkMFlXy4sPvjDctFtg/6+P+gKyju/R6mj
# 82nbY78iNaWXXWWEkH2LRlBV2AySfNIaSxzzPEKLUtCw/WvjPgcuKZvmPRul1LUd
# d5Q54ulkyUQ9eHoj8xN9ppB0g430yyYCRirCihC7pKkFDJvtaPpoLpWgKj8qa1hJ
# Yx8JaW5amJbkg/TAj/NGK978O9C9Ne9uJa7lryft0N3zDq+ZKJeYTQ49C/IIidYf
# wzIY4vDFLc5bnrRJOQrGCsLGra7lstnbFYhRRVg4MnEnGn+x9Cf43iw6IGmYslmJ
# aG5vp7d0w0AFBqYBKig+gj8TTWYLwLNN9eGPfxxvFX1Fp3blQCplo8NdUmKGwx1j
# NpeG39rz+PIWoZon4c2ll9DuXWNB41sHnIc+BncG0QaxdR8UvmFhtfDcxhsEvt9B
# xw4o7t5lL+yX9qFcltgA1qFGvVnzl6UJS0gQmYAf0AApxbGbpT9Fdx41xtKiop96
# eiL6SJUfq/tHI4D1nvi/a7dLl+LrdXga7Oo3mXkYS//WsyNodeav+vyL6wuA6mk7
# r/ww7QRMjt/fdW1jkT3RnVZOT7+AVyKheBEyIXrvQQqxP/uozKRdwaGIm1dxVk5I
# RcBCyZt2WwqASGv9eZ/BvW1taslScxMNelDNMYIVdTCCFXECAQEwgZUwfjELMAkG
# A1UEBhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQx
# HjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEoMCYGA1UEAxMfTWljcm9z
# b2Z0IENvZGUgU2lnbmluZyBQQ0EgMjAxMQITMwAAAVGejY9AcaMOQQAAAAABUTAN
# BglghkgBZQMEAgEFAKCByDAZBgkqhkiG9w0BCQMxDAYKKwYBBAGCNwIBBDAcBgor
# BgEEAYI3AgELMQ4wDAYKKwYBBAGCNwIBFTAvBgkqhkiG9w0BCQQxIgQg5X2EJ4LF
# CXLh5znXANnHpuapXA3A0tmGecBqHk1EwYEwXAYKKwYBBAGCNwIBDDFOMEygLoAs
# AFIAZQB0AGEAaQBsAE0AaQBuAG8AcgBVAHAAZwByAGEAZABlAC4AcABzADGhGoAY
# aHR0cDovL3d3dy5taWNyb3NvZnQuY29tMA0GCSqGSIb3DQEBAQUABIIBABdvDymp
# TkCD/+M5DJwD3krFahjvTJfxyjwflzJRNFJVxqsDBsP/LwAp9pzMZ6Qq0FdAyGwW
# z0hklYv7dKzlzeAQrIWhTqmWF3me5x3kVHSPwWimLGr9IE9Mbt2YK6oD7MY3eBL4
# tQEYC2Sdbi4LWpPrvt6QH73v67LQzTUiVp+19fZgTbEthx90v79kslKhwnu/2pZi
# YmSzCpL5l72s852YG7DZPHnoj0+q/ayE47blGikl1CVK3m/AnQIkQoUR7AOrBxWo
# UyaOJlgmukq600cI7WXGaP2scn0geqGYz1w9EFU6toYi/z5z411qXNCLdfeWkRRv
# 5id0Rd5IT9sMeOShghLlMIIS4QYKKwYBBAGCNwMDATGCEtEwghLNBgkqhkiG9w0B
# BwKgghK+MIISugIBAzEPMA0GCWCGSAFlAwQCAQUAMIIBUQYLKoZIhvcNAQkQAQSg
# ggFABIIBPDCCATgCAQEGCisGAQQBhFkKAwEwMTANBglghkgBZQMEAgEFAAQgkkmL
# cTwzcoWjRJQsKshUyN4vbhuSQ0bgvmLnjBlN4DsCBl1gildCUxgTMjAxOTA4Mjcw
# NzIzMzYuMTcyWjAEgAIB9KCB0KSBzTCByjELMAkGA1UEBhMCVVMxCzAJBgNVBAgT
# AldBMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9y
# YXRpb24xLTArBgNVBAsTJE1pY3Jvc29mdCBJcmVsYW5kIE9wZXJhdGlvbnMgTGlt
# aXRlZDEmMCQGA1UECxMdVGhhbGVzIFRTUyBFU046OEQ0MS00QkY3LUIzQjcxJTAj
# BgNVBAMTHE1pY3Jvc29mdCBUaW1lLVN0YW1wIHNlcnZpY2Wggg48MIIE8TCCA9mg
# AwIBAgITMwAAANmqlgpRy5tL5gAAAAAA2TANBgkqhkiG9w0BAQsFADB8MQswCQYD
# VQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEe
# MBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMSYwJAYDVQQDEx1NaWNyb3Nv
# ZnQgVGltZS1TdGFtcCBQQ0EgMjAxMDAeFw0xODA4MjMyMDI2NTJaFw0xOTExMjMy
# MDI2NTJaMIHKMQswCQYDVQQGEwJVUzELMAkGA1UECBMCV0ExEDAOBgNVBAcTB1Jl
# ZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEtMCsGA1UECxMk
# TWljcm9zb2Z0IElyZWxhbmQgT3BlcmF0aW9ucyBMaW1pdGVkMSYwJAYDVQQLEx1U
# aGFsZXMgVFNTIEVTTjo4RDQxLTRCRjctQjNCNzElMCMGA1UEAxMcTWljcm9zb2Z0
# IFRpbWUtU3RhbXAgc2VydmljZTCCASIwDQYJKoZIhvcNAQEBBQADggEPADCCAQoC
# ggEBAK4ui9Kjs3PXoxuSwLEk9YGfAovIVOp97Ss2P/YptQwd4LZIDTX1kur85PbI
# ce9W8O/wAmjU+p9vKiaXky74WfLth7lXztHz5EHeTqbGBIOqe5+zfDYRAqVlP4cR
# 6/GrKRSAxUiKrLSK4mQfl1bCTKEPToTTK39B4o1PqKx3e9DrW43zrcKcnEZ0IcEO
# 1FXpuhgyHcWmQY02KaTcYQxXddS+p5RbPgmk4QsPeQvhiLU9GaNJFnXopszlXwKD
# lNvivsxvx8bgVCXkiM2uhCDng2Cm4Pij2+jUjl3bCZd4KDmOklzgM2R/RpuhhwOn
# qzUNyb9X6mFMPRCD5JkYp0utxH0CAwEAAaOCARswggEXMB0GA1UdDgQWBBRQ651G
# Zqfcnx2nzjdoZHelFBuOPTAfBgNVHSMEGDAWgBTVYzpcijGQ80N7fEYbxTNoWoVt
# VTBWBgNVHR8ETzBNMEugSaBHhkVodHRwOi8vY3JsLm1pY3Jvc29mdC5jb20vcGtp
# L2NybC9wcm9kdWN0cy9NaWNUaW1TdGFQQ0FfMjAxMC0wNy0wMS5jcmwwWgYIKwYB
# BQUHAQEETjBMMEoGCCsGAQUFBzAChj5odHRwOi8vd3d3Lm1pY3Jvc29mdC5jb20v
# cGtpL2NlcnRzL01pY1RpbVN0YVBDQV8yMDEwLTA3LTAxLmNydDAMBgNVHRMBAf8E
# AjAAMBMGA1UdJQQMMAoGCCsGAQUFBwMIMA0GCSqGSIb3DQEBCwUAA4IBAQCeaDes
# 2uzE06QMWFAvYUpRNcicfeNJRJif1z4934nQkuhDK78ZwRCSGKpkocINNl0/+L6b
# BjfW+CY0BZ2Fz/lKzkw9PTMJYuyr0UL1D+KAklPQKmejzJyDBeLNWQrovNuKFEOx
# hRbTXo993dUDEQztuL9uwNjvzlfgQOKvH3WbEjb0GZMDysH3kFR9hrcYRT0ZiX/3
# hUgW3F3HbxRNpHA+d2fTbz9Ep7absJtkzQ2BOX8/WB1LV02BEEx/cLhHcRMisv3I
# DF+0QBgNUVWwPgjnFJEMAWKoLmzZ6WKad9MhyXRKASH50s1RGQ+4lrENFYPHdFST
# pHqmqvs0DLyXpoGCMIIGcTCCBFmgAwIBAgIKYQmBKgAAAAAAAjANBgkqhkiG9w0B
# AQsFADCBiDELMAkGA1UEBhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAOBgNV
# BAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEyMDAG
# A1UEAxMpTWljcm9zb2Z0IFJvb3QgQ2VydGlmaWNhdGUgQXV0aG9yaXR5IDIwMTAw
# HhcNMTAwNzAxMjEzNjU1WhcNMjUwNzAxMjE0NjU1WjB8MQswCQYDVQQGEwJVUzET
# MBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UEChMV
# TWljcm9zb2Z0IENvcnBvcmF0aW9uMSYwJAYDVQQDEx1NaWNyb3NvZnQgVGltZS1T
# dGFtcCBQQ0EgMjAxMDCCASIwDQYJKoZIhvcNAQEBBQADggEPADCCAQoCggEBAKkd
# Dbx3EYo6IOz8E5f1+n9plGt0VBDVpQoAgoX77XxoSyxfxcPlYcJ2tz5mK1vwFVMn
# BDEfQRsalR3OCROOfGEwWbEwRA/xYIiEVEMM1024OAizQt2TrNZzMFcmgqNFDdDq
# 9UeBzb8kYDJYYEbyWEeGMoQedGFnkV+BVLHPk0ySwcSmXdFhE24oxhr5hoC732H8
# RsEnHSRnEnIaIYqvS2SJUGKxXf13Hz3wV3WsvYpCTUBR0Q+cBj5nf/VmwAOWRH7v
# 0Ev9buWayrGo8noqCjHw2k4GkbaICDXoeByw6ZnNPOcvRLqn9NxkvaQBwSAJk3jN
# /LzAyURdXhacAQVPIk0CAwEAAaOCAeYwggHiMBAGCSsGAQQBgjcVAQQDAgEAMB0G
# A1UdDgQWBBTVYzpcijGQ80N7fEYbxTNoWoVtVTAZBgkrBgEEAYI3FAIEDB4KAFMA
# dQBiAEMAQTALBgNVHQ8EBAMCAYYwDwYDVR0TAQH/BAUwAwEB/zAfBgNVHSMEGDAW
# gBTV9lbLj+iiXGJo0T2UkFvXzpoYxDBWBgNVHR8ETzBNMEugSaBHhkVodHRwOi8v
# Y3JsLm1pY3Jvc29mdC5jb20vcGtpL2NybC9wcm9kdWN0cy9NaWNSb29DZXJBdXRf
# MjAxMC0wNi0yMy5jcmwwWgYIKwYBBQUHAQEETjBMMEoGCCsGAQUFBzAChj5odHRw
# Oi8vd3d3Lm1pY3Jvc29mdC5jb20vcGtpL2NlcnRzL01pY1Jvb0NlckF1dF8yMDEw
# LTA2LTIzLmNydDCBoAYDVR0gAQH/BIGVMIGSMIGPBgkrBgEEAYI3LgMwgYEwPQYI
# KwYBBQUHAgEWMWh0dHA6Ly93d3cubWljcm9zb2Z0LmNvbS9QS0kvZG9jcy9DUFMv
# ZGVmYXVsdC5odG0wQAYIKwYBBQUHAgIwNB4yIB0ATABlAGcAYQBsAF8AUABvAGwA
# aQBjAHkAXwBTAHQAYQB0AGUAbQBlAG4AdAAuIB0wDQYJKoZIhvcNAQELBQADggIB
# AAfmiFEN4sbgmD+BcQM9naOhIW+z66bM9TG+zwXiqf76V20ZMLPCxWbJat/15/B4
# vceoniXj+bzta1RXCCtRgkQS+7lTjMz0YBKKdsxAQEGb3FwX/1z5Xhc1mCRWS3Tv
# QhDIr79/xn/yN31aPxzymXlKkVIArzgPF/UveYFl2am1a+THzvbKegBvSzBEJCI8
# z+0DpZaPWSm8tv0E4XCfMkon/VWvL/625Y4zu2JfmttXQOnxzplmkIz/amJ/3cVK
# C5Em4jnsGUpxY517IW3DnKOiPPp/fZZqkHimbdLhnPkd/DjYlPTGpQqWhqS9nhqu
# BEKDuLWAmyI4ILUl5WTs9/S/fmNZJQ96LjlXdqJxqgaKD4kWumGnEcua2A5HmoDF
# 0M2n0O99g/DhO3EJ3110mCIIYdqwUB5vvfHhAN/nMQekkzr3ZUd46PioSKv33nJ+
# YWtvd6mBy6cJrDm77MbL2IK0cs0d9LiFAR6A+xuJKlQ5slvayA1VmXqHczsI5pgt
# 6o3gMy4SKfXAL1QnIffIrE7aKLixqduWsqdCosnPGUFN4Ib5KpqjEWYw07t0Mkvf
# Y3v1mYovG8chr1m1rtxEPJdQcdeh0sVV42neV8HR3jDA/czmTfsNv11P6Z0eGTgv
# vM9YBS7vDaBQNdrvCScc1bN+NR4Iuto229Nfj950iEkSoYICzjCCAjcCAQEwgfih
# gdCkgc0wgcoxCzAJBgNVBAYTAlVTMQswCQYDVQQIEwJXQTEQMA4GA1UEBxMHUmVk
# bW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMS0wKwYDVQQLEyRN
# aWNyb3NvZnQgSXJlbGFuZCBPcGVyYXRpb25zIExpbWl0ZWQxJjAkBgNVBAsTHVRo
# YWxlcyBUU1MgRVNOOjhENDEtNEJGNy1CM0I3MSUwIwYDVQQDExxNaWNyb3NvZnQg
# VGltZS1TdGFtcCBzZXJ2aWNloiMKAQEwBwYFKw4DAhoDFQC//EreiaQMh6prbQbz
# f59LukktoaCBgzCBgKR+MHwxCzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5n
# dG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9y
# YXRpb24xJjAkBgNVBAMTHU1pY3Jvc29mdCBUaW1lLVN0YW1wIFBDQSAyMDEwMA0G
# CSqGSIb3DQEBBQUAAgUA4Q79TjAiGA8yMDE5MDgyNzA4NTIzMFoYDzIwMTkwODI4
# MDg1MjMwWjB3MD0GCisGAQQBhFkKBAExLzAtMAoCBQDhDv1OAgEAMAoCAQACAhvu
# AgH/MAcCAQACAhF/MAoCBQDhEE7OAgEAMDYGCisGAQQBhFkKBAIxKDAmMAwGCisG
# AQQBhFkKAwKgCjAIAgEAAgMHoSChCjAIAgEAAgMBhqAwDQYJKoZIhvcNAQEFBQAD
# gYEAoGa7jwIZeYfyKfp8C+tor8cduARzz63SFNy83IVv/Rv5H/93dJkMBJV8T1IR
# MxRhP31RgverndrDhuHVPnUONFd/sDcPJK4GAQURHzdivj63h4rP149GuGCm9S88
# yV3cp3Ydfn7h5mud3/R2dmZSQD/6MX5Y75qvjSXAa7AHXXcxggMNMIIDCQIBATCB
# kzB8MQswCQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMH
# UmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMSYwJAYDVQQD
# Ex1NaWNyb3NvZnQgVGltZS1TdGFtcCBQQ0EgMjAxMAITMwAAANmqlgpRy5tL5gAA
# AAAA2TANBglghkgBZQMEAgEFAKCCAUowGgYJKoZIhvcNAQkDMQ0GCyqGSIb3DQEJ
# EAEEMC8GCSqGSIb3DQEJBDEiBCAij2y+upF3R8PDfOU/1JegLPer979HZiuV9Ob6
# n5nWZzCB+gYLKoZIhvcNAQkQAi8xgeowgecwgeQwgb0EINIsifIfKK2PQTe/ypSm
# yxPoEvAiCgjnk0WIaC0O2pNxMIGYMIGApH4wfDELMAkGA1UEBhMCVVMxEzARBgNV
# BAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jv
# c29mdCBDb3Jwb3JhdGlvbjEmMCQGA1UEAxMdTWljcm9zb2Z0IFRpbWUtU3RhbXAg
# UENBIDIwMTACEzMAAADZqpYKUcubS+YAAAAAANkwIgQgmAYBoqCCaOkCIZLJ+IIY
# YsJwJZ9QFK83Vem1P4B/P/wwDQYJKoZIhvcNAQELBQAEggEAJNGfRa6Y4Ty12KGJ
# 7jth2tlz94ejQD+IFhKnj3Im9Ptagr03KpPn5no3Sm3YMtOBMuneHmkPzLI8m4yp
# wFYqznwwm1554xO9+Fjq3PL1gQsPuLZsrBY7ne+cXBfXz74+QxXJ9ZLoV+Dv10vq
# oyFyOqCGJTMg4nQ6zc5EFlqYlES6HJ54/UEOn2Gi6SDLYeMcvirHRsqYXJ2f0hRW
# wmfdlkVev5tftC5qPFCQ1NWoRCQnItaqOC4RFqnzhXat4OpQqD+ZBBbTPyhWMBVL
# NXDQ32h5y/zbT08qUJtABAt1frHTB7ECrNwkgsYi0riXlckfcsFKh8rsJCi1H7RL
# 2DCMXg==
# SIG # End signature block
