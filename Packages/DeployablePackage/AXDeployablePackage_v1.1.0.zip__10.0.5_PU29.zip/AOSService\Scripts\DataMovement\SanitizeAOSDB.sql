--Tidy up the batch server config from the previous environment
DELETE FROM SYSSERVERCONFIG

--Tidy up server sessions from the previous environment.
DELETE FROM SYSSERVERSESSIONS

--Tidy up printers from the previous environment
DELETE FROM SYSCORPNETPRINTERS

--Tidy up client sessions from the previous environment.
DELETE FROM SYSCLIENTSESSIONS

--Tidy up batch sessions from the previous environment.
DELETE FROM BATCHSERVERCONFIG

--Tidy up batch server to batch group relation table
DELETE FROM BATCHSERVERGROUP

--Set any waiting, executing, ready or canceling batches to withhold
UPDATE BatchJob
SET STATUS = 0
WHERE STATUS  IN (1,2,5,7)
GO

IF '$(EnvSku)' = 'prod'
BEGIN
  -- Batchjob History Cleanup from source environment
  BEGIN TRAN
  DELETE BATCHJOBHISTORY WHERE CREATEDDATETIME < GETDATE()
  COMMIT TRAN
  BEGIN TRAN
  DELETE BATCHHISTORY WHERE NOT EXISTS (SELECT RECID FROM BATCHJOBHISTORY JOB  WHERE JOB.RECID = BATCHJOBHISTORYID)
  COMMIT TRAN
  BEGIN TRAN
  DELETE BATCHCONSTRAINTSHISTORY WHERE NOT EXISTS (SELECT RECID FROM BATCHHISTORY WHERE BATCHHISTORY.RECID = BATCHCONSTRAINTSHISTORY.BATCHID)
  COMMIT TRAN 
  
  --Update SYSCONFIGURATION table 
  UPDATE SYSGLOBALCONFIGURATION SET [VALUE] = 1 WHERE NAME IN ( 'DATAAREAIDLITERAL', 'PARTITIONLITERAL ')
  --Tidy up printers from the previous environment
  UPDATE SYSGLOBALCONFIGURATION SET VALUE = 'SQLAZURE' WHERE NAME = 'BACKENDDB'

  --Tidy up printers from the previous environment
  UPDATE SYSGLOBALCONFIGURATION SET VALUE = 1 WHERE NAME = 'TEMPTABLEINAXDB' 
END

IF '$(EnvSku)' = 'sandbox'
BEGIN
  --disable all users except Admin, Microsoft account and Dynamics-alias users (they should go and re-enable as they see fit),
  DECLARE @sqlDisableUserCmd nvarchar(256) = 'UPDATE UserInfo
    SET ENABLE = 0
    WHERE ID <> ''Admin'' AND NETWORKALIAS not like ''%dynamics.com%'''

  IF EXISTS(SELECT 1 FROM INFORMATION_SCHEMA.COLUMNS 
    WHERE TABLE_NAME = 'UserInfo' 
    AND COLUMN_NAME = 'IsMicrosoftAccount')
  BEGIN
    SET @sqlDisableUserCmd = @sqlDisableUserCmd + ' AND IsMicrosoftAccount <> 1'
  END

  exec sp_executesql @sqlDisableUserCmd

  --Remove the SMTP server configuration to prevent sandbox from sending mails
  UPDATE SysEmailParameters
  SET SMTPRELAYSERVERNAME = '', MAILERNONINTERACTIVE = 'SMTP'

  DELETE FROM SysEMailSMTPPassword

  --Blank out all email addresses - in the case someone adds back SMTP config this will prevent accidentally sending mails
  UPDATE LogisticsElectronicAddress
  SET LOCATOR = '' 
  WHERE Locator LIKE '%@%'
  
  --Remove all print management settings - there is email addresses stored in a container field here - again we want to prevent accidentally sending a vendor/customer a PO/SO email.
  DELETE FROM PrintMgmtSettings 

  DELETE FROM PrintMgmtDocInstance 
END

--Remove all attachment references as storage account is not copied. Approved by Tariq Bell.
UPDATE t1
SET t1.storageproviderid = 0
     , t1.accessinformation = ''
     , t1.modifiedby = 'NonProdRestore'
     , t1.modifieddatetime = getdate()
FROM docuvalue t1 
WHERE t1.storageproviderid = 1

-- RETAILTRANSACTIONSERVICEPROFILE
DECLARE @MIGRATIONVALUE NVARCHAR(50)
SET @MIGRATIONVALUE = N'https://MIGRATION_VALUE'

IF EXISTS(SELECT 1 FROM INFORMATION_SCHEMA.COLUMNS 
  WHERE TABLE_NAME = 'RETAILTRANSACTIONSERVICEPROFILE' 
  AND COLUMN_NAME = 'AzureResource')
BEGIN
  EXECUTE ('UPDATE dbo.[RETAILTRANSACTIONSERVICEPROFILE] SET ServiceHostUrl = ''' + @MIGRATIONVALUE + ''' , AzureResource = ''' + @MIGRATIONVALUE + ''' ')
END
ELSE
BEGIN
  EXECUTE ('UPDATE dbo.[RETAILTRANSACTIONSERVICEPROFILE] SET ServiceHostUrl = ''' + @MIGRATIONVALUE + '''  ')
END

-- RETAILCHANNELPROFILEPROPERTY
UPDATE 
  dbo.[RETAILCHANNELPROFILEPROPERTY]
SET 
  [VALUE] = N'https://MIGRATION_VALUE'
WHERE
  [VALUE] LIKE '%dynamics.com'


UPDATE 
  dbo.[RETAILCHANNELPROFILEPROPERTY]
SET 
  [VALUE] = N'https://MIGRATION_VALUE/Commerce'
WHERE
  [VALUE] LIKE '%dynamics.com/Commerce'


UPDATE 
  dbo.[RETAILCHANNELPROFILEPROPERTY]
SET 
  [VALUE] = N'https://MIGRATION_VALUE/MediaServer'
WHERE
  [VALUE] LIKE '%dynamics.com/MediaServer'


-- RETAILCONNDATABASEPROFILE (all rows)
UPDATE
  dbo.[RETAILCONNDATABASEPROFILE]
SET
  [CONNECTIONSTRING] = NULL

    -- RETAILIDENTITYPROVIDER 
UPDATE
    dbo.[RETAILIDENTITYPROVIDER]
SET
    [ISSUER] = N'https://sts.windows-ppe.net/MIGRATION_VALUE_' + SUBSTRING(CONVERT(nvarchar(50), NEWID()), 1, 8) + '/'
WHERE
    [NAME] = N'Azure AD'

UPDATE
    dbo.[RETAILIDENTITYPROVIDER]
SET
    [ISSUER] = N'https://MIGRATION_VALUE_' + SUBSTRING(CONVERT(nvarchar(50), NEWID()), 1, 8) + '/auth'
WHERE
    [NAME] = N'Commerce Identity Provider'

UPDATE 
  dbo.[RETAILHARDWAREPROFILE]
SET
  [SECUREMERCHANTPROPERTIES] = NULL
