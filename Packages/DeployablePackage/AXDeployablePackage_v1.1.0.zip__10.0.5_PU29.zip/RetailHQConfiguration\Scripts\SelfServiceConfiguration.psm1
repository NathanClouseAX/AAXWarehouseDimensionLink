<#
SAMPLE CODE NOTICE

THIS SAMPLE CODE IS MADE AVAILABLE AS IS.  MICROSOFT MAKES NO WARRANTIES, WHETHER EXPRESS OR IMPLIED, 
OF FITNESS FOR A PARTICULAR PURPOSE, OF ACCURACY OR COMPLETENESS OF RESPONSES, OF RESULTS, OR CONDITIONS OF MERCHANTABILITY.  
THE ENTIRE RISK OF THE USE OR THE RESULTS FROM THE USE OF THIS SAMPLE CODE REMAINS WITH THE USER.  
NO TECHNICAL SUPPORT IS PROVIDED.  YOU MAY NOT DISTRIBUTE THIS CODE UNLESS YOU HAVE A LICENSE AGREEMENT WITH MICROSOFT THAT ALLOWS YOU TO DO SO.
#>

$ErrorActionPreference = "Stop"

$scriptDir = Split-Path -Path $MyInvocation.MyCommand.Path -Parent
. $ScriptDir\Common-Configuration.ps1
. $ScriptDir\Common-Web.ps1

function Write-Log(
    $objectToLog = $(Throw 'objectToLog is required!'),
    [string]$logFile)
{
    try
    {
        $date = (Get-Date -DisplayHint Time)
        $objectToLogString = $objectToLog |  Out-String -Width 4096
        $message = "{0}: {1}" -f $date, $objectToLogString

        # Write to log file and to console.
        if($logFile)
        {
            $message | Out-File -FilePath $logFile -Append -Force
        }

        Write-Host $message
    }
    catch
    {
        # swallow any log exceptions
    }
}

function Get-SelfServiceRegistryPath
{
    return 'HKLM:\SOFTWARE\Microsoft\Dynamics\{0}\RetailSelfService' -f (Get-ProductVersionMajorMinor)
}

function Get-SelfServicePkgLocationRegKeyName
{
    return 'SelfServicePackagesLocation'
}

function Get-SelfServiceScriptsLocationRegKeyName
{
    return 'SelfServiceScriptsLocation'
}

function Get-SelfServiceAOSWebsiteRegKeyName
{
    return 'AOSWebsiteName'
}

function Get-AOSWebsiteName
{
    $aosWebsiteName = 'AOSService'
    $aosWebsiteNameObjectFromRegistry = Get-ItemProperty -Path (Get-SelfServiceRegistryPath) -Name 'AOSWebsiteName' -ErrorAction SilentlyContinue
    
    if ($aosWebsiteNameObjectFromRegistry.AOSWebsiteName)
    {
        $aosWebsiteName = $aosWebsiteNameObjectFromRegistry.AOSWebsiteName
    }

    return $aosWebsiteName
}

function Get-WebsitePhysicalPath(
    [string]$webSiteName = $(Throw 'webSiteName is required!')
)
{
    $IISWebSiteObject = Get-WebSiteSafe -Name $webSiteName

    if(!$IISWebSiteObject)
    {
        Throw ("Unable to find a website: '{0}'. Verify that the website exists." -f $webSiteName)
    }
    
    return $IISWebSiteObject.physicalPath
}

function Get-AOSWebConfigFilePath(
    [string]$AOSWebsitePhysicalPath = $(Throw 'AOSWebsitePhysicalPath is required!')
)
{
    $webConfigFilePath =  Join-Path -Path $AOSWebsitePhysicalPath -ChildPath 'web.config'

    if(-not(Test-Path -Path $webConfigFilePath))
    {
        Throw ("Unable to locate Web.config for website: '{0}'. Verify that the website exists." -f $AOSWebsiteName)
    }

    return $webConfigFilePath
}

function Get-AXDeploymentUtilityFilesPath(
    [string]$AOSWebsitePhysicalPath = $(Throw 'AOSWebsitePhysicalPath is required!'),
    [string]$UtilityFileName = $(Throw 'UtilityFileName is required!')
)
{
    # We DO NOT want to edit the file under AOS WebRoot, which may result in the crashing of AOS WebSite, and as a result, it may break the servicing process
    # We can use the same utility under PackagesLocalDirectory\bin, where all the dependencies exist as well.
    $webConfigFilePath =  Join-Path -Path $AOSWebsitePhysicalPath -ChildPath 'web.config'
    if(-not(Test-Path -Path $webConfigFilePath))
    {
        throw "Unable to locate AOS web.config at $webConfigFilePath "
    }
    
    $aosWebConfigContent = Get-AOSWebConfigContent -pathToAosWebConfig $webConfigFilePath

    $binDirectory = $aosWebConfigContent.SelectSingleNode("/configuration/appSettings/add[@key='Common.BinDir']").value;

    $UtilityFilePath =  Join-Path -Path $binDirectory -ChildPath (Join-Path -Path 'bin' -ChildPath $UtilityFileName)
    if(-not(Test-Path -Path $UtilityFilePath))
    {
        throw "Unable to locate $UtilityFilePath"
    }

    return $UtilityFilePath
}

function Update-AXDeploymentUtilityConfigFile(
    [string]$AOSWebConfigFilePath = $(Throw 'AOSWebConfigFilePath is required!'),
    [string]$AXDeploymentUtilityConfigFilePath = $(Throw 'AXDeploymentUtilityConfigFilePath is required!'),
    [string]$logFile = $(Throw 'logFile is required!')
)
{
    # Load AOS web.config and AX Deployment Utility config files
    $aosWebConfigContent = [xml](Get-Content -Path $AOSWebConfigFilePath)
    $AXDeploymentUtilityConfigDoc = [xml](Get-Content -Path $AXDeploymentUtilityConfigFilePath)

    # Get Azure storage connection string from aos web.config file.
    $AzureStorageConnectionStringKey = 'AzureStorage.StorageConnectionString'
    $AzureStorageConnectionStringValue = $aosWebConfigContent.SelectSingleNode("/configuration/appSettings/add[@key='{0}']" -f $AzureStorageConnectionStringKey).Value

    # Find the Azure storage connection string in post deployment utility config file.
    $AzureStorageConnectionStringKeyElement = $AXDeploymentUtilityConfigDoc.SelectSingleNode("/configuration/appSettings/add[@key='{0}']" -f $AzureStorageConnectionStringKey)
    Write-Log -objectToLog ('Azure storage connection string in xml config: {0}' -f ($AzureStorageConnectionStringKeyElement | Out-String)) -logFile $logFile

    # Only add a new element if one doesn't already exist.
    if(!$AzureStorageConnectionStringKeyElement)
    {
        Write-Log -objectToLog 'Adding connection string to xml config.' -logFile $logFile

        $AzureStorageConnectionStringKeyElement = $AXDeploymentUtilityConfigDoc.CreateElement('add')
        $AzureStorageConnectionStringKeyElement.SetAttribute('key', $AzureStorageConnectionStringKey)

        $AzureStorageConnectionStringKeyElement.SetAttribute('value', $AzureStorageConnectionStringValue )

        # To prevent leakage of the output stream to the consuming function, we are suppressing output.
        $AXDeploymentUtilityConfigDoc.configuration.appSettings.AppendChild($AzureStorageConnectionStringKeyElement) | Out-Null
    }
    else
    {
        Write-Log -objectToLog 'Modifying connection string in xml config.' -logFile $logFile
        $AzureStorageConnectionStringKeyElement.Value = $AzureStorageConnectionStringValue
    }

    $AXDeploymentUtilityConfigDoc.Save($AXDeploymentUtilityConfigFilePath)
}

function Get-AOSWebConfigContent(
    [string]$pathToAosWebConfig = $(Throw 'pathToAosWebConfig is required!')
)
{
    try
    {
        # The AosDatabasePass is potentially encrypted and needs to be decrypted for use.
        # Step 1: Create a copy of web.config
        $aosWebsiteRootFolder = Split-Path -Path $pathToAosWebConfig -Parent
        $duplicateWebConfigFilePath = [System.IO.Path]::GetTempFileName()
        Copy-Item -Path $pathToAosWebConfig -Destination $duplicateWebConfigFilePath -Force

        # Step 2: Decrypt web.config
        $configEncryptorExeName = 'Microsoft.Dynamics.AX.Framework.ConfigEncryptor.exe'
        $pathToConfigEncryptor = [System.IO.Path]::Combine($aosWebsiteRootFolder, 'bin', $configEncryptorExeName)

        try
        {
            # Step 3: Decrypt the copied web.config
            # To prevent leakage of the output stream to the consuming function, we are suppressing output.
            & $pathToConfigEncryptor -decrypt $duplicateWebConfigFilePath | Out-Null
        }
        catch
        {
            # Only reason for entering this block is cause the web config is already decrypted.
            Write-Log -objectToLog 'Copied web config file is not encrypted.'
        }

        # Step 4: Get the contents of the web.config
        $aosWebConfigContent = [xml](Get-Content -Path $duplicateWebConfigFilePath)
    }
    finally
    {
        # Remove the decrypted copy of the web.config
        Remove-Item -Path $duplicateWebConfigFilePath -Force -ErrorAction SilentlyContinue
    }

    return $aosWebConfigContent
}

function Get-RetailUsageDetails()
{
    Write-Log -objectToLog 'Get-RetailUsageDetails - Getting connection string to database'
    $dbDetails = Get-RequisiteParametersFromAosWebConfig

    $inputFile = Join-Path $PSScriptRoot 'GetRetailChannelDetails.sql'

    $retailInfo = Invoke-SqlCmd -ConnectionTimeout 60 -QueryTimeout 300 -ServerInstance $dbDetails.AosDatabaseServer -Database $dbDetails.AosDatabaseName `
        -Username $dbDetails.AosDatabaseUser -Password $dbDetails.AosDatabasePass -InputFile $inputFile

    # environment uses retail if any of the below signals are true
    [bool]$usesRetail = $retailInfo['HAS CHANNEL DATA IN CHANNELDB'] -or $retailInfo['HAS ANY CHANNEL DATA IN AOS'] `
        -or $retailInfo['HAS TRANSACTION DATA IN AOS'] -or $retailInfo['HAS TRANSACTION DATA IN CHANNEL DB'] `
        -or $retailInfo['HAS CHANNEL DB EXTENSIONS']

    $retailInfo | Add-Member -Type NoteProperty -Name UsesRetail -Value $usesRetail

    Write-Log -objectToLog $retailInfo

    return $retailInfo
}

function Get-RequisiteParametersFromAosWebConfig(
    [string]$AOSWebConfigFilePath
)
{
    if ([string]::IsNullOrWhitespace($AOSWebConfigFilePath))
    {
        Write-Log -objectToLog 'Get-RequisiteParametersFromAosWebConfig - AOS Web Config not provided. I will try to resolve AOSService web.config path based on IIS details.'

        # default to AOS service
        $webSitePhysicalPath = Get-WebSitePhysicalPath -webSiteName "AOSService"

        if (-not $webSitePhysicalPath)
        {
            throw "Could not resolve AOSService web.config path. Please provide the AOS web.config as a parameter."
        }

        $AOSWebConfigFilePath = Join-Path $webSitePhysicalPath 'web.config'
    }

    # Read the web config, sample xml element: <add key="Aos.MetadataDirectory" value="F:\AosService\PackagesLocalDirectory" />
    $aosWebConfigContent = Get-AOSWebConfigContent -pathToAosWebConfig $AOSWebConfigFilePath

    $result = @{
        'BinDirectory'      = $aosWebConfigContent.SelectSingleNode("/configuration/appSettings/add[@key='Common.BinDir']").value;
        'MetadataDirectory' = $aosWebConfigContent.SelectSingleNode("/configuration/appSettings/add[@key='Common.BinDir']").value;
        'AosDatabaseServer' = $aosWebConfigContent.SelectSingleNode("/configuration/appSettings/add[@key='DataAccess.DbServer']").value;
        'AosDatabaseName'   = $aosWebConfigContent.SelectSingleNode("/configuration/appSettings/add[@key='DataAccess.Database']").value;
        'AosDatabaseUser'   = $aosWebConfigContent.SelectSingleNode("/configuration/appSettings/add[@key='DataAccess.SqlUser']").value;
        'AosDatabasePass'   = $aosWebConfigContent.SelectSingleNode("/configuration/appSettings/add[@key='DataAccess.SqlPwd']").value;
    }

    return $result
}

function Call-AXDeploymentSetupUtility(
    $parametersFromAosWebConfig = $(Throw 'parametersFromAosWebConfig is required!'),
    $methodInputXmlFilePath = $(Throw 'methodInputXmlFilePath is required!'),
    $AXDeploymentSetupUtilityFilePath = $(Throw 'AXDeploymentSetupUtilityFilePath is required!'),
    $className = 'RetailSelfServicePackageManager',
    $methodName = 'ProcessExternalRequests',
    $logFile = $(Throw 'logFile is required!')
)
{
    $metadataDirectory = $parametersFromAosWebConfig["MetadataDirectory"];

    if(-not (Test-Path -Path $MetadataDirectory))
    {
        $metadataDirectory = $parametersFromAosWebConfig["BinDirectory"]
    }

    # Generate array of parameters to pass to Deployment Setup Utility without password based parameters
    $axDeploymentCallArguments = @(
        '--isemulated',      'false',
        '--bindir',          $parametersFromAosWebConfig['BinDirectory'],
        '--metadatadir',     $metadataDirectory,
        '--sqlserver',       $parametersFromAosWebConfig['AosDatabaseServer'],
        '--sqldatabase',     $parametersFromAosWebConfig['AosDatabaseName'],
        '--sqluser',         $parametersFromAosWebConfig['AosDatabaseUser'],
        '--setupmode',       'RunStaticXppMethod',
        '--classname',       $className,
        '--methodname',      $methodName,
        '--methodinputfile', $methodInputXmlFilePath
    )
    
    Write-Log -objectToLog ('Calling {0}' -f $AXDeploymentSetupUtilityFilePath) -logFile $logFile
    Write-Log -objectToLog ('Passing parameters {0}' -f ($axDeploymentCallArguments -join ' ')) -logFile $logFile

    # Add password based parameters
    $axDeploymentCallArguments += ('--sqlpwd', $parametersFromAosWebConfig['AosDatabasePass'])
    
    $Global:LASTEXITCODE = 0
    $commandOutput = & $AXDeploymentSetupUtilityFilePath $axDeploymentCallArguments 2>&1 | Out-String

    $exitCode = $Global:LASTEXITCODE
    Write-Log -objectToLog ("Program Output: {0}" -f $commandOutput) -logFile $logFile

    if ($exitCode -ne 0)
    {
        throw 'Exception occured during execution of call to DeploymentSetupUtility. Please see the log for further details.'
    }
}

Export-ModuleMember -Function Write-Log
Export-ModuleMember -Function Get-SelfServiceRegistryPath
Export-ModuleMember -Function Get-SelfServicePkgLocationRegKeyName

Export-ModuleMember -Function Get-SelfServiceScriptsLocationRegKeyName
Export-ModuleMember -Function Get-SelfServiceAOSWebsiteRegKeyName
Export-ModuleMember -Function Get-WebsitePhysicalPath

Export-ModuleMember -Function Get-AOSWebsiteName
Export-ModuleMember -Function Get-AOSWebConfigFilePath
Export-ModuleMember -Function Get-AXDeploymentUtilityFilesPath

Export-ModuleMember -Function Read-RegistryValue
Export-ModuleMember -Function Update-AXDeploymentUtilityConfigFile
Export-ModuleMember -Function Get-RequisiteParametersFromAosWebConfig
Export-ModuleMember -Function Call-AXDeploymentSetupUtility

Export-ModuleMember -Function Get-RetailUsageDetails
# SIG # Begin signature block
# MIIjoAYJKoZIhvcNAQcCoIIjkTCCI40CAQExDzANBglghkgBZQMEAgEFADB5Bgor
# BgEEAYI3AgEEoGswaTA0BgorBgEEAYI3AgEeMCYCAwEAAAQQH8w7YFlLCE63JNLG
# KX7zUQIBAAIBAAIBAAIBAAIBADAxMA0GCWCGSAFlAwQCAQUABCDgx3mIyR3fKgWy
# omrjnqw9pV/Hsu9TFDgs4dv8ZBnmuKCCDYEwggX/MIID56ADAgECAhMzAAABUZ6N
# j0Bxow5BAAAAAAFRMA0GCSqGSIb3DQEBCwUAMH4xCzAJBgNVBAYTAlVTMRMwEQYD
# VQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNy
# b3NvZnQgQ29ycG9yYXRpb24xKDAmBgNVBAMTH01pY3Jvc29mdCBDb2RlIFNpZ25p
# bmcgUENBIDIwMTEwHhcNMTkwNTAyMjEzNzQ2WhcNMjAwNTAyMjEzNzQ2WjB0MQsw
# CQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9u
# ZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMR4wHAYDVQQDExVNaWNy
# b3NvZnQgQ29ycG9yYXRpb24wggEiMA0GCSqGSIb3DQEBAQUAA4IBDwAwggEKAoIB
# AQCVWsaGaUcdNB7xVcNmdfZiVBhYFGcn8KMqxgNIvOZWNH9JYQLuhHhmJ5RWISy1
# oey3zTuxqLbkHAdmbeU8NFMo49Pv71MgIS9IG/EtqwOH7upan+lIq6NOcw5fO6Os
# +12R0Q28MzGn+3y7F2mKDnopVu0sEufy453gxz16M8bAw4+QXuv7+fR9WzRJ2CpU
# 62wQKYiFQMfew6Vh5fuPoXloN3k6+Qlz7zgcT4YRmxzx7jMVpP/uvK6sZcBxQ3Wg
# B/WkyXHgxaY19IAzLq2QiPiX2YryiR5EsYBq35BP7U15DlZtpSs2wIYTkkDBxhPJ
# IDJgowZu5GyhHdqrst3OjkSRAgMBAAGjggF+MIIBejAfBgNVHSUEGDAWBgorBgEE
# AYI3TAgBBggrBgEFBQcDAzAdBgNVHQ4EFgQUV4Iarkq57esagu6FUBb270Zijc8w
# UAYDVR0RBEkwR6RFMEMxKTAnBgNVBAsTIE1pY3Jvc29mdCBPcGVyYXRpb25zIFB1
# ZXJ0byBSaWNvMRYwFAYDVQQFEw0yMzAwMTIrNDU0MTM1MB8GA1UdIwQYMBaAFEhu
# ZOVQBdOCqhc3NyK1bajKdQKVMFQGA1UdHwRNMEswSaBHoEWGQ2h0dHA6Ly93d3cu
# bWljcm9zb2Z0LmNvbS9wa2lvcHMvY3JsL01pY0NvZFNpZ1BDQTIwMTFfMjAxMS0w
# Ny0wOC5jcmwwYQYIKwYBBQUHAQEEVTBTMFEGCCsGAQUFBzAChkVodHRwOi8vd3d3
# Lm1pY3Jvc29mdC5jb20vcGtpb3BzL2NlcnRzL01pY0NvZFNpZ1BDQTIwMTFfMjAx
# MS0wNy0wOC5jcnQwDAYDVR0TAQH/BAIwADANBgkqhkiG9w0BAQsFAAOCAgEAWg+A
# rS4Anq7KrogslIQnoMHSXUPr/RqOIhJX+32ObuY3MFvdlRElbSsSJxrRy/OCCZdS
# se+f2AqQ+F/2aYwBDmUQbeMB8n0pYLZnOPifqe78RBH2fVZsvXxyfizbHubWWoUf
# NW/FJlZlLXwJmF3BoL8E2p09K3hagwz/otcKtQ1+Q4+DaOYXWleqJrJUsnHs9UiL
# crVF0leL/Q1V5bshob2OTlZq0qzSdrMDLWdhyrUOxnZ+ojZ7UdTY4VnCuogbZ9Zs
# 9syJbg7ZUS9SVgYkowRsWv5jV4lbqTD+tG4FzhOwcRQwdb6A8zp2Nnd+s7VdCuYF
# sGgI41ucD8oxVfcAMjF9YX5N2s4mltkqnUe3/htVrnxKKDAwSYliaux2L7gKw+bD
# 1kEZ/5ozLRnJ3jjDkomTrPctokY/KaZ1qub0NUnmOKH+3xUK/plWJK8BOQYuU7gK
# YH7Yy9WSKNlP7pKj6i417+3Na/frInjnBkKRCJ/eYTvBH+s5guezpfQWtU4bNo/j
# 8Qw2vpTQ9w7flhH78Rmwd319+YTmhv7TcxDbWlyteaj4RK2wk3pY1oSz2JPE5PNu
# Nmd9Gmf6oePZgy7Ii9JLLq8SnULV7b+IP0UXRY9q+GdRjM2AEX6msZvvPCIoG0aY
# HQu9wZsKEK2jqvWi8/xdeeeSI9FN6K1w4oVQM4Mwggd6MIIFYqADAgECAgphDpDS
# AAAAAAADMA0GCSqGSIb3DQEBCwUAMIGIMQswCQYDVQQGEwJVUzETMBEGA1UECBMK
# V2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0
# IENvcnBvcmF0aW9uMTIwMAYDVQQDEylNaWNyb3NvZnQgUm9vdCBDZXJ0aWZpY2F0
# ZSBBdXRob3JpdHkgMjAxMTAeFw0xMTA3MDgyMDU5MDlaFw0yNjA3MDgyMTA5MDla
# MH4xCzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdS
# ZWRtb25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xKDAmBgNVBAMT
# H01pY3Jvc29mdCBDb2RlIFNpZ25pbmcgUENBIDIwMTEwggIiMA0GCSqGSIb3DQEB
# AQUAA4ICDwAwggIKAoICAQCr8PpyEBwurdhuqoIQTTS68rZYIZ9CGypr6VpQqrgG
# OBoESbp/wwwe3TdrxhLYC/A4wpkGsMg51QEUMULTiQ15ZId+lGAkbK+eSZzpaF7S
# 35tTsgosw6/ZqSuuegmv15ZZymAaBelmdugyUiYSL+erCFDPs0S3XdjELgN1q2jz
# y23zOlyhFvRGuuA4ZKxuZDV4pqBjDy3TQJP4494HDdVceaVJKecNvqATd76UPe/7
# 4ytaEB9NViiienLgEjq3SV7Y7e1DkYPZe7J7hhvZPrGMXeiJT4Qa8qEvWeSQOy2u
# M1jFtz7+MtOzAz2xsq+SOH7SnYAs9U5WkSE1JcM5bmR/U7qcD60ZI4TL9LoDho33
# X/DQUr+MlIe8wCF0JV8YKLbMJyg4JZg5SjbPfLGSrhwjp6lm7GEfauEoSZ1fiOIl
# XdMhSz5SxLVXPyQD8NF6Wy/VI+NwXQ9RRnez+ADhvKwCgl/bwBWzvRvUVUvnOaEP
# 6SNJvBi4RHxF5MHDcnrgcuck379GmcXvwhxX24ON7E1JMKerjt/sW5+v/N2wZuLB
# l4F77dbtS+dJKacTKKanfWeA5opieF+yL4TXV5xcv3coKPHtbcMojyyPQDdPweGF
# RInECUzF1KVDL3SV9274eCBYLBNdYJWaPk8zhNqwiBfenk70lrC8RqBsmNLg1oiM
# CwIDAQABo4IB7TCCAekwEAYJKwYBBAGCNxUBBAMCAQAwHQYDVR0OBBYEFEhuZOVQ
# BdOCqhc3NyK1bajKdQKVMBkGCSsGAQQBgjcUAgQMHgoAUwB1AGIAQwBBMAsGA1Ud
# DwQEAwIBhjAPBgNVHRMBAf8EBTADAQH/MB8GA1UdIwQYMBaAFHItOgIxkEO5FAVO
# 4eqnxzHRI4k0MFoGA1UdHwRTMFEwT6BNoEuGSWh0dHA6Ly9jcmwubWljcm9zb2Z0
# LmNvbS9wa2kvY3JsL3Byb2R1Y3RzL01pY1Jvb0NlckF1dDIwMTFfMjAxMV8wM18y
# Mi5jcmwwXgYIKwYBBQUHAQEEUjBQME4GCCsGAQUFBzAChkJodHRwOi8vd3d3Lm1p
# Y3Jvc29mdC5jb20vcGtpL2NlcnRzL01pY1Jvb0NlckF1dDIwMTFfMjAxMV8wM18y
# Mi5jcnQwgZ8GA1UdIASBlzCBlDCBkQYJKwYBBAGCNy4DMIGDMD8GCCsGAQUFBwIB
# FjNodHRwOi8vd3d3Lm1pY3Jvc29mdC5jb20vcGtpb3BzL2RvY3MvcHJpbWFyeWNw
# cy5odG0wQAYIKwYBBQUHAgIwNB4yIB0ATABlAGcAYQBsAF8AcABvAGwAaQBjAHkA
# XwBzAHQAYQB0AGUAbQBlAG4AdAAuIB0wDQYJKoZIhvcNAQELBQADggIBAGfyhqWY
# 4FR5Gi7T2HRnIpsLlhHhY5KZQpZ90nkMkMFlXy4sPvjDctFtg/6+P+gKyju/R6mj
# 82nbY78iNaWXXWWEkH2LRlBV2AySfNIaSxzzPEKLUtCw/WvjPgcuKZvmPRul1LUd
# d5Q54ulkyUQ9eHoj8xN9ppB0g430yyYCRirCihC7pKkFDJvtaPpoLpWgKj8qa1hJ
# Yx8JaW5amJbkg/TAj/NGK978O9C9Ne9uJa7lryft0N3zDq+ZKJeYTQ49C/IIidYf
# wzIY4vDFLc5bnrRJOQrGCsLGra7lstnbFYhRRVg4MnEnGn+x9Cf43iw6IGmYslmJ
# aG5vp7d0w0AFBqYBKig+gj8TTWYLwLNN9eGPfxxvFX1Fp3blQCplo8NdUmKGwx1j
# NpeG39rz+PIWoZon4c2ll9DuXWNB41sHnIc+BncG0QaxdR8UvmFhtfDcxhsEvt9B
# xw4o7t5lL+yX9qFcltgA1qFGvVnzl6UJS0gQmYAf0AApxbGbpT9Fdx41xtKiop96
# eiL6SJUfq/tHI4D1nvi/a7dLl+LrdXga7Oo3mXkYS//WsyNodeav+vyL6wuA6mk7
# r/ww7QRMjt/fdW1jkT3RnVZOT7+AVyKheBEyIXrvQQqxP/uozKRdwaGIm1dxVk5I
# RcBCyZt2WwqASGv9eZ/BvW1taslScxMNelDNMYIVdTCCFXECAQEwgZUwfjELMAkG
# A1UEBhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQx
# HjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEoMCYGA1UEAxMfTWljcm9z
# b2Z0IENvZGUgU2lnbmluZyBQQ0EgMjAxMQITMwAAAVGejY9AcaMOQQAAAAABUTAN
# BglghkgBZQMEAgEFAKCByDAZBgkqhkiG9w0BCQMxDAYKKwYBBAGCNwIBBDAcBgor
# BgEEAYI3AgELMQ4wDAYKKwYBBAGCNwIBFTAvBgkqhkiG9w0BCQQxIgQgE9tUkx0n
# tZbJE7G9mfSN/FqAWuqc5UJxKZLmi8lDgLIwXAYKKwYBBAGCNwIBDDFOMEygLoAs
# AFIAZQB0AGEAaQBsAE0AaQBuAG8AcgBVAHAAZwByAGEAZABlAC4AcABzADGhGoAY
# aHR0cDovL3d3dy5taWNyb3NvZnQuY29tMA0GCSqGSIb3DQEBAQUABIIBAJHOFlhS
# HErGo14eI/rjjQY8I6VxSsR6OmNcBzD2DQNyGce4ZUUo7c8Bm8AgHl6wN4uQLGCN
# RnkXD05WfrLF8hW4zkbjH39HYjXWgwXjHlkjYePszDatitOr5R04ZrvLOiWc+1rU
# lnLM1z1Np88ch1WeKsct8GpEMuaHuvI/wil+oS1ybu4nZR9Vq8dNQ4C+2laZ3Uui
# KRVFQ6sosTCyYsCJYqF7qV2Xv8FhOGjaAN9py1jOMiqSwLN42D/w2bUN2OCbvn+F
# KV0dsU2++8Hb8fjT/ub/XNEJA7EIRu8S25k3YGV3I98ih0aWBcikFhLl5dpoG/io
# zQ4j91Vh8SzAduyhghLlMIIS4QYKKwYBBAGCNwMDATGCEtEwghLNBgkqhkiG9w0B
# BwKgghK+MIISugIBAzEPMA0GCWCGSAFlAwQCAQUAMIIBUQYLKoZIhvcNAQkQAQSg
# ggFABIIBPDCCATgCAQEGCisGAQQBhFkKAwEwMTANBglghkgBZQMEAgEFAAQgIqW2
# nUGj/FlC0ivmzT6TaTLjtUOt3J+T+rSdwRUMnVcCBl1gK6EK/xgTMjAxOTA4Mjcw
# NzIzMzYuMTAzWjAEgAIB9KCB0KSBzTCByjELMAkGA1UEBhMCVVMxCzAJBgNVBAgT
# AldBMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9y
# YXRpb24xLTArBgNVBAsTJE1pY3Jvc29mdCBJcmVsYW5kIE9wZXJhdGlvbnMgTGlt
# aXRlZDEmMCQGA1UECxMdVGhhbGVzIFRTUyBFU046MDg0Mi00QkU2LUMyOUExJTAj
# BgNVBAMTHE1pY3Jvc29mdCBUaW1lLVN0YW1wIHNlcnZpY2Wggg48MIIE8TCCA9mg
# AwIBAgITMwAAANga5Mw/ehH64QAAAAAA2DANBgkqhkiG9w0BAQsFADB8MQswCQYD
# VQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEe
# MBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMSYwJAYDVQQDEx1NaWNyb3Nv
# ZnQgVGltZS1TdGFtcCBQQ0EgMjAxMDAeFw0xODA4MjMyMDI2NTFaFw0xOTExMjMy
# MDI2NTFaMIHKMQswCQYDVQQGEwJVUzELMAkGA1UECBMCV0ExEDAOBgNVBAcTB1Jl
# ZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEtMCsGA1UECxMk
# TWljcm9zb2Z0IElyZWxhbmQgT3BlcmF0aW9ucyBMaW1pdGVkMSYwJAYDVQQLEx1U
# aGFsZXMgVFNTIEVTTjowODQyLTRCRTYtQzI5QTElMCMGA1UEAxMcTWljcm9zb2Z0
# IFRpbWUtU3RhbXAgc2VydmljZTCCASIwDQYJKoZIhvcNAQEBBQADggEPADCCAQoC
# ggEBAJQeMOSHWvWwaLjzMJJNUlItdUPmMVReJICu4pqGgEB5cQWDde10v3sl7BPa
# 8SYt4YQ9J1zmeiuXr57pmiFWP/zzApH7DSX8BcRtuDaAzyDtdntSgYEFiPd9Mls0
# uT0GgAjhDT4LIIuwkRQ3G9cEmRfQqF5evcim2kNmhqAGWT9PdRoUeZM58bphx7nN
# EnksdDK8TQ71GckMkw3kOhHn/MxlfsDYUXQMdd/gL8BZBA9gdA5XV+Y25/EGVLAP
# gYVs67VHx0v5LM1TN7vselOqD7p4tNRKwc15WvhgrOs3zW+YLHpoi7mK5bBxRbHD
# HtOBuoavZ12D9Xj1byK71Swy9UMCAwEAAaOCARswggEXMB0GA1UdDgQWBBSftlZL
# Hu4U1d+KdnqagxrnkONm5DAfBgNVHSMEGDAWgBTVYzpcijGQ80N7fEYbxTNoWoVt
# VTBWBgNVHR8ETzBNMEugSaBHhkVodHRwOi8vY3JsLm1pY3Jvc29mdC5jb20vcGtp
# L2NybC9wcm9kdWN0cy9NaWNUaW1TdGFQQ0FfMjAxMC0wNy0wMS5jcmwwWgYIKwYB
# BQUHAQEETjBMMEoGCCsGAQUFBzAChj5odHRwOi8vd3d3Lm1pY3Jvc29mdC5jb20v
# cGtpL2NlcnRzL01pY1RpbVN0YVBDQV8yMDEwLTA3LTAxLmNydDAMBgNVHRMBAf8E
# AjAAMBMGA1UdJQQMMAoGCCsGAQUFBwMIMA0GCSqGSIb3DQEBCwUAA4IBAQAOUnB2
# 3sg/ILU0t7sBnN7w2jsyd3zgPlIwd/GJGkt45hfP5uBn4j9vwGfpsKDZehLtQpt/
# Rp6i5Sq79NyQOw4Lr5+SjS5bUuk5E5SkK9z1ZMa/RVeP+gkC5dlElNHep5kc6CJh
# nSoLIlKE7IgiYkpvjdiDPi3ST8kDSrkT7PZb8PacoNVX7NOcrxKdE5DnlYp6gmr2
# kFwmN3Wd/se9h3UyXIWEXc7B0I8Wsz8W2xws7oYpUGK9el7Tcr0jYqyiAmHbuwIp
# d3TtM3WGpQ5UznixUltmh8+ckTCKD406FhJGKOFLhP99FrVVwtDavCE0zJBz1T75
# D5bf4jYrxoObSU6xMIIGcTCCBFmgAwIBAgIKYQmBKgAAAAAAAjANBgkqhkiG9w0B
# AQsFADCBiDELMAkGA1UEBhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAOBgNV
# BAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEyMDAG
# A1UEAxMpTWljcm9zb2Z0IFJvb3QgQ2VydGlmaWNhdGUgQXV0aG9yaXR5IDIwMTAw
# HhcNMTAwNzAxMjEzNjU1WhcNMjUwNzAxMjE0NjU1WjB8MQswCQYDVQQGEwJVUzET
# MBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UEChMV
# TWljcm9zb2Z0IENvcnBvcmF0aW9uMSYwJAYDVQQDEx1NaWNyb3NvZnQgVGltZS1T
# dGFtcCBQQ0EgMjAxMDCCASIwDQYJKoZIhvcNAQEBBQADggEPADCCAQoCggEBAKkd
# Dbx3EYo6IOz8E5f1+n9plGt0VBDVpQoAgoX77XxoSyxfxcPlYcJ2tz5mK1vwFVMn
# BDEfQRsalR3OCROOfGEwWbEwRA/xYIiEVEMM1024OAizQt2TrNZzMFcmgqNFDdDq
# 9UeBzb8kYDJYYEbyWEeGMoQedGFnkV+BVLHPk0ySwcSmXdFhE24oxhr5hoC732H8
# RsEnHSRnEnIaIYqvS2SJUGKxXf13Hz3wV3WsvYpCTUBR0Q+cBj5nf/VmwAOWRH7v
# 0Ev9buWayrGo8noqCjHw2k4GkbaICDXoeByw6ZnNPOcvRLqn9NxkvaQBwSAJk3jN
# /LzAyURdXhacAQVPIk0CAwEAAaOCAeYwggHiMBAGCSsGAQQBgjcVAQQDAgEAMB0G
# A1UdDgQWBBTVYzpcijGQ80N7fEYbxTNoWoVtVTAZBgkrBgEEAYI3FAIEDB4KAFMA
# dQBiAEMAQTALBgNVHQ8EBAMCAYYwDwYDVR0TAQH/BAUwAwEB/zAfBgNVHSMEGDAW
# gBTV9lbLj+iiXGJo0T2UkFvXzpoYxDBWBgNVHR8ETzBNMEugSaBHhkVodHRwOi8v
# Y3JsLm1pY3Jvc29mdC5jb20vcGtpL2NybC9wcm9kdWN0cy9NaWNSb29DZXJBdXRf
# MjAxMC0wNi0yMy5jcmwwWgYIKwYBBQUHAQEETjBMMEoGCCsGAQUFBzAChj5odHRw
# Oi8vd3d3Lm1pY3Jvc29mdC5jb20vcGtpL2NlcnRzL01pY1Jvb0NlckF1dF8yMDEw
# LTA2LTIzLmNydDCBoAYDVR0gAQH/BIGVMIGSMIGPBgkrBgEEAYI3LgMwgYEwPQYI
# KwYBBQUHAgEWMWh0dHA6Ly93d3cubWljcm9zb2Z0LmNvbS9QS0kvZG9jcy9DUFMv
# ZGVmYXVsdC5odG0wQAYIKwYBBQUHAgIwNB4yIB0ATABlAGcAYQBsAF8AUABvAGwA
# aQBjAHkAXwBTAHQAYQB0AGUAbQBlAG4AdAAuIB0wDQYJKoZIhvcNAQELBQADggIB
# AAfmiFEN4sbgmD+BcQM9naOhIW+z66bM9TG+zwXiqf76V20ZMLPCxWbJat/15/B4
# vceoniXj+bzta1RXCCtRgkQS+7lTjMz0YBKKdsxAQEGb3FwX/1z5Xhc1mCRWS3Tv
# QhDIr79/xn/yN31aPxzymXlKkVIArzgPF/UveYFl2am1a+THzvbKegBvSzBEJCI8
# z+0DpZaPWSm8tv0E4XCfMkon/VWvL/625Y4zu2JfmttXQOnxzplmkIz/amJ/3cVK
# C5Em4jnsGUpxY517IW3DnKOiPPp/fZZqkHimbdLhnPkd/DjYlPTGpQqWhqS9nhqu
# BEKDuLWAmyI4ILUl5WTs9/S/fmNZJQ96LjlXdqJxqgaKD4kWumGnEcua2A5HmoDF
# 0M2n0O99g/DhO3EJ3110mCIIYdqwUB5vvfHhAN/nMQekkzr3ZUd46PioSKv33nJ+
# YWtvd6mBy6cJrDm77MbL2IK0cs0d9LiFAR6A+xuJKlQ5slvayA1VmXqHczsI5pgt
# 6o3gMy4SKfXAL1QnIffIrE7aKLixqduWsqdCosnPGUFN4Ib5KpqjEWYw07t0Mkvf
# Y3v1mYovG8chr1m1rtxEPJdQcdeh0sVV42neV8HR3jDA/czmTfsNv11P6Z0eGTgv
# vM9YBS7vDaBQNdrvCScc1bN+NR4Iuto229Nfj950iEkSoYICzjCCAjcCAQEwgfih
# gdCkgc0wgcoxCzAJBgNVBAYTAlVTMQswCQYDVQQIEwJXQTEQMA4GA1UEBxMHUmVk
# bW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMS0wKwYDVQQLEyRN
# aWNyb3NvZnQgSXJlbGFuZCBPcGVyYXRpb25zIExpbWl0ZWQxJjAkBgNVBAsTHVRo
# YWxlcyBUU1MgRVNOOjA4NDItNEJFNi1DMjlBMSUwIwYDVQQDExxNaWNyb3NvZnQg
# VGltZS1TdGFtcCBzZXJ2aWNloiMKAQEwBwYFKw4DAhoDFQBlMcHdEV4dkOyNKKJJ
# FQhZYCsigaCBgzCBgKR+MHwxCzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5n
# dG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9y
# YXRpb24xJjAkBgNVBAMTHU1pY3Jvc29mdCBUaW1lLVN0YW1wIFBDQSAyMDEwMA0G
# CSqGSIb3DQEBBQUAAgUA4Q9HWDAiGA8yMDE5MDgyNzE0MDgyNFoYDzIwMTkwODI4
# MTQwODI0WjB3MD0GCisGAQQBhFkKBAExLzAtMAoCBQDhD0dYAgEAMAoCAQACAibO
# AgH/MAcCAQACAhFtMAoCBQDhEJjYAgEAMDYGCisGAQQBhFkKBAIxKDAmMAwGCisG
# AQQBhFkKAwKgCjAIAgEAAgMHoSChCjAIAgEAAgMBhqAwDQYJKoZIhvcNAQEFBQAD
# gYEAKgO3mwjCOZziCMId9srxlB9hkt8MotYGXZZSnt8y/nw4yHG/y7Zn03pla8Ag
# AwAJrsX9pLN1AdlJzJggWlDHXtDdd6dI6DB0TPJnVbGycOzkzgg718h0Z83WIE45
# MzoEwgfVAikfefmaARByY5AezBe8FQVUKT3Uv09J4tlTlloxggMNMIIDCQIBATCB
# kzB8MQswCQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMH
# UmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMSYwJAYDVQQD
# Ex1NaWNyb3NvZnQgVGltZS1TdGFtcCBQQ0EgMjAxMAITMwAAANga5Mw/ehH64QAA
# AAAA2DANBglghkgBZQMEAgEFAKCCAUowGgYJKoZIhvcNAQkDMQ0GCyqGSIb3DQEJ
# EAEEMC8GCSqGSIb3DQEJBDEiBCAjUz60RPFV3N9AQPTWeno99c7TcTjofl/tSUEB
# xlVUZTCB+gYLKoZIhvcNAQkQAi8xgeowgecwgeQwgb0EIHM7ncd4XOjzdin/74SV
# qj0pQNFvCgT/IGvME59BLtgtMIGYMIGApH4wfDELMAkGA1UEBhMCVVMxEzARBgNV
# BAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jv
# c29mdCBDb3Jwb3JhdGlvbjEmMCQGA1UEAxMdTWljcm9zb2Z0IFRpbWUtU3RhbXAg
# UENBIDIwMTACEzMAAADYGuTMP3oR+uEAAAAAANgwIgQgfCQ0rxZniz9RX+jsxhWK
# 9V3zKTaDH5ORzDQgvNgFBVIwDQYJKoZIhvcNAQELBQAEggEAMa5PQHMuv7xdVi6K
# /ZojVAxBqWN94Mrnle83z9CMAtBtcYof/O/MwwXPGaCDfql5GNhK/t6aEoMtOC9+
# HOUPlPQQDLQaOS0pq8e+GQ/Mb+LVM0bYzeZLkon9PCUlHrK3sci/ZVGecuz7+BXo
# +Pix9SNFyp23agf3BJkfhGXUvxKLaMytcwVfY55Z4LwHMwBbdFjTtGjJiL6CbH4b
# XH6b7sK6HQKxobpQm8S4woaBhkEkXjSxOp/LYrKEDmHqrYO48eFlU+t4t0mtBfEy
# BbGZG2kfqglWYXCEnNTP1f8wxYI9expmNcZw63vWMRVnFAT6eQUm5Czj32mfN5Xb
# RM9OCg==
# SIG # End signature block
