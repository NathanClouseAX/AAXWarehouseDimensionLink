param(
    [string]$config = $(Throw 'config parameter required'), 
    [string]$log = $(Throw 'log parameter required'),
    [string]$channelDatabaseDacpacFolderOverridePath,
    [string]$customScriptFolderOverridePath
)
function Drop-ExistingChannelDatabaseSchema(
    [string]$serviceModelRootPath = $(Throw 'serviceModelRootPath parameter required'),
    [string]$config = $(Throw 'config parameter required'),
    [string]$log = $(Throw 'log parameter required')
)
{
    $dropChannelDatabaseSchemaScriptPath = Join-Path -Path $serviceModelRootPath -ChildPath 'Scripts\ApplyRetailDBScriptInSQLSUDropObjects.ps1'
    Write-Log -Message 'Dropping existing retail channel database schema'

    $global:LASTEXITCODE = 0
    & $dropChannelDatabaseSchemaScriptPath -config $config -log $log
    $capturedExitCode = $global:LASTEXITCODE

    if ($capturedExitCode -ne 0)
    {
        $errorMessage = "Error dropping existing retail channel database schema, exit code: $capturedExitCode"
        Write-Log -Message  $errorMessage -IsError
    }

    Write-Log -Message 'Successfully dropped existing retail channel database schema'
}

$global:LASTEXITCODE = 0

$settings = @{}
try
{
    $decodedConfig = [System.Text.Encoding]::UTF8.GetString([System.Convert]::FromBase64String($config))
    $settings = ConvertFrom-Json $decodedConfig

    $ScriptDir = Split-Path -Parent $PSCommandPath
    . $ScriptDir\Common-Configuration.ps1
    . $ScriptDir\Common-Database.ps1
    
    $dbServer = $settings.AxDbServer
    $dbName = $settings.AxDbName
    $dbUser = $settings.AxDbDeploySqlUser
    $dbPassword = $settings.AxDbDeploySqlPwd
    $retailRunTimeUser = $settings.dbUser
    $retailRunTimeUserPassword = $settings.dbPassword
    $retailDataSyncDbUser = $settings.dataSyncDbUser
    $retailDataSyncDbUserPassword = $settings.dataSyncDbUserPassword
    $retailExtensionsUser = $settings.AxDeployExtUser
    $retailExtensionsUserPassword = $settings.AxDeployExtUserPassword

    Write-Log ('Parameters retrieved from configuration string: dbServer = {0}; dbName = {1}; dbUser = {2}; dbPassword: *******; retailRunTimeUser = {3}; retailRuntimeDbUser = {4}; retailExtensionsUser = {5}' `
            -f $dbServer, $dbName, $dbUser, $retailRunTimeUser, $retailDataSyncDbUser, $retailExtensionsUser)

    $retailUsersToEnsure = @{$retailRunTimeUser = $retailRunTimeUserPassword; $retailDataSyncDbUser = $retailDataSyncDbUserPassword; $retailExtensionsUser = $retailExtensionsUserPassword}
    foreach($user in $retailUsersToEnsure.Keys)
    {
        try
        {
            $password = $retailUsersToEnsure[$user]
            $queryToEnsureUser = "
                DECLARE @isSqlAzure BIT
                SELECT @isSqlAzure = 0
                DECLARE @errorCode INT
                SELECT @errorCode = 0

                if (CHARINDEX('SQL Azure',@@VERSION) > 0)
                BEGIN
                    SELECT @isSqlAzure = 1
                END

                IF (@isSqlAzure = 0) -- Handle non SQL Azure
                BEGIN
                    -- Create login if not exists
                    IF NOT EXISTS(SELECT 1 FROM dbo.syslogins WHERE [NAME] = '$user')
                    BEGIN
                        CREATE LOGIN $user WITH PASSWORD = '$password'
                        SELECT @errorCode = @errorCode | 1
                    END

                    -- Create user from the login
                    IF NOT EXISTS (SELECT 1 FROM [sys].[sysusers] WHERE [NAME] = '$user' AND issqluser = 1)
                    BEGIN
                        CREATE USER $user FOR LOGIN $user
                        SELECT @errorCode = @errorCode | 4
                    END
                    
                    ALTER LOGIN $user WITH PASSWORD = '$password'
                    
                    -- Reassociate user and login
                    EXEC sp_change_users_login 'Update_One', '$user', '$user'

                END
                ELSE -- Handle SQL Azure
                BEGIN
                    -- SQL Azure login creation requires access to master database, we may not have this permission in current context, skip this part for now.
                    -- IF NOT EXISTS (SELECT 1 FROM [master].[sys].[sql_logins] WHERE [NAME] = '$user')
                    -- BEGIN
                    --  CREATE LOGIN $user WITH PASSWORD = '$password'
                    -- END

                    -- Create user if not exists
                    IF NOT EXISTS (SELECT 1 FROM [sys].[sysusers] WHERE [NAME] = '$user' AND islogin = 1 AND issqluser = 1)
                    BEGIN
                        -- For SQL Azure when the user is not available for login then we can't provision it during the script execution
                        -- needs to be provisioned in the 'master' database by DSE
                        -- RAISERROR('User $user not found as a valid login, it will need to be created in the master database, and the user should be created in the $dbName.  In Production environments this should be done by DSE team', 16, 1)
                        SELECT @errorCode = @errorCode | 8
                    END
                END
                SELECT @errorCode AS ErrorCode "
            Write-Log "Ensure user $user"
            $result = Invoke-SqlCmd -ServerInstance $dbServer -Database  $dbName -Username $dbUser -Password $dbPassword -Query $queryToEnsureUser -ErrorAction Stop
            
            if($result.ErrorCode -gt 0)
            {
                # This will leave the environment with a state that the Retail function may not work correctly.
                # But we will just generate a warning here in order not to break the updgrade automation. 
                # Migitation plan has been created to fix this environment with manual steps.
                Write-Warning "WARNING: Login or User '$user' doesn't exist in database, ErrorCode $($result.ErrorCode)."
            }
        }
        catch
        {
            $message = ($global:error[0] | format-list * -f | Out-String)
            Write-Warning "WARNING:$message"
        }
    }

    $PackageDirectory = Split-Path -Parent $ScriptDir
    $dbDeploymentAssetsRoot = Join-Path $PackageDirectory 'Data'
    
    $ChannelDatabaseBaselineScriptPath = Join-Path $dbDeploymentAssetsRoot 'CommerceRuntimeScripts_Create.sql'
    $ChannelDatabaseUpgradeCustomScriptFolderPath = Join-Path $dbDeploymentAssetsRoot 'Upgrade\Custom'
    $ChannelDatabaseUpgradeDacpacFileFolderPath = $dbDeploymentAssetsRoot
    $ChannelDatabaseUpgradeRetailScriptFolderPath = Join-Path $dbDeploymentAssetsRoot 'Upgrade\Retail'

    if (-not [String]::IsNullOrWhitespace($channelDatabaseDacpacFolderOverridePath))
    {
        # we only need to change $ChannelDatabaseUpgradeDacpacFileFolderPath because that is the only path used by Common-Database
        # to retrieve the dacpac used to create/update the database when deploying the channel database
        Write-Log "Channel database dacpac folder path was overriden to: $channelDatabaseDacpacFolderOverridePath"
        $ChannelDatabaseUpgradeDacpacFileFolderPath = $channelDatabaseDacpacFolderOverridePath
    }

    # If $customScriptFolderOverridePath is specified, use it to apply the database customizations.
    if (-not [String]::IsNullOrWhitespace($customScriptFolderOverridePath))
    {
        Write-Log "Channel database custom scripts folder path was overriden to: $customScriptFolderOverridePath"
        $ChannelDatabaseUpgradeCustomScriptFolderPath = $customScriptFolderOverridePath
    }

    # Drop the existing channel database schema before attempting to regenerate it.
    # By default, this step will be executed for initial deployment since the databackup may contains retail schema.
    # For minor version upgrdade, this step will be skipped since we want to perform a in-pleace upgrade.
    if($settings.SkipDatabaseSchemaDeletion -ieq "true")
    {
        Write-Log "SkipDatabaseSchemaDeletion is set to true, will skip the schema deletion."
    }
    else
    {
        Drop-ExistingChannelDatabaseSchema -serviceModelRootPath $PackageDirectory -config $config -log $log
    }
    
    $channelDbTopology = Join-Path $ScriptDir 'channeldb-topology-cloud.xml'
    $channelDbSettingTemplate = Join-Path $ScriptDir 'channeldb-settings-cloud.xml'
    $ChannelDbSettingCloud = Join-Path $ScriptDir 'channeldb-settings-cloudupdated.xml'
    $credentials = New-Object System.Management.Automation.PSCredential($dbUser, (ConvertTo-SecureString $dbPassword -AsPlainText -Force))
    $extensionUserCredentials = New-Object System.Management.Automation.PSCredential($retailExtensionsUser, (ConvertTo-SecureString $retailExtensionsUserPassword -AsPlainText -Force))



    Write-Log "Trying to upgrade Retail Channel database."
    
    Write-Log "setting up $ChannelDbSettingCloud for Microsoft upgrade."

    Set-Location $ScriptDir
    
    Invoke-Script -scriptBlock `
    {
        & (Join-Path $ScriptDir 'Setup-SettingsForDatabaseDeployment.ps1') `
                                -channelDatabaseServerName $dbserver `
                                -channelDatabaseName $dbname `
                                -SqlUserName $dbUser `
                                -ChannelDatabaseBaselineScriptPath $ChannelDatabaseBaselineScriptPath `
                                -ChannelDatabaseUpgradeCustomScriptFolderPath $ChannelDatabaseUpgradeCustomScriptFolderPath `
                                -ChannelDatabaseUpgradeDacpacFileFolderPath $ChannelDatabaseUpgradeDacpacFileFolderPath `
                                -ChannelDatabaseUpgradeRetailScriptFolderPath $ChannelDatabaseUpgradeRetailScriptFolderPath `
                                -SettingsXmlFilePathInput $channelDbSettingTemplate `
                                -SettingsXmlFilePathOutput $ChannelDbSettingCloud
    } -logFile $log
    
    Write-Log "Finished setting up $ChannelDbSettingCloud for Microsoft upgrade."
    Write-Log "Trying to upgrade base version for Retail Channel database."

    Invoke-Script -scriptBlock `
    {
        & (Join-Path $ScriptDir 'Deploy-Databases.ps1') `
                                -TopologyXmlFilePath $channelDbTopology `
                                -SettingsXmlFilePath $ChannelDbSettingCloud `
                                -Credentials $credentials `
                                -Verbose $True `
                                -DeploymentType "ChannelDB"
    } -logFile $log
    
    Write-Log "Finished upgrading base version for Retail Channel database."

    Log-TimedMessage 'Update roles for retail database users.'
    Set-RolesForCloudRetailChannelDatabase `
                            -Server $dbServer `
                            -Database $dbName `
                            -Credentials $credentials
    Log-TimedMessage 'Finished updating roles for retail database users.'

    Write-Log "setting up $ChannelDbSettingCloud for upgrading customizations for Retail Channel database."
    
    Invoke-Script -scriptBlock `
    {
        & (Join-Path $ScriptDir 'Setup-SettingsForDatabaseDeployment.ps1') `
                                -channelDatabaseServerName $dbserver `
                                -channelDatabaseName $dbname `
                                -SqlUserName $retailExtensionsUser `
                                -ChannelDatabaseBaselineScriptPath $ChannelDatabaseBaselineScriptPath `
                                -ChannelDatabaseUpgradeCustomScriptFolderPath $ChannelDatabaseUpgradeCustomScriptFolderPath `
                                -ChannelDatabaseUpgradeDacpacFileFolderPath $ChannelDatabaseUpgradeDacpacFileFolderPath `
                                -ChannelDatabaseUpgradeRetailScriptFolderPath $ChannelDatabaseUpgradeRetailScriptFolderPath `
                                -SettingsXmlFilePathInput $channelDbSettingTemplate `
                                -SettingsXmlFilePathOutput $ChannelDbSettingCloud
    } -logFile $log

    Write-Log "Finished setting up $ChannelDbSettingCloud for upgrading customizations for Retail Channel database."
    Write-Log "Trying to upgrade customizations for Retail Channel database."

    Invoke-Script -scriptBlock `
    {
        & (Join-Path $ScriptDir 'Deploy-Databases.ps1') `
                                -TopologyXmlFilePath $channelDbTopology `
                                -SettingsXmlFilePath $ChannelDbSettingCloud `
                                -Credentials $extensionUserCredentials `
                                -Verbose $True `
                                -DeploymentType "Customizations"
    } -logFile $log
    
    Write-Log "Finished upgrading customizations for Retail Channel database."
    
    
    $capturedExitCode = $global:LASTEXITCODE
    if($capturedExitCode -ne 0)
    {
        $errorMessage = "Error deploying retail channel database, exit code: $capturedExitCode"
        Write-Log -Message  $errorMessage -IsError
        throw $errorMessage
    }

    exit $capturedExitCode
}
catch
{
    # Will throw if the database deployment fails, generally this is a critical failure and it should fail, leave it to the caller to handle it if necessary.
    $exceptionMsg = ($global:error[0] | Format-List * -f | Out-String)
    $errorMsg = "Error executing the script ApplyRetailDBScriptInSQLSURetailSchema: $exceptionMsg."
    Write-Log $errorMsg
    throw $errorMsg
}
# SIG # Begin signature block
# MIIjnwYJKoZIhvcNAQcCoIIjkDCCI4wCAQExDzANBglghkgBZQMEAgEFADB5Bgor
# BgEEAYI3AgEEoGswaTA0BgorBgEEAYI3AgEeMCYCAwEAAAQQH8w7YFlLCE63JNLG
# KX7zUQIBAAIBAAIBAAIBAAIBADAxMA0GCWCGSAFlAwQCAQUABCBb25ipRhR1PNWR
# 1SMmAyb04EwreWZqQb9JgPiEgZ6toqCCDYEwggX/MIID56ADAgECAhMzAAABUZ6N
# j0Bxow5BAAAAAAFRMA0GCSqGSIb3DQEBCwUAMH4xCzAJBgNVBAYTAlVTMRMwEQYD
# VQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNy
# b3NvZnQgQ29ycG9yYXRpb24xKDAmBgNVBAMTH01pY3Jvc29mdCBDb2RlIFNpZ25p
# bmcgUENBIDIwMTEwHhcNMTkwNTAyMjEzNzQ2WhcNMjAwNTAyMjEzNzQ2WjB0MQsw
# CQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9u
# ZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMR4wHAYDVQQDExVNaWNy
# b3NvZnQgQ29ycG9yYXRpb24wggEiMA0GCSqGSIb3DQEBAQUAA4IBDwAwggEKAoIB
# AQCVWsaGaUcdNB7xVcNmdfZiVBhYFGcn8KMqxgNIvOZWNH9JYQLuhHhmJ5RWISy1
# oey3zTuxqLbkHAdmbeU8NFMo49Pv71MgIS9IG/EtqwOH7upan+lIq6NOcw5fO6Os
# +12R0Q28MzGn+3y7F2mKDnopVu0sEufy453gxz16M8bAw4+QXuv7+fR9WzRJ2CpU
# 62wQKYiFQMfew6Vh5fuPoXloN3k6+Qlz7zgcT4YRmxzx7jMVpP/uvK6sZcBxQ3Wg
# B/WkyXHgxaY19IAzLq2QiPiX2YryiR5EsYBq35BP7U15DlZtpSs2wIYTkkDBxhPJ
# IDJgowZu5GyhHdqrst3OjkSRAgMBAAGjggF+MIIBejAfBgNVHSUEGDAWBgorBgEE
# AYI3TAgBBggrBgEFBQcDAzAdBgNVHQ4EFgQUV4Iarkq57esagu6FUBb270Zijc8w
# UAYDVR0RBEkwR6RFMEMxKTAnBgNVBAsTIE1pY3Jvc29mdCBPcGVyYXRpb25zIFB1
# ZXJ0byBSaWNvMRYwFAYDVQQFEw0yMzAwMTIrNDU0MTM1MB8GA1UdIwQYMBaAFEhu
# ZOVQBdOCqhc3NyK1bajKdQKVMFQGA1UdHwRNMEswSaBHoEWGQ2h0dHA6Ly93d3cu
# bWljcm9zb2Z0LmNvbS9wa2lvcHMvY3JsL01pY0NvZFNpZ1BDQTIwMTFfMjAxMS0w
# Ny0wOC5jcmwwYQYIKwYBBQUHAQEEVTBTMFEGCCsGAQUFBzAChkVodHRwOi8vd3d3
# Lm1pY3Jvc29mdC5jb20vcGtpb3BzL2NlcnRzL01pY0NvZFNpZ1BDQTIwMTFfMjAx
# MS0wNy0wOC5jcnQwDAYDVR0TAQH/BAIwADANBgkqhkiG9w0BAQsFAAOCAgEAWg+A
# rS4Anq7KrogslIQnoMHSXUPr/RqOIhJX+32ObuY3MFvdlRElbSsSJxrRy/OCCZdS
# se+f2AqQ+F/2aYwBDmUQbeMB8n0pYLZnOPifqe78RBH2fVZsvXxyfizbHubWWoUf
# NW/FJlZlLXwJmF3BoL8E2p09K3hagwz/otcKtQ1+Q4+DaOYXWleqJrJUsnHs9UiL
# crVF0leL/Q1V5bshob2OTlZq0qzSdrMDLWdhyrUOxnZ+ojZ7UdTY4VnCuogbZ9Zs
# 9syJbg7ZUS9SVgYkowRsWv5jV4lbqTD+tG4FzhOwcRQwdb6A8zp2Nnd+s7VdCuYF
# sGgI41ucD8oxVfcAMjF9YX5N2s4mltkqnUe3/htVrnxKKDAwSYliaux2L7gKw+bD
# 1kEZ/5ozLRnJ3jjDkomTrPctokY/KaZ1qub0NUnmOKH+3xUK/plWJK8BOQYuU7gK
# YH7Yy9WSKNlP7pKj6i417+3Na/frInjnBkKRCJ/eYTvBH+s5guezpfQWtU4bNo/j
# 8Qw2vpTQ9w7flhH78Rmwd319+YTmhv7TcxDbWlyteaj4RK2wk3pY1oSz2JPE5PNu
# Nmd9Gmf6oePZgy7Ii9JLLq8SnULV7b+IP0UXRY9q+GdRjM2AEX6msZvvPCIoG0aY
# HQu9wZsKEK2jqvWi8/xdeeeSI9FN6K1w4oVQM4Mwggd6MIIFYqADAgECAgphDpDS
# AAAAAAADMA0GCSqGSIb3DQEBCwUAMIGIMQswCQYDVQQGEwJVUzETMBEGA1UECBMK
# V2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0
# IENvcnBvcmF0aW9uMTIwMAYDVQQDEylNaWNyb3NvZnQgUm9vdCBDZXJ0aWZpY2F0
# ZSBBdXRob3JpdHkgMjAxMTAeFw0xMTA3MDgyMDU5MDlaFw0yNjA3MDgyMTA5MDla
# MH4xCzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdS
# ZWRtb25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xKDAmBgNVBAMT
# H01pY3Jvc29mdCBDb2RlIFNpZ25pbmcgUENBIDIwMTEwggIiMA0GCSqGSIb3DQEB
# AQUAA4ICDwAwggIKAoICAQCr8PpyEBwurdhuqoIQTTS68rZYIZ9CGypr6VpQqrgG
# OBoESbp/wwwe3TdrxhLYC/A4wpkGsMg51QEUMULTiQ15ZId+lGAkbK+eSZzpaF7S
# 35tTsgosw6/ZqSuuegmv15ZZymAaBelmdugyUiYSL+erCFDPs0S3XdjELgN1q2jz
# y23zOlyhFvRGuuA4ZKxuZDV4pqBjDy3TQJP4494HDdVceaVJKecNvqATd76UPe/7
# 4ytaEB9NViiienLgEjq3SV7Y7e1DkYPZe7J7hhvZPrGMXeiJT4Qa8qEvWeSQOy2u
# M1jFtz7+MtOzAz2xsq+SOH7SnYAs9U5WkSE1JcM5bmR/U7qcD60ZI4TL9LoDho33
# X/DQUr+MlIe8wCF0JV8YKLbMJyg4JZg5SjbPfLGSrhwjp6lm7GEfauEoSZ1fiOIl
# XdMhSz5SxLVXPyQD8NF6Wy/VI+NwXQ9RRnez+ADhvKwCgl/bwBWzvRvUVUvnOaEP
# 6SNJvBi4RHxF5MHDcnrgcuck379GmcXvwhxX24ON7E1JMKerjt/sW5+v/N2wZuLB
# l4F77dbtS+dJKacTKKanfWeA5opieF+yL4TXV5xcv3coKPHtbcMojyyPQDdPweGF
# RInECUzF1KVDL3SV9274eCBYLBNdYJWaPk8zhNqwiBfenk70lrC8RqBsmNLg1oiM
# CwIDAQABo4IB7TCCAekwEAYJKwYBBAGCNxUBBAMCAQAwHQYDVR0OBBYEFEhuZOVQ
# BdOCqhc3NyK1bajKdQKVMBkGCSsGAQQBgjcUAgQMHgoAUwB1AGIAQwBBMAsGA1Ud
# DwQEAwIBhjAPBgNVHRMBAf8EBTADAQH/MB8GA1UdIwQYMBaAFHItOgIxkEO5FAVO
# 4eqnxzHRI4k0MFoGA1UdHwRTMFEwT6BNoEuGSWh0dHA6Ly9jcmwubWljcm9zb2Z0
# LmNvbS9wa2kvY3JsL3Byb2R1Y3RzL01pY1Jvb0NlckF1dDIwMTFfMjAxMV8wM18y
# Mi5jcmwwXgYIKwYBBQUHAQEEUjBQME4GCCsGAQUFBzAChkJodHRwOi8vd3d3Lm1p
# Y3Jvc29mdC5jb20vcGtpL2NlcnRzL01pY1Jvb0NlckF1dDIwMTFfMjAxMV8wM18y
# Mi5jcnQwgZ8GA1UdIASBlzCBlDCBkQYJKwYBBAGCNy4DMIGDMD8GCCsGAQUFBwIB
# FjNodHRwOi8vd3d3Lm1pY3Jvc29mdC5jb20vcGtpb3BzL2RvY3MvcHJpbWFyeWNw
# cy5odG0wQAYIKwYBBQUHAgIwNB4yIB0ATABlAGcAYQBsAF8AcABvAGwAaQBjAHkA
# XwBzAHQAYQB0AGUAbQBlAG4AdAAuIB0wDQYJKoZIhvcNAQELBQADggIBAGfyhqWY
# 4FR5Gi7T2HRnIpsLlhHhY5KZQpZ90nkMkMFlXy4sPvjDctFtg/6+P+gKyju/R6mj
# 82nbY78iNaWXXWWEkH2LRlBV2AySfNIaSxzzPEKLUtCw/WvjPgcuKZvmPRul1LUd
# d5Q54ulkyUQ9eHoj8xN9ppB0g430yyYCRirCihC7pKkFDJvtaPpoLpWgKj8qa1hJ
# Yx8JaW5amJbkg/TAj/NGK978O9C9Ne9uJa7lryft0N3zDq+ZKJeYTQ49C/IIidYf
# wzIY4vDFLc5bnrRJOQrGCsLGra7lstnbFYhRRVg4MnEnGn+x9Cf43iw6IGmYslmJ
# aG5vp7d0w0AFBqYBKig+gj8TTWYLwLNN9eGPfxxvFX1Fp3blQCplo8NdUmKGwx1j
# NpeG39rz+PIWoZon4c2ll9DuXWNB41sHnIc+BncG0QaxdR8UvmFhtfDcxhsEvt9B
# xw4o7t5lL+yX9qFcltgA1qFGvVnzl6UJS0gQmYAf0AApxbGbpT9Fdx41xtKiop96
# eiL6SJUfq/tHI4D1nvi/a7dLl+LrdXga7Oo3mXkYS//WsyNodeav+vyL6wuA6mk7
# r/ww7QRMjt/fdW1jkT3RnVZOT7+AVyKheBEyIXrvQQqxP/uozKRdwaGIm1dxVk5I
# RcBCyZt2WwqASGv9eZ/BvW1taslScxMNelDNMYIVdDCCFXACAQEwgZUwfjELMAkG
# A1UEBhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQx
# HjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEoMCYGA1UEAxMfTWljcm9z
# b2Z0IENvZGUgU2lnbmluZyBQQ0EgMjAxMQITMwAAAVGejY9AcaMOQQAAAAABUTAN
# BglghkgBZQMEAgEFAKCByDAZBgkqhkiG9w0BCQMxDAYKKwYBBAGCNwIBBDAcBgor
# BgEEAYI3AgELMQ4wDAYKKwYBBAGCNwIBFTAvBgkqhkiG9w0BCQQxIgQgYOr/BLQg
# GtL54kymXis03fNJ4pYCkQRbprn518HHq0AwXAYKKwYBBAGCNwIBDDFOMEygLoAs
# AFIAZQB0AGEAaQBsAE0AaQBuAG8AcgBVAHAAZwByAGEAZABlAC4AcABzADGhGoAY
# aHR0cDovL3d3dy5taWNyb3NvZnQuY29tMA0GCSqGSIb3DQEBAQUABIIBAH416nDS
# 192csW9h5Axxd7ASdvTtS+ZUdFu8luDf/1eO+/D5HNZ+fyEq94WS7n0UJeCyKoo1
# tqrVlc2aHiNwPVaBe/B9j5tK8PT1uECsJSPT8YXPjpMDDS94LdGkYfeToGwqyPhS
# UKyKCG8CgO8eE0L3yr8WIC5y+fI56oC46T0LRIxgiMdme6W2RfMaX3NmKG6HY05W
# YlaRwDeKI1jSXQ1h1vqVJNyyJYlHdnJtYw3+6vJzJePYax+BgXi4BlUhLHllv6oq
# a7WujoSPveDDtmwkI7ZWM6AJ+7F81BYygCDWqnRZHeFo+46Oowwi/4i8y1/54Q8E
# DzfL+H+ZXGxbmTuhghLkMIIS4AYKKwYBBAGCNwMDATGCEtAwghLMBgkqhkiG9w0B
# BwKgghK9MIISuQIBAzEPMA0GCWCGSAFlAwQCAQUAMIIBUAYLKoZIhvcNAQkQAQSg
# ggE/BIIBOzCCATcCAQEGCisGAQQBhFkKAwEwMTANBglghkgBZQMEAgEFAAQggwUU
# q6IVNCKcPMEDHJp6uCOYB//I2ckT1FP4UcSj7DQCBl1exgAcKRgSMjAxOTA4Mjcw
# NzIzMzUuMzRaMASAAgH0oIHQpIHNMIHKMQswCQYDVQQGEwJVUzELMAkGA1UECBMC
# V0ExEDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3Jh
# dGlvbjEtMCsGA1UECxMkTWljcm9zb2Z0IElyZWxhbmQgT3BlcmF0aW9ucyBMaW1p
# dGVkMSYwJAYDVQQLEx1UaGFsZXMgVFNTIEVTTjozQkQ0LTRCODAtNjlDMzElMCMG
# A1UEAxMcTWljcm9zb2Z0IFRpbWUtU3RhbXAgc2VydmljZaCCDjwwggTxMIID2aAD
# AgECAhMzAAAA2khVAmRImjRmAAAAAADaMA0GCSqGSIb3DQEBCwUAMHwxCzAJBgNV
# BAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4w
# HAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xJjAkBgNVBAMTHU1pY3Jvc29m
# dCBUaW1lLVN0YW1wIFBDQSAyMDEwMB4XDTE4MDgyMzIwMjY1MloXDTE5MTEyMzIw
# MjY1MlowgcoxCzAJBgNVBAYTAlVTMQswCQYDVQQIEwJXQTEQMA4GA1UEBxMHUmVk
# bW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMS0wKwYDVQQLEyRN
# aWNyb3NvZnQgSXJlbGFuZCBPcGVyYXRpb25zIExpbWl0ZWQxJjAkBgNVBAsTHVRo
# YWxlcyBUU1MgRVNOOjNCRDQtNEI4MC02OUMzMSUwIwYDVQQDExxNaWNyb3NvZnQg
# VGltZS1TdGFtcCBzZXJ2aWNlMIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKC
# AQEAx0UoLe4vNxhzxk2Ore+olTarBAw8M+8pP/7bYoR0RzI2qxg57j1KvMrvRY7t
# erX2QP6Cilu/GW0Xeem+VHGq3LPjAh9fS4hG7x0CwArBvKgnmgMpwxjkXfdo0ORp
# KkYMLkuSgC+yuBMSA1nPg/loOYks0vkbSsPXY/jV7P8lhprmBFCoVaxexT8kvty0
# UNPuwwjuMaZjppd9BpxIN/IlFmkbVN7qOlWLaYbTFCnD3iRt+bJ5+kMlTZezwNDY
# bNiPtluAE8V8XmgxOP/YNQwgL77i69wy2+GVggp/HKSjLuHa3SkN5gIrDieNUBT0
# 66XSuQg2BUZKThgwvDKlnC7/AQIDAQABo4IBGzCCARcwHQYDVR0OBBYEFGvcyOOH
# RwyBAs4sSmwFNtZOPwAuMB8GA1UdIwQYMBaAFNVjOlyKMZDzQ3t8RhvFM2hahW1V
# MFYGA1UdHwRPME0wS6BJoEeGRWh0dHA6Ly9jcmwubWljcm9zb2Z0LmNvbS9wa2kv
# Y3JsL3Byb2R1Y3RzL01pY1RpbVN0YVBDQV8yMDEwLTA3LTAxLmNybDBaBggrBgEF
# BQcBAQROMEwwSgYIKwYBBQUHMAKGPmh0dHA6Ly93d3cubWljcm9zb2Z0LmNvbS9w
# a2kvY2VydHMvTWljVGltU3RhUENBXzIwMTAtMDctMDEuY3J0MAwGA1UdEwEB/wQC
# MAAwEwYDVR0lBAwwCgYIKwYBBQUHAwgwDQYJKoZIhvcNAQELBQADggEBAEvsYsH3
# XPF4NGqXMXQXzBh9VaZHNV/uQwJpSJ9C3JF3tNBifSp0jrLS6YvTnYOwrnVKoP7w
# nZXly3wpxJpE6msoMRxli4cg97tCeqoVT6S6jjCiXSdUkk1UHngbX7jOgwRgXZZx
# L/WDolOpO0fZJj2MX1vpcCe20nSrGnzR+Wu52+CvYYIS8XVaUkFW7zHlFdNIx10Q
# A59hQK+d1H/kHavOHt6S4Pmr+iJu67csCUUVRfVC5dVKrnYwuVx5q4AQGrBbPiLo
# KSmUqaVF8vkLhDNMpevnLfSk7KOKEZP3Km7bk1+ibhTOO9ALV/RXD2U2BEiP0MIu
# go292xJc9/10UiAwggZxMIIEWaADAgECAgphCYEqAAAAAAACMA0GCSqGSIb3DQEB
# CwUAMIGIMQswCQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UE
# BxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMTIwMAYD
# VQQDEylNaWNyb3NvZnQgUm9vdCBDZXJ0aWZpY2F0ZSBBdXRob3JpdHkgMjAxMDAe
# Fw0xMDA3MDEyMTM2NTVaFw0yNTA3MDEyMTQ2NTVaMHwxCzAJBgNVBAYTAlVTMRMw
# EQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVN
# aWNyb3NvZnQgQ29ycG9yYXRpb24xJjAkBgNVBAMTHU1pY3Jvc29mdCBUaW1lLVN0
# YW1wIFBDQSAyMDEwMIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAqR0N
# vHcRijog7PwTl/X6f2mUa3RUENWlCgCChfvtfGhLLF/Fw+Vhwna3PmYrW/AVUycE
# MR9BGxqVHc4JE458YTBZsTBED/FgiIRUQwzXTbg4CLNC3ZOs1nMwVyaCo0UN0Or1
# R4HNvyRgMlhgRvJYR4YyhB50YWeRX4FUsc+TTJLBxKZd0WETbijGGvmGgLvfYfxG
# wScdJGcSchohiq9LZIlQYrFd/XcfPfBXday9ikJNQFHRD5wGPmd/9WbAA5ZEfu/Q
# S/1u5ZrKsajyeioKMfDaTgaRtogINeh4HLDpmc085y9Euqf03GS9pAHBIAmTeM38
# vMDJRF1eFpwBBU8iTQIDAQABo4IB5jCCAeIwEAYJKwYBBAGCNxUBBAMCAQAwHQYD
# VR0OBBYEFNVjOlyKMZDzQ3t8RhvFM2hahW1VMBkGCSsGAQQBgjcUAgQMHgoAUwB1
# AGIAQwBBMAsGA1UdDwQEAwIBhjAPBgNVHRMBAf8EBTADAQH/MB8GA1UdIwQYMBaA
# FNX2VsuP6KJcYmjRPZSQW9fOmhjEMFYGA1UdHwRPME0wS6BJoEeGRWh0dHA6Ly9j
# cmwubWljcm9zb2Z0LmNvbS9wa2kvY3JsL3Byb2R1Y3RzL01pY1Jvb0NlckF1dF8y
# MDEwLTA2LTIzLmNybDBaBggrBgEFBQcBAQROMEwwSgYIKwYBBQUHMAKGPmh0dHA6
# Ly93d3cubWljcm9zb2Z0LmNvbS9wa2kvY2VydHMvTWljUm9vQ2VyQXV0XzIwMTAt
# MDYtMjMuY3J0MIGgBgNVHSABAf8EgZUwgZIwgY8GCSsGAQQBgjcuAzCBgTA9Bggr
# BgEFBQcCARYxaHR0cDovL3d3dy5taWNyb3NvZnQuY29tL1BLSS9kb2NzL0NQUy9k
# ZWZhdWx0Lmh0bTBABggrBgEFBQcCAjA0HjIgHQBMAGUAZwBhAGwAXwBQAG8AbABp
# AGMAeQBfAFMAdABhAHQAZQBtAGUAbgB0AC4gHTANBgkqhkiG9w0BAQsFAAOCAgEA
# B+aIUQ3ixuCYP4FxAz2do6Ehb7Prpsz1Mb7PBeKp/vpXbRkws8LFZslq3/Xn8Hi9
# x6ieJeP5vO1rVFcIK1GCRBL7uVOMzPRgEop2zEBAQZvcXBf/XPleFzWYJFZLdO9C
# EMivv3/Gf/I3fVo/HPKZeUqRUgCvOA8X9S95gWXZqbVr5MfO9sp6AG9LMEQkIjzP
# 7QOllo9ZKby2/QThcJ8ySif9Va8v/rbljjO7Yl+a21dA6fHOmWaQjP9qYn/dxUoL
# kSbiOewZSnFjnXshbcOco6I8+n99lmqQeKZt0uGc+R38ONiU9MalCpaGpL2eGq4E
# QoO4tYCbIjggtSXlZOz39L9+Y1klD3ouOVd2onGqBooPiRa6YacRy5rYDkeagMXQ
# zafQ732D8OE7cQnfXXSYIghh2rBQHm+98eEA3+cxB6STOvdlR3jo+KhIq/fecn5h
# a293qYHLpwmsObvsxsvYgrRyzR30uIUBHoD7G4kqVDmyW9rIDVWZeodzOwjmmC3q
# jeAzLhIp9cAvVCch98isTtoouLGp25ayp0Kiyc8ZQU3ghvkqmqMRZjDTu3QyS99j
# e/WZii8bxyGvWbWu3EQ8l1Bx16HSxVXjad5XwdHeMMD9zOZN+w2/XU/pnR4ZOC+8
# z1gFLu8NoFA12u8JJxzVs341Hgi62jbb01+P3nSISRKhggLOMIICNwIBATCB+KGB
# 0KSBzTCByjELMAkGA1UEBhMCVVMxCzAJBgNVBAgTAldBMRAwDgYDVQQHEwdSZWRt
# b25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xLTArBgNVBAsTJE1p
# Y3Jvc29mdCBJcmVsYW5kIE9wZXJhdGlvbnMgTGltaXRlZDEmMCQGA1UECxMdVGhh
# bGVzIFRTUyBFU046M0JENC00QjgwLTY5QzMxJTAjBgNVBAMTHE1pY3Jvc29mdCBU
# aW1lLVN0YW1wIHNlcnZpY2WiIwoBATAHBgUrDgMCGgMVAHRM00xKLaEEqRs6edgp
# DbuC5oWSoIGDMIGApH4wfDELMAkGA1UEBhMCVVMxEzARBgNVBAgTCldhc2hpbmd0
# b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3Jh
# dGlvbjEmMCQGA1UEAxMdTWljcm9zb2Z0IFRpbWUtU3RhbXAgUENBIDIwMTAwDQYJ
# KoZIhvcNAQEFBQACBQDhDzM2MCIYDzIwMTkwODI3MTI0MjMwWhgPMjAxOTA4Mjgx
# MjQyMzBaMHcwPQYKKwYBBAGEWQoEATEvMC0wCgIFAOEPMzYCAQAwCgIBAAICJtIC
# Af8wBwIBAAICEW0wCgIFAOEQhLYCAQAwNgYKKwYBBAGEWQoEAjEoMCYwDAYKKwYB
# BAGEWQoDAqAKMAgCAQACAwehIKEKMAgCAQACAwGGoDANBgkqhkiG9w0BAQUFAAOB
# gQA4YPbFbqZk4lwbBUQkmbJFp8jUIDcLwRKY1F0NNLZZL/1lpjOFKrox6x4CxisC
# 9GlNIefWJbnlRqCthTASOJKMK/wBOyXN+t4XEuDm2fMo9oxOyKeVF4Q9eFdQA6xu
# izUGcj2c6jTRwOBY3Y6iKde+WS3zyKpzjWEZlXon8gjKpzGCAw0wggMJAgEBMIGT
# MHwxCzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdS
# ZWRtb25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xJjAkBgNVBAMT
# HU1pY3Jvc29mdCBUaW1lLVN0YW1wIFBDQSAyMDEwAhMzAAAA2khVAmRImjRmAAAA
# AADaMA0GCWCGSAFlAwQCAQUAoIIBSjAaBgkqhkiG9w0BCQMxDQYLKoZIhvcNAQkQ
# AQQwLwYJKoZIhvcNAQkEMSIEIKi5kTmNgZu0OBsJW5JcwfiH3SGkydg0bIptH9aT
# 9PqUMIH6BgsqhkiG9w0BCRACLzGB6jCB5zCB5DCBvQQgis27W7zapYOXiyrehIxm
# 4yubIaVWHfStjvtrDWsVMRMwgZgwgYCkfjB8MQswCQYDVQQGEwJVUzETMBEGA1UE
# CBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9z
# b2Z0IENvcnBvcmF0aW9uMSYwJAYDVQQDEx1NaWNyb3NvZnQgVGltZS1TdGFtcCBQ
# Q0EgMjAxMAITMwAAANpIVQJkSJo0ZgAAAAAA2jAiBCBeu+pDlXNv06ZnnAPis5aY
# UQvrVGIYKQzgmZ8PE+G8MTANBgkqhkiG9w0BAQsFAASCAQC7DQTzF1uFY7p1YMTe
# wqzN31mOCtyVgn1jBVab46DTdGVtIhQcsUkm8RlSdqhNF9TRP09g+qtq9DYA/huX
# LWarIT7vdHV2F8ZRiN4wMLNJCHYdUZljqf00SHrNpJEZp2yc6jjelkCL8nIVxeFF
# TpG9KK0aCQ+P6WARh72slw8WIy+71muGbr2f5gzr01kXP+pR9rxMElLu3JJ0YX+W
# 5xefoCzMN9scIHjyXP3k8jfyux77y0vVXyW8agjkQqSWkU0lUMGMJysferUrBWtR
# rd5AsIIWxUnutScZMCiE3LhoFjNwUU2bJXg4rwhbobaNFi3t15+4iJFcpz70mOyz
# 6O7M
# SIG # End signature block
