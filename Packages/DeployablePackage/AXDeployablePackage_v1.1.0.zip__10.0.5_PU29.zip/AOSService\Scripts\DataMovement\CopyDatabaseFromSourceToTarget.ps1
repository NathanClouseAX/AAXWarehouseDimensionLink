﻿    
    ##################
    ### Parameters ###
    ##################
    param(
        [Parameter(Mandatory=$true)]
	    [string]$source_ServerName,
        [Parameter(Mandatory=$true)]
        [string]$source_UserId,
        [Parameter(Mandatory=$true)]
        [string]$source_Password,
        [Parameter(Mandatory=$true)]
        [string]$source_DatabaseName,
        [Parameter(Mandatory=$true)]
        [string]$target_ServerName,
        [Parameter(Mandatory=$true)]
        [string]$target_UserId,
        [Parameter(Mandatory=$true)]
        [string]$target_Password,
        [Parameter(Mandatory=$true)]
        [string]$target_DatabaseName,
        [Parameter(Mandatory=$true)]
        $sqlUserJsonData,
        [Parameter(Mandatory=$true)]
        [string]$dbName
    )
    
    ######################
    ### Helper methods ###
    ######################
    function IsLocalServer([string] $serverName)
    {
        if ($serverName -eq $null) { return $false }
    
        if ("." -eq $serverName) { return $true }
        if ("(local)" -eq $serverName) { return $true }
        if ("localhost" -eq $serverName) { return $true }
        if ("127.0.0.1" -eq $serverName) { return $true }
        if ([System.Environment]::MachineName -eq $serverName.Split('.')[0]) { return $true }

        return $false
    }

    function CreateLogin($sqlParams, $newUser, $password)
    {
        $createLoginStmt = @"
        IF NOT EXISTS (SELECT name FROM sys.sql_logins WHERE name = '$newUser')
        BEGIN
            CREATE LOGIN [$newUser] WITH PASSWORD = N'$password'
        END
        ELSE
        BEGIN
            ALTER LOGIN [$newUser] WITH PASSWORD = N'$password'
        END
"@
     Write-Log "Creating login for: $newUser"
        $sqlParams.Query = $createLoginStmt
        Invoke-Sqlcmd @sqlParams | Out-Null
    }

    function CreateUserForLogin($sqlParams, $newUser)
    {
        $createUserStmt = @"
        IF NOT EXISTS(SELECT name FROM sys.database_principals WHERE name = '$newUser' AND TYPE = 'S')
        BEGIN
            CREATE USER [$newUser] FOR LOGIN [$newUser] WITH DEFAULT_SCHEMA = [dbo]
        END
"@
        Write-Log "Creating user: $newUser for login."
        $sqlParams.Query = $createUserStmt
        Invoke-Sqlcmd @sqlParams | Out-Null
    }

    function AddUserToRole($sqlParams, $user, $role)
    {
        $alterRoleStmt = @"
        IF IS_ROLEMEMBER('$role', '$user') = 0
        BEGIN
            ALTER ROLE [$role] ADD MEMBER [$user]
        END 
"@
	    Write-Log "Adding user: $user to Role: $role"
        $sqlParams.Query = $alterRoleStmt
        Invoke-Sqlcmd @sqlParams | Out-Null
    }

    function VerifyUserAccess($serverName, $databaseName, $user, $password)
    {

        $sqlStatement = @"
    
        SELECT HAS_DBACCESS('$($databaseName)')
"@  

        Write-Log "Testing $user access against $databaseName on server $serverName"

        Invoke-SQLcmd -ServerInstance $serverName -Database $databaseName -Username $user -Password $password -Query $sqlStatement -OutputSqlErrors $True | Out-Null
    
    }

    ### Functions for removing copy user after completed

    function RemoveUserFromRole($sqlParams, $user, $role)
    {
        $removeRoleStmt = @"
        IF IS_ROLEMEMBER('$role', '$user') = 1
        BEGIN
            ALTER ROLE [$role] DROP MEMBER [$user]
        END 
"@

	    Write-Log "Removing user: $user from role: $role"

        $sqlParams.Query = $removeRoleStmt
        Invoke-Sqlcmd @sqlParams | Out-Null
    }

    function RemoveUserForLogin($sqlParams, $newUser)
    {
        $removeUserStmt = @"
        IF EXISTS(SELECT name FROM sys.database_principals WHERE name = '$newUser' AND TYPE = 'S')
        BEGIN
            DROP USER [$newUser]
        END
"@

        Write-Log "Removing user: $newUser from login."
        $sqlParams.Query = $removeUserStmt
        Invoke-Sqlcmd @sqlParams | Out-Null
    }

    function RemoveLogin($sqlParams, $newUser, $password)
    {
        $removeLoginStmt = @"
        IF EXISTS (SELECT name FROM sys.sql_logins WHERE name = '$newUser')
        BEGIN
            DROP LOGIN [$newUser]
        END
"@
	    Write-Log "Removing login: $newUser"
        $sqlParams.Query = $removeLoginStmt
        Invoke-Sqlcmd @sqlParams | Out-Null
    }

    function ModifyDatabaseLevel ($sqlParams, $databseName, $edition, $serviceLevel, $maxSize)
    {
         $modifyDBStmt = @"
	     Alter database [$databseName] modify (Edition='$edition', service_objective='$serviceLevel', MAXSIZE=$maxSize);
"@
         $target_sqlParams.Query = $modifyDBStmt
         Write-Log "About to run query: $($target_sqlParams.Query)"
         Invoke-Sqlcmd @target_sqlParams	
         Write-Log "Waiting for 30 secs before checking the status"
         Start-Sleep -Seconds 30

         #Monitor the progress of the operation
         $monitorOperationStmt = @"
         select top 1 1 from (
	        select
		        *,
			    row_number() over (partition by resource_type, major_resource_id, minor_resource_id order by start_time desc) as rowNum
		    from sys.dm_operation_status) currentdb
		    where rowNum = 1
			    and resource_type_desc = 'Database'
			    and major_resource_id = '$databseName'
			    and state=1
"@
         $target_sqlParams.Query = $monitorOperationStmt
         Write-Log "About to run Query : $($target_sqlParams.Query) to check the status of command."
         $value = Invoke-Sqlcmd @target_sqlParams

         While($($Value.Column1) -ne $null)
         {
            "Operation still in progress."
            Start-Sleep -Seconds 10
            $value = Invoke-Sqlcmd @target_sqlParams
         }
    }

	#######################################
	### Initialize additional variables ###
	#######################################
	$source_sqlParams = @{
    'Database' = ''
    'UserName' = $source_UserId
    'Password' = $source_Password
    'ServerInstance' = $source_ServerName
    'EncryptConnection' = !(IsLocalServer($source_ServerName))
    'Query' = ''
	}

	$target_sqlParams = @{
    'Database' = ''
    'UserName' = $target_UserId
    'Password' = $target_Password
    'ServerInstance' = $target_ServerName
    'EncryptConnection' = !(IsLocalServer($target_ServerName))
    'Query' = ''
    'QueryTimeout' = 0
	}

    $standardEdition = "Standard"
    $premiumEdition = "Premium"

	##########################################
	### Pre-Requisite checks prior to copy ###
	##########################################

	Write-Log "Starting pre-requisite checks." 

	# Test $target_UserId against Target DB

	VerifyUserAccess -serverName $target_ServerName -Database $target_DatabaseName -user $target_UserId -password $target_Password

	Write-Log "Verified sqluser access to target database." 

	# Test $source_UserId against Source DB

	VerifyUserAccess -serverName $source_ServerName -Database $source_DatabaseName -user $source_UserId -password $source_Password

	Write-Log "Verified sqluser access to source database."

	####################################################################
	### Check target server for existing db name "_orig" i.e. backup ###
	####################################################################

	$currentDate = Get-Date -UFormat "%Y%m%d%H%M"
	$standardTargetDbBackupName = $($target_DatabaseName + '_orig')
	$formerTargetDbBackupName = $standardTargetDbBackupName + '_' + $currentDate
	$target_sqlParams.Database = 'master'
	$target_sqlParams.Query = @"
	IF EXISTS (SELECT 'x' FROM SYS.DATABASES WHERE NAME = '$standardTargetDbBackupName')
	BEGIN
		ALTER DATABASE [$standardTargetDbBackupName] MODIFY NAME = [$formerTargetDbBackupName]
	END
"@
	Invoke-Sqlcmd @target_sqlParams

	#########################################
	### Create temporary user for copying ###
	#########################################

	Write-Log "The copy user will be removed and recreated if it already exists to prevent errors during copy."

	$upgrade_SqlUser = 'ax_update'
	$upgrade_Password = $target_Password

	##################################################
	#### Remove Copy Users If Exist Prior to Copy. ###
	##################################################

	# Remove from source
	Write-Log "Removing copy user (if exists) in source sql server prior to copy."
	$source_sqlParams.Database = $source_DatabaseName
	RemoveUserFromRole $source_sqlParams $upgrade_SqlUser 'db_owner'
	RemoveUserForLogin $source_sqlParams $upgrade_SqlUser

	$source_sqlParams.Database = 'master'
	RemoveUserForLogin $source_sqlParams $upgrade_SqlUser
	RemoveLogin $source_sqlParams $upgrade_SqlUser

	# Remove from target
	Write-Log "Removing copy user (if exists) in target sql server prior to copy."
	$target_sqlParams.Database = 'master'
	RemoveUserFromRole $target_sqlParams $upgrade_SqlUser 'dbmanager'
	RemoveUserForLogin $target_sqlParams $upgrade_SqlUser
	RemoveLogin $target_sqlParams $upgrade_SqlUser


	#############################################################################
	#### Create user in source sql server to perform database copy operation. ###
	#############################################################################

	Write-Log "Creating copy user in source sql server."

	$source_sqlParams.Database = 'master'
	CreateLogin $source_sqlParams $upgrade_SqlUser $upgrade_Password
	CreateUserForLogin $source_sqlParams $upgrade_SqlUser
	AddUserTorole $source_sqlParams $upgrade_SqlUser 'dbmanager'

	$source_sqlParams.Database = $source_DatabaseName
	CreateUserForLogin $source_sqlParams $upgrade_SqlUser
	AddUserToRole $source_sqlParams $upgrade_SqlUser 'db_owner'

	############################################################################
	### Create user in target sql server to perform database copy operation. ###
	############################################################################

	Write-Log "Creating copy user in target sql server."

	$target_sqlParams.Database = 'master'
	CreateLogin $target_sqlParams $upgrade_SqlUser $upgrade_Password
	CreateUserForLogin $target_sqlParams $upgrade_SqlUser
	AddUserToRole $target_sqlParams $upgrade_SqlUser 'dbmanager'


    ###########################################
	### Get Service Level from Target DB    ###
	###########################################

    [bool]$isLevelChanged = $false
    [bool]$isAdjustMaxSize = $false

    ##### Get the source SLO, Edition, maxsize and physical file size ############################
    #SLO
    $source_sqlParams.Database = $Source_DatabaseName
	$source_sqlParams.Query = @"
	SELECT DATABASEPROPERTYEX('$Source_DatabaseName', 'ServiceObjective')
"@
	$sourceServicelevel = (Invoke-SqlCmd @source_sqlParams).Column1
    if([string]::IsNullOrEmpty($sourceServicelevel))
    {
        Write-Log -IsError "Cannot retrieve the service objective for source database: $Source_DatabaseName"
    }

	Write-Log "Source db service level: $sourceServicelevel"

    #Edition
    $source_sqlParams.Query = @"
	SELECT DATABASEPROPERTYEX('$Source_DatabaseName', 'Edition')
"@
	$sourceEdition = (Invoke-Sqlcmd @source_sqlParams).Column1
    if([string]::IsNullOrEmpty($sourceEdition))
    {
        Write-Log -IsError "Cannot retrieve the edition for source database: $Source_DatabaseName"
    }
    Write-Log "Source Edition is: $sourceEdition"

    #MaxSize
    $source_sqlParams.Query = @"
	SELECT DATABASEPROPERTYEX('$Source_DatabaseName', 'MaxSizeInBytes') AS SizeInBytes,
           SUM(CAST(DATABASEPROPERTYEX('$Source_DatabaseName', 'MaxSizeInBytes') AS bigint)) / 1024 / 1024 AS SizeInMB,
           SUM(CAST(DATABASEPROPERTYEX('$Source_DatabaseName', 'MaxSizeInBytes') AS bigint)) / 1024 / 1024 / 1024 AS SizeInGB
"@
	$sourceMaxSizeTEMP = Invoke-Sqlcmd @source_sqlParams
    if($sourceMaxSizeTEMP -eq $null)
    {
        Write-Log -IsError "Cannot retrieve the MaxSize for source database: $Source_DatabaseName"
    }

    $sourceMaxSizeBytes = $sourceMaxSizeTEMP.SizeInBytes
	$sourceMaxSizeMB = $sourceMaxSizeTEMP.SizeInMB
    $sourceMaxSizeGB = $sourceMaxSizeTEMP.SizeInGB
    If($sourceMaxSizeMB -in ('100', '250', '500'))
    {
        $sourceMaxSize = [string]$sourceMaxSizeMB + " MB"
    }
    else
    {
        $sourceMaxSize = [string]$sourceMaxSizeGB + " GB"
    }
    
    Write-Log "Source MaxSize is: $sourceMaxSize"

    # Source physical file size
    $source_sqlParams.Query = @"
	SELECT SUM(CAST(FILEPROPERTY(name, 'SpaceUsed') AS bigint) * 8192.) 
    FROM sys.database_files
    WHERE type_desc = 'ROWS';
"@
	$sourcePhysicalFileSize = (Invoke-Sqlcmd @source_sqlParams).Column1
    Write-Log "Source physical file size (in bytes) is: $sourcePhysicalFileSize"

	##### Get Target SLO, edition and Maxsize #####################################################
    # SLO
	$target_sqlParams.Database = $target_DatabaseName
	$target_sqlParams.Query = @"
	SELECT DATABASEPROPERTYEX('$target_DatabaseName', 'ServiceObjective')
"@
	$targetServicelevel = (Invoke-Sqlcmd @target_sqlParams).Column1    

    if([string]::IsNullOrEmpty($targetServicelevel))
    {
		$targetServicelevel = 'P2'
        Write-Log "Target Service level was not found. Setting it to default value: $targetServicelevel"
    }
    Write-Log "Target service level is: $targetServicelevel"

    #Edition
    $target_sqlParams.Query = @"
	SELECT DATABASEPROPERTYEX('$target_DatabaseName', 'Edition')
"@
	$targetEdition = (Invoke-Sqlcmd @target_sqlParams).Column1
    if([string]::IsNullOrEmpty($targetEdition))
    {
		$targetEdition = 'Premium'
        Write-Log "Target database edition was not found. Setting it to default value: $targetEdition"
    }
    Write-Log "Target Edition is: $targetEdition"

    #MaxSizeBytes
	$target_sqlParams.Query = @"
	SELECT DATABASEPROPERTYEX('$target_DatabaseName', 'MaxSizeInBytes') AS SizeInBytes,
           SUM(CAST(DATABASEPROPERTYEX('$target_DatabaseName', 'MaxSizeInBytes') AS bigint)) / 1024 / 1024 AS SizeInMB,
           SUM(CAST(DATABASEPROPERTYEX('$target_DatabaseName', 'MaxSizeInBytes') AS bigint)) / 1024 / 1024 / 1024 AS SizeInGB
"@
    $targetMaxSizeTEMP = Invoke-Sqlcmd @target_sqlParams
    if($targetMaxSizeTEMP -eq $null)
    {
		If($targetServicelevel -in ('S0', 'S1', 'S2'))
		{
			$targetMaxSize = "250 GB"
			$targetMaxSizeBytes = "268435456000"			
		}
		else
		{
			$targetMaxSize = "500 GB"
			$targetMaxSizeBytes = "536870912000"
		}
        Write-Log "MaxSize for target database was not found. Setting it to default value: $targetMaxSize or $targetMaxSizeBytes bytes."
    }
    else
        {
        $targetMaxSizeBytes = $targetMaxSizeTemp.SizeInBytes
	    $targetMaxSizeMB = $targetMaxSizeTemp.SizeInMB
        $targetMaxSizeGB = $targetMaxSizeTemp.SizeInGB
        If($targetMaxSizeMB -in ('100', '250', '500'))
        {
            $targetMaxSize = [string]$targetMaxSizeMB + " MB"
        }
        else
        {
            $targetMaxSize = [string]$targetMaxSizeGB + " GB"
        }
    }
    Write-Log "Target MaxSize is: $targetMaxSize"

    ##### If it is MR database then set the target DB to P2\500GB\Premium if source is in Premium edition and target in standard edition #############################
    if($dbname -like "MR" -and ($sourceEdition -eq $premiumEdition -and $targetEdition -eq $standardEdition))
    {
        $targetServicelevel = 'P2'
        $targetEdition = $premiumEdition
        $targetMaxSize = "500 GB"
        Write-Log "Source MRDB is in Premium Edition and Target in Standard. Upgrading target service level. Creating copy with service level: $targetServicelevel"  
    }

    ##### Pre-condition check to see if copy is possible. 
    ##### Fail if actual source db size is greater than MaxSize of target db
    Write-Log "Comparing source physical file size: $sourcePhysicalFileSize and target Max size:$targetMaxSizeBytes "
    If([bigint]$sourcePhysicalFileSize -gt [bigint]$targetMaxSizeBytes)
    {
        Write-Log -IsError "Actual size of source database is greater than maximum size allowed for target database. This scenario is not supported. Canceling refresh."
    }
    Write-Log "Verified that acutal size of source database is within maximum size allowed for target database."

    ##### Find the level value to intitate copy with #####################################################################################################################

    # If both source and target are in Standard edition 
    if($sourceEdition -eq $standardEdition -and $targetEdition -eq $standardEdition)
    {
        $toNumberSourceServicelevel = $sourceServicelevel.Substring(1)
        $toNumberTargetServicelevel = $targetServicelevel.Substring(1)
        If([int]$toNumberSourceServicelevel -gt [int]$toNumberTargetServicelevel)  
        {
            $copylevel = $sourceServicelevel
            $isLevelChanged = $true
        }
        else
        {
            $copylevel = $targetServicelevel
        }
    }
    #If source is in Premium edition and target either standard or premium
    elseif($sourceEdition -eq $premiumEdition)
    {
        if($targetEdition -eq $standardEdition)
        {
            $copylevel = $sourceServicelevel
            $isLevelChanged = $true
            If($sourceMaxSize -like "4096 GB")
            {
                $isAdjustMaxSize = $true
            }
        }
        elseif($sourceServicelevel -in ('P11','P15') -and $sourceMaxSize -eq "4096 GB")  
        {
            If($targetServicelevel -notin ('P11','P15'))
            {
                $copylevel = $sourceServicelevel
                $isLevelChanged = $true
                $isAdjustMaxSize = $true
            }
            else 
            {
                $copylevel = $targetServicelevel
                if($targetMaxSize -ne "4096 GB")
                {
                    $isAdjustMaxSize = $true
                }
            }
        }
        else
        {
            $copylevel = $targetServicelevel             
        }
    }
    # Target is in premium but source on standard tier, then copy at highest standard tier.
    else
    {
        $copylevel = 'S12'
        $isLevelChanged = $true
    }
    Write-Log "Target database copy will be created at level: $copylevel"
    If($isLevelChanged)
    {
        Write-Log "Copy level($copylevel) is different from the original target level($targetServicelevel). This will be adjust post copy."
    }
    If($isAdjustMaxSize)
    {
        Write-Log "Copy is being performed at $copylevel level and will need maxsize adjustment. Maxsize adjustment will also be performed post copy."
    }
    
	##########################################
	###   Get target database properties   ###
	##########################################

	# Get target compatibility level
	Write-Log "Getting target db compatibility level."
	$target_sqlParams.Database = 'master'
	$target_sqlParams.Query = "select compatibility_level from sys.databases where name = '$($target_DatabaseName)'"
	$compatResult = Invoke-Sqlcmd @target_sqlParams

	# Get scoped configuration from original DB
	Write-Log "Getting scoped configuration from target db."
	$target_sqlParams.Database = "$($target_DatabaseName)"
	$target_sqlparams.Query = "SELECT * from sys.database_scoped_configurations"
	$origConfigs = Invoke-Sqlcmd @target_sqlParams
	
	###########################################
	### Rename target database i.e. backup ###
	###########################################

	Write-Log "Renaming the target database for backup to: $standardTargetDbBackupName"

	$target_sqlParams.Database = 'master'
	$target_sqlParams.Query = @"
	IF NOT EXISTS (SELECT 'x' FROM SYS.DATABASES WHERE NAME = '$standardTargetDbBackupName')
	BEGIN
		ALTER DATABASE [$target_DatabaseName] MODIFY NAME = [$standardTargetDbBackupName]
	END
"@
	Invoke-Sqlcmd @target_sqlParams
	Write-Log "Finished renaming original target database."
	
	############################################
	### Copy databases from source to target ###
	############################################

	Write-Log "Initiating database copy operation."
    
    $RetryIntervalInSeconds = 30
    $NumberOfRetryAttempts = 2 
    $cmdOk = $FALSE

      do
    {
        try
        {
            $target_sqlParams.Database = 'master'
	        $target_sqlParams.UserName = $upgrade_SqlUser
	        $target_sqlParams.Password = $upgrade_Password
	        $target_sqlParams.Query = "CREATE DATABASE [$($target_DatabaseName)] as copy of [$($source_sqlParams.ServerInstance.Split('.')[0])].[$($source_DatabaseName)] (SERVICE_OBJECTIVE = '$copylevel')"

	        Write-Log "About to run query: $($target_sqlParams.Query)"
            Invoke-Sqlcmd @target_sqlParams -ErrorAction Continue -OutputSqlErrors $True -Verbose 
            $cmdOk = $TRUE

        }
        catch
        {
            Write-Log "Exception Caught..."  
            $ErrorMessage = $_.Exception.Message
            Write-Log "Error Occurred: Message: $ErrorMessage"
        }
        finally
        {
           # Validate that we have the copied database
	       # This step is required because CREATE DATABASE
	       # will give an error even when successful.
           $target_sqlParams.QueryTimeout = 0
	       $target_sqlParams.Query = "SELECT COUNT(*) FROM sys.databases WHERE name in ('$target_DatabaseName')"
           Write-Log "Query FROM sys.databases to check if database copy operation started."

	        # Wait a few seconds before checking
	        Start-Sleep -Seconds 60
	        $result = Invoke-SqlCmd @target_sqlParams

	        if (($result -eq $null) -bor ($result[0] -eq 0))
	        {
#		        throw 'Database copy failed, no record in sys.Databases was found for this copy operation.'
                Write-Log "No record found in sys.databases. Retry the flow."
                Write-Log "Sleeping for $RetryIntervalInSeconds seconds before retrying. Retry attempts left: $NumberOfRetryAttempts"
                $cmdOk = $False
                $NumberOfRetryAttempts = $NumberOfRetryAttempts - 1   
                Start-Sleep -Seconds $RetryIntervalInSeconds
	        }
            else
            {
                Write-Log "record found in sys.databases. Continue the flow."
                $cmdOk = $TRUE
            }
        }
    }while (-not $cmdOk -and $NumberOfRetryAttempts -ge 0)

	Write-Log "Waiting..."

	# Wait until copied database is available

	$target_sqlParams.Database = 'master'
	$target_sqlParams.UserName = $target_UserId
	$target_sqlParams.Password = $target_Password
	$target_sqlParams.Query = "SELECT state, name FROM sys.databases WHERE name in ('$target_DatabaseName') and state != 0"
	$result = Invoke-SqlCmd @target_sqlParams
	while ($result -ne $null)
	{
		$result
		'Waiting 30 seconds for database copy to complete.'
		Start-Sleep -Seconds 30
		$result = Invoke-Sqlcmd @target_sqlParams
	}

	Write-Log "Database copy completed $(Get-Date), now starting post copy operations."

	##################################################
	###       Set properties on new database       ###
	##################################################

	Write-Log "Setting Compatibility level on newly copied database."
	$target_sqlParams.Database = 'master'
	$target_sqlParams.Query = "ALTER DATABASE [$target_DatabaseName] SET COMPATIBILITY_LEVEL = $($compatResult.compatibility_level)"

	Invoke-Sqlcmd @target_sqlParams
	
	##################################################
	### Copy scoped configuration from original DB ###
	##################################################

	Write-Log "Copying scoped configuration to new database."

	# Expression to format value.
	$normalizeValue = @'
		if ($origConfigValue -is [System.DBNull])
		{
			return "PRIMARY"
		}
		
		if ($origConfigValue -is [System.Boolean])
		{
			if ($origConfigValue) { return 'ON' } else { return 'OFF' }
		}

		if ($origConfigValue -is [System.Int32])
		{
			return $origConfigValue
		}

        if ($origConfigValue -like "OFF*")
        {
            return "OFF"
        }

        if ($origConfigValue -like "ON*")
        {
            return "ON"
        }
        
		return "'$origConfigValue'"
'@

	# Set scoped configuration from original DB
	if ($origConfigs -ne $null)
	{
		# Iterate and copy values to target DB.
		$target_sqlParams.Database = "$target_DatabaseName"
		foreach($origConfig in $origConfigs)
		{
			$origConfigValue = $origConfig.value
			$normalizedConfigValue = Invoke-Expression $normalizeValue
			$target_sqlParams.Query = "ALTER DATABASE SCOPED CONFIGURATION SET $($origConfig.name) = $normalizedConfigValue"
			Invoke-Sqlcmd @target_sqlParams

			$origConfigValue = $origConfig.value_for_secondary
			$normalizedConfigValue = Invoke-Expression $normalizeValue
			$target_sqlParams.Query = "ALTER DATABASE SCOPED CONFIGURATION FOR SECONDARY SET $($origConfig.name) = $normalizedConfigValue"
			Invoke-Sqlcmd @target_sqlParams -ErrorAction SilentlyContinue
		}
	}
	Write-Log "Copying scoped configuration completed."

    if($isAdjustMaxSize)
    {
        Write-Log "Copy was created at 4TB MaxSize. Reducing MaxSize to to original target Maxsize before resetting service objective to original level."
  
        # downgrade Max size to original
        $target_sqlParams.Database = 'master'
	    $target_sqlParams.UserName = $target_UserId
	    $target_sqlParams.Password = $target_Password
	    ModifyDatabaseLevel $target_sqlParams $target_DatabaseName $premiumEdition $copylevel $targetMaxSize
 
            If($isLevelChanged)
            {
		        Write-Log "Completed resetting the service level to temporary values. Now performing final reset."
            }
            else
            {
                Write-Log "Completed Reset of SERVICE_OBJECTIVE level on copied database."
            }
    }

    if($isLevelChanged)
    {    
        # Reset to correct service level 
	    Write-Log "Resetting to final service level: $targetServicelevel"

	    $target_sqlParams.Database = 'master'
	    $target_sqlParams.UserName = $target_UserId
	    $target_sqlParams.Password = $target_Password
	    ModifyDatabaseLevel $target_sqlParams $target_DatabaseName $targetEdition $targetServicelevel $targetMaxSize
        Write-Log "Completed Reset of SERVICE_OBJECTIVE level on copied database."
    }

    Create-Sql-Users $target_ServerName $target_DatabaseName $target_UserId $target_Password  $sqlUserJsonData

	##################################################
	### Run post-restore SQL script for AXDB (only)###
	##################################################
	if($dbName -like "AX")
	{
		Write-Log "Starting Post-restore SQL script execution." 

		$postRestoreStatement = @"
		--Tidy up the batch server config from the previous environment
		DELETE FROM SYSSERVERCONFIG

		--Tidy up server sessions from the previous environment.
		DELETE FROM SYSSERVERSESSIONS

		--Tidy up printers from the previous environment
		DELETE FROM SYSCORPNETPRINTERS

		--Tidy up client sessions from the previous environment.
		DELETE FROM SYSCLIENTSESSIONS

		--Tidy up batch sessions from the previous environment.
		DELETE FROM BATCHSERVERCONFIG

		--Remove the SMTP server configuration to prevent sandbox from sending mails
		UPDATE SysEmailParameters
		SET SMTPRELAYSERVERNAME = '', MAILERNONINTERACTIVE = 'SMTP'
		GO

		--Set any waiting, executing, ready or canceling batches to withhold
		UPDATE BatchJob
		SET STATUS = 0
		WHERE STATUS  IN (1,2,5,7)
		GO

		--disable all users except Admin (Admin user should go and re-enable as they see fit)
		UPDATE UserInfo
		SET ENABLE = 0
		WHERE ID <> 'Admin' AND ID <> 'axrunner' AND ID <> 'FRServiceUser' AND ID <> 'RetailServiceAccount'
		GO

		--Blank out all email addresses - in the case someone adds back SMTP config this will prevent accidentally sending mails
		UPDATE LogisticsElectronicAddress
		SET LOCATOR = '' 
		WHERE Locator LIKE '%@%'
		GO

		--Remove all print management settings - there is email addresses stored in a container field here - again we want to prevent accidentally sending a vendor/customer a PO/SO email.
		DELETE FROM PrintMgmtSettings 
		DELETE FROM PrintMgmtDocInstance 

		--Remove all attachment references as storage account is not copied. Approved by Tariq Bell.
		UPDATE t1
		SET t1.storageproviderid = 0
			   , t1.accessinformation = ''
			   , t1.modifiedby = 'NonProdRestore'
			   , t1.modifieddatetime = getdate()
		FROM docuvalue t1 
		WHERE t1.storageproviderid = 1

		-- RETAILTRANSACTIONSERVICEPROFILE
		DECLARE @MIGRATIONVALUE NVARCHAR(50)
		SET @MIGRATIONVALUE = N'https://MIGRATION_VALUE'

		IF EXISTS(SELECT 1 FROM INFORMATION_SCHEMA.COLUMNS 
			WHERE TABLE_NAME = 'RETAILTRANSACTIONSERVICEPROFILE' 
			AND COLUMN_NAME = 'AzureResource')
		BEGIN
			EXECUTE ('UPDATE dbo.[RETAILTRANSACTIONSERVICEPROFILE] SET ServiceHostUrl = ''' + @MIGRATIONVALUE + ''' , AzureResource = ''' + @MIGRATIONVALUE + ''' ')
		END
		ELSE
		BEGIN
			EXECUTE ('UPDATE dbo.[RETAILTRANSACTIONSERVICEPROFILE] SET ServiceHostUrl = ''' + @MIGRATIONVALUE + '''  ')
		END

		-- RETAILCHANNELPROFILEPROPERTY
		UPDATE 
			dbo.[RETAILCHANNELPROFILEPROPERTY]
		SET 
			[VALUE] = N'https://MIGRATION_VALUE'
		WHERE
			[VALUE] LIKE '%dynamics.com'


		UPDATE 
			dbo.[RETAILCHANNELPROFILEPROPERTY]
		SET 
			[VALUE] = N'https://MIGRATION_VALUE/Commerce'
		WHERE
			[VALUE] LIKE '%dynamics.com/Commerce'


		UPDATE 
			dbo.[RETAILCHANNELPROFILEPROPERTY]
		SET 
			[VALUE] = N'https://MIGRATION_VALUE/MediaServer'
		WHERE
			[VALUE] LIKE '%dynamics.com/MediaServer'


		-- RETAILCONNDATABASEPROFILE (all rows)
		UPDATE
			dbo.[RETAILCONNDATABASEPROFILE]
		SET
			[CONNECTIONSTRING] = NULL

        -- RETAILIDENTITYPROVIDER 
        UPDATE
            dbo.[RETAILIDENTITYPROVIDER]
        SET
            [ISSUER] = N'https://sts.windows-ppe.net/MIGRATION_VALUE_' + SUBSTRING(CONVERT(nvarchar(50), NEWID()), 1, 8) + '/'
        WHERE
            [NAME] = N'Azure AD'

        UPDATE
            dbo.[RETAILIDENTITYPROVIDER]
        SET
            [ISSUER] = N'https://MIGRATION_VALUE_' + SUBSTRING(CONVERT(nvarchar(50), NEWID()), 1, 8) + '/auth'
        WHERE
            [NAME] = N'Commerce Identity Provider'

		UPDATE 
			dbo.[RETAILHARDWAREPROFILE]
		SET
			[SECUREMERCHANTPROPERTIES] = NULL

"@
		$target_sqlParams.Database = $target_DatabaseName
		$target_sqlParams.Query = $postRestoreStatement
		Invoke-Sqlcmd @target_sqlParams
	}
	
	#######################################################
	###              Fix Admin user                    ####
	#######################################################
	
if($dbName -like "AX")
{
	#Webroot path
    $ServiceDriveWebRootPath = "$env:SERVICEDRIVE\AosService\Webroot"
    Write-Log "The Service drive path of the webroot on the aos machine is : $ServiceDriveWebRootPath"  

    # Reading web config values required for running the SQL script
    [xml]$xml = get-content $ServiceDriveWebRootPath\web.config   
    $TenandId = $xml.SelectSingleNode('//add[@key="Aad.AADTenantId"]').Value
    $AdminPrincipalName = $xml.SelectSingleNode('//add[@key="Provisioning.AdminPrincipalName"]').Value
    $AdminIdentityProvider = $xml.SelectSingleNode('//add[@key="Provisioning.AdminIdentityProvider"]').Value

    if ($AdminPrincipalName -eq $null)
    {
        Write-Log "Admin principal name in web.config is null so stop automatic check for admin. Please check admin account in DB manually and update the web.config for admin principal name."
    }
    else
    {
        if ($AdminIdentityProvider -eq $null)
        {
            $AdminIdentityProvider = 'https://sts.windows.net/'
        }

        $target_sqlParams.Database = $target_DatabaseName

        $target_sqlParams.Query = @"
        SELECT COUNT(*) As Ct FROM USERINFO WHERE ID = 'Admin'
"@
        $count = Invoke-Sqlcmd @target_sqlParams
        Write-Log "Number of admin users are $($count.Ct)"

        # Validate if ADMIN account is unique.
        if($count.Ct -gt 1)
        {
            Write-Log "Multiple admin records found. Removing duplicates."
            $target_sqlParams.Query = @"
            DECLARE @expectedCnt int = 0,
            @adminPrincipalName varchar(100) = '$AdminPrincipalName'
	            SELECT @expectedCnt = COUNT(*) FROM USERINFO WHERE ID = 'Admin' and NETWORKALIAS = @adminPrincipalName;
		
				        IF @expectedCnt >= 1 
				        BEGIN
					        DELETE USERINFO WHERE ID = 'Admin' and NETWORKALIAS != @adminPrincipalName;
					        IF @expectedCnt > 1 
					        BEGIN
						        DELETE TOP(@expectedCnt - 1) USERINFO WHERE ID = 'Admin'
					        END;
				        END;

				        ELSE
				        BEGIN
					        DELETE TOP($($count.Ct) - 1) USERINFO WHERE ID = 'Admin'
				        END;
"@
            Invoke-Sqlcmd @target_sqlParams | out-null
            Write-Log "Removed the duplicate Admin records."
        }
        else
        {
            Write-Log "No duplicate Admin records found in USERINFO table."
        }

        $target_sqlParams.Query = @"
        SELECT COUNT(*) As Ct FROM USERINFO WHERE ID = 'Admin'
"@
        $currentCount = Invoke-Sqlcmd @target_sqlParams
        Write-Log "Number of current admin users are $($currentCount.Ct)"

        # Validate if ADMIN account exists.
        if($currentCount.Ct -eq 0)
        {
            Write-Log "USERINFO has empty Admin account. Need to create Admin account."
            $target_sqlParams.Query = @"
            DECLARE 
            @expectedAdminSID varchar(1000) = '',
            @adminIdentityProviderDef varchar(100) = '$AdminIdentityProvider',
            @adminPrincipalName varchar(100) = '$AdminPrincipalName'
            IF @expectedAdminSID = '' or @expectedAdminSID = NULL
	            BEGIN
		            SET @expectedAdminSID = '$expectedAdminSID'
		        END;
	
	        BEGIN
	                INSERT INTO USERINFO (ID, NAME, ENABLE, STATUSLINEINFO, TOOLBARINFO, DEBUGINFO, AUTOINFO, AUTOUPDATE, GARBAGECOLLECTLIMIT, HISTORYLIMIT, MESSAGELIMIT, GENERALINFO, SHOWSTATUSLINE, SHOWTOOLBAR, SHOWAOTLAYER, CONFIRMDELETE, REPORTFONTSIZE, FORMFONTSIZE, PROPERTYFONTSIZE, COMPANY, COMPILERWARNINGLEVEL, SID, NETWORKDOMAIN, NETWORKALIAS, LANGUAGE, HELPLANGUAGE, PREFERREDTIMEZONE, NOTIFYTIMEZONEMISMATCH, ACCOUNTTYPE, DEFAULTPARTITION, IDENTITYPROVIDER, INTERACTIVELOGON)  
			        VALUES ('Admin', 'Admin', 1, -538365, -1, 12, -1, 6, 20, 5, 1000, -8209, 1, 1, 4, -1, 9, 9, 9, 'DAT', 3, @expectedAdminSID, @adminIdentityProviderDef, @adminPrincipalName, 'en-US', 'en-us', 58, 1, 2, 1, @adminIdentityProviderDef, 1)
	        END;
"@
            Invoke-Sqlcmd @target_sqlParams | out-null
            Write-Log "Added a new admin record to USERINFO table."
        }
        else
        {
            Write-Log "Validated that Admin account exists."
        }

        $target_sqlParams.Query = @"
        SELECT	ENABLE,
		        NETWORKALIAS,
		        IDENTITYPROVIDER,
		        NETWORKDOMAIN,
		        SID 
        FROM USERINFO WHERE ID = 'Admin'
"@
        $results = Invoke-Sqlcmd @target_sqlParams

        #Validate if Admin is enabled
        If($results.ENABLE -ne 1)
        {
            Write-Log "Admin account is disabled. Enabling Admin account."
            $target_sqlParams.Query = @"
	        UPDATE USERINFO set ENABLE = 1 WHERE ID = 'Admin'
"@
            Invoke-Sqlcmd @target_sqlParams | Out-Null
            Write-Log "Finished enabling ADMIN account."
        }
        else
        {
            Write-Log "Validated that admin account is enabled."    
        }

        # Validate if SID is correct.
	    Write-Log "Loading the  Microsoft.Dynamics.AX.Security.SidGenerator.dll file to generate SID."
        $expectedAdminSID = $null

        $dllPath = Join-Path $ServiceDriveWebRootPath '\bin\Microsoft.Dynamics.AX.Security.SidGenerator.dll'
        if (Test-Path $dllPath)
        {
		    [Reflection.Assembly]::LoadFile($dllPath)
        	$expectedAdminSID = [Microsoft.Dynamics.Ax.Security.SidGenerator]::Generate($AdminPrincipalName, $AdminIdentityProvider)
        }

        if ($expectedAdminSID -eq $null)
        {
            Write-Log "Expected admin SID is null so no check for admin SID."
        }
        else
        {
            Write-Log "Value retrieved for Expected Admin SID: $($expectedAdminSID)"

            if($results.SID -ne $expectedAdminSID)
            {   
                Write-Log "SID is not valid, current SID: $($results.SID)"
                $target_sqlParams.Query = @"
                DECLARE @expectedAdminSID varchar(1000) = ''
                SET @expectedAdminSID = '$expectedAdminSID'	
                UPDATE USERINFO set SID = @expectedAdminSID WHERE ID = 'Admin'
"@
                Invoke-Sqlcmd @target_sqlParams | Out-Null
	            Write-Log "Finsihed updating the SID."				
            }
            else
            {
                Write-Log "SID is valid."
            }

            # Validate if admin is the same provisioning admin and has the same domain with the tenant
            if (($TenandId -ne $null) -and ($results.NETWORKALIAS -ne $null) -and ((($results.NETWORKALIAS).SubString($results.NETWORKALIAS.IndexOf('@')+1)).ToUpper() -ne $TenandId.ToUpper()))
            {
                Write-Log "Admin in USERINFO has the different domain with the tenant."
            }

            if($results.NETWORKALIAS -ne  $AdminPrincipalName)
            {
                Write-Log "Admin network alias in USERINFO is different with default provisioning admin principal name. Updating admin network alias in USERINFO."

                $target_sqlParams.Query = @"
                DECLARE @adminPrincipalName varchar(100) = '$AdminPrincipalName'
                UPDATE USERINFO set NETWORKALIAS = @adminPrincipalName WHERE ID = 'Admin'
"@
                Invoke-Sqlcmd @target_sqlParams | Out-Null
                Write-Log "Updated admin email in USERINFO."
            }
            else
            {
                Write-Log "Validated that admin network alias is the same with the admin principal name in the config."
            }

            # Validate if Admin identity provider is correct
            If ($AdminIdentityProvider.ToUpper() -ne $results.IDENTITYPROVIDER.ToUpper())
            {
                Write-Log "Admin identity provider in USERINFO is different with default provisioning admin identity provider"
                $target_sqlParams.Query = @"
                DECLARE @adminIdentityProviderDef varchar(100) = '$AdminIdentityProvider'
                UPDATE USERINFO set IDENTITYPROVIDER = @adminIdentityProviderDef WHERE ID = 'Admin'
"@
                Invoke-Sqlcmd @target_sqlParams | Out-Null
                Write-Log "Updated admin identity provider in USERINFO."
            }
            else
            {
                Write-Log "Admin has correct identity provider in USERINFO."
            }

            # Validate if Admin network domain is correct
            If ($results.NETWORKDOMAIN -ne $AdminIdentityProvider.ToUpper())
            {
                Write-Log "Admin network domain in USERINFO is different with default provisioning admin identity provider"
                $target_sqlParams.Query = @"
                DECLARE @adminIdentityProviderDef varchar(100) = '$AdminIdentityProvider'
                UPDATE USERINFO set NETWORKDOMAIN = @adminIdentityProviderDef WHERE ID = 'Admin'
"@
                Write-Log "Updated admin network domain in USERINFO."
                Invoke-Sqlcmd @target_sqlParams | Out-Null
            }
            else
            {
                Write-Log "Admin network domain is correct."
            }
        }
    }
}

	#######################################################
	###              Remove Copy Users                 ####
	#######################################################

	Write-Log "Removing copy user in source sql server"

	$source_sqlParams.Database = $source_DatabaseName
	RemoveUserFromRole $source_sqlParams $upgrade_SqlUser 'db_owner'
	RemoveUserForLogin $source_sqlParams $upgrade_SqlUser

	$source_sqlParams.Database = 'master'
	RemoveUserFromRole $source_sqlParams $upgrade_SqlUser 'dbmanager'
	RemoveUserForLogin $source_sqlParams $upgrade_SqlUser
	RemoveLogin $source_sqlParams $upgrade_SqlUser


	Write-Log "Removing copy user in target sql server"

	$target_sqlParams.Database = $target_DatabaseName
	RemoveUserFromRole $target_sqlParams $upgrade_SqlUser 'db_owner'
	RemoveUserForLogin $target_sqlParams $upgrade_SqlUser

	$target_sqlParams.Database = 'master'
	RemoveUserFromRole $target_sqlParams $upgrade_SqlUser 'dbmanager'
	RemoveUserForLogin $target_sqlParams $upgrade_SqlUser
	RemoveLogin $target_sqlParams $upgrade_SqlUser

	#######################################################
	###              Copy Completed                    ####
	#######################################################

	Write-Log "Database restore completed successfully." 
# SIG # Begin signature block
# MIIjnwYJKoZIhvcNAQcCoIIjkDCCI4wCAQExDzANBglghkgBZQMEAgEFADB5Bgor
# BgEEAYI3AgEEoGswaTA0BgorBgEEAYI3AgEeMCYCAwEAAAQQH8w7YFlLCE63JNLG
# KX7zUQIBAAIBAAIBAAIBAAIBADAxMA0GCWCGSAFlAwQCAQUABCAAKXpsW/0lL3yo
# viyQMv8xJA00Qt8jKu3Ib+Cwhx0ZaKCCDYEwggX/MIID56ADAgECAhMzAAABUZ6N
# j0Bxow5BAAAAAAFRMA0GCSqGSIb3DQEBCwUAMH4xCzAJBgNVBAYTAlVTMRMwEQYD
# VQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNy
# b3NvZnQgQ29ycG9yYXRpb24xKDAmBgNVBAMTH01pY3Jvc29mdCBDb2RlIFNpZ25p
# bmcgUENBIDIwMTEwHhcNMTkwNTAyMjEzNzQ2WhcNMjAwNTAyMjEzNzQ2WjB0MQsw
# CQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9u
# ZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMR4wHAYDVQQDExVNaWNy
# b3NvZnQgQ29ycG9yYXRpb24wggEiMA0GCSqGSIb3DQEBAQUAA4IBDwAwggEKAoIB
# AQCVWsaGaUcdNB7xVcNmdfZiVBhYFGcn8KMqxgNIvOZWNH9JYQLuhHhmJ5RWISy1
# oey3zTuxqLbkHAdmbeU8NFMo49Pv71MgIS9IG/EtqwOH7upan+lIq6NOcw5fO6Os
# +12R0Q28MzGn+3y7F2mKDnopVu0sEufy453gxz16M8bAw4+QXuv7+fR9WzRJ2CpU
# 62wQKYiFQMfew6Vh5fuPoXloN3k6+Qlz7zgcT4YRmxzx7jMVpP/uvK6sZcBxQ3Wg
# B/WkyXHgxaY19IAzLq2QiPiX2YryiR5EsYBq35BP7U15DlZtpSs2wIYTkkDBxhPJ
# IDJgowZu5GyhHdqrst3OjkSRAgMBAAGjggF+MIIBejAfBgNVHSUEGDAWBgorBgEE
# AYI3TAgBBggrBgEFBQcDAzAdBgNVHQ4EFgQUV4Iarkq57esagu6FUBb270Zijc8w
# UAYDVR0RBEkwR6RFMEMxKTAnBgNVBAsTIE1pY3Jvc29mdCBPcGVyYXRpb25zIFB1
# ZXJ0byBSaWNvMRYwFAYDVQQFEw0yMzAwMTIrNDU0MTM1MB8GA1UdIwQYMBaAFEhu
# ZOVQBdOCqhc3NyK1bajKdQKVMFQGA1UdHwRNMEswSaBHoEWGQ2h0dHA6Ly93d3cu
# bWljcm9zb2Z0LmNvbS9wa2lvcHMvY3JsL01pY0NvZFNpZ1BDQTIwMTFfMjAxMS0w
# Ny0wOC5jcmwwYQYIKwYBBQUHAQEEVTBTMFEGCCsGAQUFBzAChkVodHRwOi8vd3d3
# Lm1pY3Jvc29mdC5jb20vcGtpb3BzL2NlcnRzL01pY0NvZFNpZ1BDQTIwMTFfMjAx
# MS0wNy0wOC5jcnQwDAYDVR0TAQH/BAIwADANBgkqhkiG9w0BAQsFAAOCAgEAWg+A
# rS4Anq7KrogslIQnoMHSXUPr/RqOIhJX+32ObuY3MFvdlRElbSsSJxrRy/OCCZdS
# se+f2AqQ+F/2aYwBDmUQbeMB8n0pYLZnOPifqe78RBH2fVZsvXxyfizbHubWWoUf
# NW/FJlZlLXwJmF3BoL8E2p09K3hagwz/otcKtQ1+Q4+DaOYXWleqJrJUsnHs9UiL
# crVF0leL/Q1V5bshob2OTlZq0qzSdrMDLWdhyrUOxnZ+ojZ7UdTY4VnCuogbZ9Zs
# 9syJbg7ZUS9SVgYkowRsWv5jV4lbqTD+tG4FzhOwcRQwdb6A8zp2Nnd+s7VdCuYF
# sGgI41ucD8oxVfcAMjF9YX5N2s4mltkqnUe3/htVrnxKKDAwSYliaux2L7gKw+bD
# 1kEZ/5ozLRnJ3jjDkomTrPctokY/KaZ1qub0NUnmOKH+3xUK/plWJK8BOQYuU7gK
# YH7Yy9WSKNlP7pKj6i417+3Na/frInjnBkKRCJ/eYTvBH+s5guezpfQWtU4bNo/j
# 8Qw2vpTQ9w7flhH78Rmwd319+YTmhv7TcxDbWlyteaj4RK2wk3pY1oSz2JPE5PNu
# Nmd9Gmf6oePZgy7Ii9JLLq8SnULV7b+IP0UXRY9q+GdRjM2AEX6msZvvPCIoG0aY
# HQu9wZsKEK2jqvWi8/xdeeeSI9FN6K1w4oVQM4Mwggd6MIIFYqADAgECAgphDpDS
# AAAAAAADMA0GCSqGSIb3DQEBCwUAMIGIMQswCQYDVQQGEwJVUzETMBEGA1UECBMK
# V2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0
# IENvcnBvcmF0aW9uMTIwMAYDVQQDEylNaWNyb3NvZnQgUm9vdCBDZXJ0aWZpY2F0
# ZSBBdXRob3JpdHkgMjAxMTAeFw0xMTA3MDgyMDU5MDlaFw0yNjA3MDgyMTA5MDla
# MH4xCzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdS
# ZWRtb25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xKDAmBgNVBAMT
# H01pY3Jvc29mdCBDb2RlIFNpZ25pbmcgUENBIDIwMTEwggIiMA0GCSqGSIb3DQEB
# AQUAA4ICDwAwggIKAoICAQCr8PpyEBwurdhuqoIQTTS68rZYIZ9CGypr6VpQqrgG
# OBoESbp/wwwe3TdrxhLYC/A4wpkGsMg51QEUMULTiQ15ZId+lGAkbK+eSZzpaF7S
# 35tTsgosw6/ZqSuuegmv15ZZymAaBelmdugyUiYSL+erCFDPs0S3XdjELgN1q2jz
# y23zOlyhFvRGuuA4ZKxuZDV4pqBjDy3TQJP4494HDdVceaVJKecNvqATd76UPe/7
# 4ytaEB9NViiienLgEjq3SV7Y7e1DkYPZe7J7hhvZPrGMXeiJT4Qa8qEvWeSQOy2u
# M1jFtz7+MtOzAz2xsq+SOH7SnYAs9U5WkSE1JcM5bmR/U7qcD60ZI4TL9LoDho33
# X/DQUr+MlIe8wCF0JV8YKLbMJyg4JZg5SjbPfLGSrhwjp6lm7GEfauEoSZ1fiOIl
# XdMhSz5SxLVXPyQD8NF6Wy/VI+NwXQ9RRnez+ADhvKwCgl/bwBWzvRvUVUvnOaEP
# 6SNJvBi4RHxF5MHDcnrgcuck379GmcXvwhxX24ON7E1JMKerjt/sW5+v/N2wZuLB
# l4F77dbtS+dJKacTKKanfWeA5opieF+yL4TXV5xcv3coKPHtbcMojyyPQDdPweGF
# RInECUzF1KVDL3SV9274eCBYLBNdYJWaPk8zhNqwiBfenk70lrC8RqBsmNLg1oiM
# CwIDAQABo4IB7TCCAekwEAYJKwYBBAGCNxUBBAMCAQAwHQYDVR0OBBYEFEhuZOVQ
# BdOCqhc3NyK1bajKdQKVMBkGCSsGAQQBgjcUAgQMHgoAUwB1AGIAQwBBMAsGA1Ud
# DwQEAwIBhjAPBgNVHRMBAf8EBTADAQH/MB8GA1UdIwQYMBaAFHItOgIxkEO5FAVO
# 4eqnxzHRI4k0MFoGA1UdHwRTMFEwT6BNoEuGSWh0dHA6Ly9jcmwubWljcm9zb2Z0
# LmNvbS9wa2kvY3JsL3Byb2R1Y3RzL01pY1Jvb0NlckF1dDIwMTFfMjAxMV8wM18y
# Mi5jcmwwXgYIKwYBBQUHAQEEUjBQME4GCCsGAQUFBzAChkJodHRwOi8vd3d3Lm1p
# Y3Jvc29mdC5jb20vcGtpL2NlcnRzL01pY1Jvb0NlckF1dDIwMTFfMjAxMV8wM18y
# Mi5jcnQwgZ8GA1UdIASBlzCBlDCBkQYJKwYBBAGCNy4DMIGDMD8GCCsGAQUFBwIB
# FjNodHRwOi8vd3d3Lm1pY3Jvc29mdC5jb20vcGtpb3BzL2RvY3MvcHJpbWFyeWNw
# cy5odG0wQAYIKwYBBQUHAgIwNB4yIB0ATABlAGcAYQBsAF8AcABvAGwAaQBjAHkA
# XwBzAHQAYQB0AGUAbQBlAG4AdAAuIB0wDQYJKoZIhvcNAQELBQADggIBAGfyhqWY
# 4FR5Gi7T2HRnIpsLlhHhY5KZQpZ90nkMkMFlXy4sPvjDctFtg/6+P+gKyju/R6mj
# 82nbY78iNaWXXWWEkH2LRlBV2AySfNIaSxzzPEKLUtCw/WvjPgcuKZvmPRul1LUd
# d5Q54ulkyUQ9eHoj8xN9ppB0g430yyYCRirCihC7pKkFDJvtaPpoLpWgKj8qa1hJ
# Yx8JaW5amJbkg/TAj/NGK978O9C9Ne9uJa7lryft0N3zDq+ZKJeYTQ49C/IIidYf
# wzIY4vDFLc5bnrRJOQrGCsLGra7lstnbFYhRRVg4MnEnGn+x9Cf43iw6IGmYslmJ
# aG5vp7d0w0AFBqYBKig+gj8TTWYLwLNN9eGPfxxvFX1Fp3blQCplo8NdUmKGwx1j
# NpeG39rz+PIWoZon4c2ll9DuXWNB41sHnIc+BncG0QaxdR8UvmFhtfDcxhsEvt9B
# xw4o7t5lL+yX9qFcltgA1qFGvVnzl6UJS0gQmYAf0AApxbGbpT9Fdx41xtKiop96
# eiL6SJUfq/tHI4D1nvi/a7dLl+LrdXga7Oo3mXkYS//WsyNodeav+vyL6wuA6mk7
# r/ww7QRMjt/fdW1jkT3RnVZOT7+AVyKheBEyIXrvQQqxP/uozKRdwaGIm1dxVk5I
# RcBCyZt2WwqASGv9eZ/BvW1taslScxMNelDNMYIVdDCCFXACAQEwgZUwfjELMAkG
# A1UEBhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQx
# HjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEoMCYGA1UEAxMfTWljcm9z
# b2Z0IENvZGUgU2lnbmluZyBQQ0EgMjAxMQITMwAAAVGejY9AcaMOQQAAAAABUTAN
# BglghkgBZQMEAgEFAKCByDAZBgkqhkiG9w0BCQMxDAYKKwYBBAGCNwIBBDAcBgor
# BgEEAYI3AgELMQ4wDAYKKwYBBAGCNwIBFTAvBgkqhkiG9w0BCQQxIgQgh7ccinM5
# QpY9bQkvvap3DXo+YpNpT2h1pBxMiCDccGAwXAYKKwYBBAGCNwIBDDFOMEygLoAs
# AFIAZQB0AGEAaQBsAE0AaQBuAG8AcgBVAHAAZwByAGEAZABlAC4AcABzADGhGoAY
# aHR0cDovL3d3dy5taWNyb3NvZnQuY29tMA0GCSqGSIb3DQEBAQUABIIBAHiCP/B1
# +Q+xZ31JyDuzmyHWpaIo8rFfW04SBNJ1RbF2QI425EQBXpGndQQ3q36JHfvp8RUq
# NWSi9Z8i9RCH2s0vWk7hxynEhhQ8iRYNkA+NvV4+01gksDwesyCHz6Q+uvUty4sp
# 5ErJzz90XLmrhTIfsSq7zRJJbXGQS0DN0aIOv6aMzF4rGEMAqn3a4hkrYgxyFxkp
# Ql6nu0xOUyreutwrFqqSq30En+sGCBJpoRJA6IIHLW7S7WKn1NvyCcfAIjfPjmDf
# lmtCwf4uvGA14/PyCCvxMFGRa/KQxcph97exju5dhaVknCRP3LPHUZmlNVk02puK
# vxIuMY5zML/UcpKhghLkMIIS4AYKKwYBBAGCNwMDATGCEtAwghLMBgkqhkiG9w0B
# BwKgghK9MIISuQIBAzEPMA0GCWCGSAFlAwQCAQUAMIIBUAYLKoZIhvcNAQkQAQSg
# ggE/BIIBOzCCATcCAQEGCisGAQQBhFkKAwEwMTANBglghkgBZQMEAgEFAAQgUEox
# i0W2Oo176DKDVEL7cMGBHa37gFb50QlIMSjNx+wCBl1gildCYhgSMjAxOTA4Mjcw
# NzIzMzYuNThaMASAAgH0oIHQpIHNMIHKMQswCQYDVQQGEwJVUzELMAkGA1UECBMC
# V0ExEDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3Jh
# dGlvbjEtMCsGA1UECxMkTWljcm9zb2Z0IElyZWxhbmQgT3BlcmF0aW9ucyBMaW1p
# dGVkMSYwJAYDVQQLEx1UaGFsZXMgVFNTIEVTTjo4RDQxLTRCRjctQjNCNzElMCMG
# A1UEAxMcTWljcm9zb2Z0IFRpbWUtU3RhbXAgc2VydmljZaCCDjwwggTxMIID2aAD
# AgECAhMzAAAA2aqWClHLm0vmAAAAAADZMA0GCSqGSIb3DQEBCwUAMHwxCzAJBgNV
# BAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4w
# HAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xJjAkBgNVBAMTHU1pY3Jvc29m
# dCBUaW1lLVN0YW1wIFBDQSAyMDEwMB4XDTE4MDgyMzIwMjY1MloXDTE5MTEyMzIw
# MjY1MlowgcoxCzAJBgNVBAYTAlVTMQswCQYDVQQIEwJXQTEQMA4GA1UEBxMHUmVk
# bW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMS0wKwYDVQQLEyRN
# aWNyb3NvZnQgSXJlbGFuZCBPcGVyYXRpb25zIExpbWl0ZWQxJjAkBgNVBAsTHVRo
# YWxlcyBUU1MgRVNOOjhENDEtNEJGNy1CM0I3MSUwIwYDVQQDExxNaWNyb3NvZnQg
# VGltZS1TdGFtcCBzZXJ2aWNlMIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKC
# AQEAri6L0qOzc9ejG5LAsST1gZ8Ci8hU6n3tKzY/9im1DB3gtkgNNfWS6vzk9shx
# 71bw7/ACaNT6n28qJpeTLvhZ8u2HuVfO0fPkQd5OpsYEg6p7n7N8NhECpWU/hxHr
# 8aspFIDFSIqstIriZB+XVsJMoQ9OhNMrf0HijU+orHd70OtbjfOtwpycRnQhwQ7U
# Vem6GDIdxaZBjTYppNxhDFd11L6nlFs+CaThCw95C+GItT0Zo0kWdeimzOVfAoOU
# 2+K+zG/HxuBUJeSIza6EIOeDYKbg+KPb6NSOXdsJl3goOY6SXOAzZH9Gm6GHA6er
# NQ3Jv1fqYUw9EIPkmRinS63EfQIDAQABo4IBGzCCARcwHQYDVR0OBBYEFFDrnUZm
# p9yfHafON2hkd6UUG449MB8GA1UdIwQYMBaAFNVjOlyKMZDzQ3t8RhvFM2hahW1V
# MFYGA1UdHwRPME0wS6BJoEeGRWh0dHA6Ly9jcmwubWljcm9zb2Z0LmNvbS9wa2kv
# Y3JsL3Byb2R1Y3RzL01pY1RpbVN0YVBDQV8yMDEwLTA3LTAxLmNybDBaBggrBgEF
# BQcBAQROMEwwSgYIKwYBBQUHMAKGPmh0dHA6Ly93d3cubWljcm9zb2Z0LmNvbS9w
# a2kvY2VydHMvTWljVGltU3RhUENBXzIwMTAtMDctMDEuY3J0MAwGA1UdEwEB/wQC
# MAAwEwYDVR0lBAwwCgYIKwYBBQUHAwgwDQYJKoZIhvcNAQELBQADggEBAJ5oN6za
# 7MTTpAxYUC9hSlE1yJx940lEmJ/XPj3fidCS6EMrvxnBEJIYqmShwg02XT/4vpsG
# N9b4JjQFnYXP+UrOTD09Mwli7KvRQvUP4oCSU9AqZ6PMnIMF4s1ZCui824oUQ7GF
# FtNej33d1QMRDO24v27A2O/OV+BA4q8fdZsSNvQZkwPKwfeQVH2GtxhFPRmJf/eF
# SBbcXcdvFE2kcD53Z9NvP0Sntpuwm2TNDYE5fz9YHUtXTYEQTH9wuEdxEyKy/cgM
# X7RAGA1RVbA+COcUkQwBYqgubNnpYpp30yHJdEoBIfnSzVEZD7iWsQ0Vg8d0VJOk
# eqaq+zQMvJemgYIwggZxMIIEWaADAgECAgphCYEqAAAAAAACMA0GCSqGSIb3DQEB
# CwUAMIGIMQswCQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UE
# BxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMTIwMAYD
# VQQDEylNaWNyb3NvZnQgUm9vdCBDZXJ0aWZpY2F0ZSBBdXRob3JpdHkgMjAxMDAe
# Fw0xMDA3MDEyMTM2NTVaFw0yNTA3MDEyMTQ2NTVaMHwxCzAJBgNVBAYTAlVTMRMw
# EQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVN
# aWNyb3NvZnQgQ29ycG9yYXRpb24xJjAkBgNVBAMTHU1pY3Jvc29mdCBUaW1lLVN0
# YW1wIFBDQSAyMDEwMIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAqR0N
# vHcRijog7PwTl/X6f2mUa3RUENWlCgCChfvtfGhLLF/Fw+Vhwna3PmYrW/AVUycE
# MR9BGxqVHc4JE458YTBZsTBED/FgiIRUQwzXTbg4CLNC3ZOs1nMwVyaCo0UN0Or1
# R4HNvyRgMlhgRvJYR4YyhB50YWeRX4FUsc+TTJLBxKZd0WETbijGGvmGgLvfYfxG
# wScdJGcSchohiq9LZIlQYrFd/XcfPfBXday9ikJNQFHRD5wGPmd/9WbAA5ZEfu/Q
# S/1u5ZrKsajyeioKMfDaTgaRtogINeh4HLDpmc085y9Euqf03GS9pAHBIAmTeM38
# vMDJRF1eFpwBBU8iTQIDAQABo4IB5jCCAeIwEAYJKwYBBAGCNxUBBAMCAQAwHQYD
# VR0OBBYEFNVjOlyKMZDzQ3t8RhvFM2hahW1VMBkGCSsGAQQBgjcUAgQMHgoAUwB1
# AGIAQwBBMAsGA1UdDwQEAwIBhjAPBgNVHRMBAf8EBTADAQH/MB8GA1UdIwQYMBaA
# FNX2VsuP6KJcYmjRPZSQW9fOmhjEMFYGA1UdHwRPME0wS6BJoEeGRWh0dHA6Ly9j
# cmwubWljcm9zb2Z0LmNvbS9wa2kvY3JsL3Byb2R1Y3RzL01pY1Jvb0NlckF1dF8y
# MDEwLTA2LTIzLmNybDBaBggrBgEFBQcBAQROMEwwSgYIKwYBBQUHMAKGPmh0dHA6
# Ly93d3cubWljcm9zb2Z0LmNvbS9wa2kvY2VydHMvTWljUm9vQ2VyQXV0XzIwMTAt
# MDYtMjMuY3J0MIGgBgNVHSABAf8EgZUwgZIwgY8GCSsGAQQBgjcuAzCBgTA9Bggr
# BgEFBQcCARYxaHR0cDovL3d3dy5taWNyb3NvZnQuY29tL1BLSS9kb2NzL0NQUy9k
# ZWZhdWx0Lmh0bTBABggrBgEFBQcCAjA0HjIgHQBMAGUAZwBhAGwAXwBQAG8AbABp
# AGMAeQBfAFMAdABhAHQAZQBtAGUAbgB0AC4gHTANBgkqhkiG9w0BAQsFAAOCAgEA
# B+aIUQ3ixuCYP4FxAz2do6Ehb7Prpsz1Mb7PBeKp/vpXbRkws8LFZslq3/Xn8Hi9
# x6ieJeP5vO1rVFcIK1GCRBL7uVOMzPRgEop2zEBAQZvcXBf/XPleFzWYJFZLdO9C
# EMivv3/Gf/I3fVo/HPKZeUqRUgCvOA8X9S95gWXZqbVr5MfO9sp6AG9LMEQkIjzP
# 7QOllo9ZKby2/QThcJ8ySif9Va8v/rbljjO7Yl+a21dA6fHOmWaQjP9qYn/dxUoL
# kSbiOewZSnFjnXshbcOco6I8+n99lmqQeKZt0uGc+R38ONiU9MalCpaGpL2eGq4E
# QoO4tYCbIjggtSXlZOz39L9+Y1klD3ouOVd2onGqBooPiRa6YacRy5rYDkeagMXQ
# zafQ732D8OE7cQnfXXSYIghh2rBQHm+98eEA3+cxB6STOvdlR3jo+KhIq/fecn5h
# a293qYHLpwmsObvsxsvYgrRyzR30uIUBHoD7G4kqVDmyW9rIDVWZeodzOwjmmC3q
# jeAzLhIp9cAvVCch98isTtoouLGp25ayp0Kiyc8ZQU3ghvkqmqMRZjDTu3QyS99j
# e/WZii8bxyGvWbWu3EQ8l1Bx16HSxVXjad5XwdHeMMD9zOZN+w2/XU/pnR4ZOC+8
# z1gFLu8NoFA12u8JJxzVs341Hgi62jbb01+P3nSISRKhggLOMIICNwIBATCB+KGB
# 0KSBzTCByjELMAkGA1UEBhMCVVMxCzAJBgNVBAgTAldBMRAwDgYDVQQHEwdSZWRt
# b25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xLTArBgNVBAsTJE1p
# Y3Jvc29mdCBJcmVsYW5kIE9wZXJhdGlvbnMgTGltaXRlZDEmMCQGA1UECxMdVGhh
# bGVzIFRTUyBFU046OEQ0MS00QkY3LUIzQjcxJTAjBgNVBAMTHE1pY3Jvc29mdCBU
# aW1lLVN0YW1wIHNlcnZpY2WiIwoBATAHBgUrDgMCGgMVAL/8St6JpAyHqmttBvN/
# n0u6SS2hoIGDMIGApH4wfDELMAkGA1UEBhMCVVMxEzARBgNVBAgTCldhc2hpbmd0
# b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3Jh
# dGlvbjEmMCQGA1UEAxMdTWljcm9zb2Z0IFRpbWUtU3RhbXAgUENBIDIwMTAwDQYJ
# KoZIhvcNAQEFBQACBQDhDv1OMCIYDzIwMTkwODI3MDg1MjMwWhgPMjAxOTA4Mjgw
# ODUyMzBaMHcwPQYKKwYBBAGEWQoEATEvMC0wCgIFAOEO/U4CAQAwCgIBAAICG+4C
# Af8wBwIBAAICEX8wCgIFAOEQTs4CAQAwNgYKKwYBBAGEWQoEAjEoMCYwDAYKKwYB
# BAGEWQoDAqAKMAgCAQACAwehIKEKMAgCAQACAwGGoDANBgkqhkiG9w0BAQUFAAOB
# gQCgZruPAhl5h/Ip+nwL62ivxx24BHPPrdIU3LzchW/9G/kf/3d0mQwElXxPUhEz
# FGE/fVGC96ud2sOG4dU+dQ40V3+wNw8krgYBBREfN2K+PreHis/Xj0a4YKb1LzzJ
# Xdyndh1+fuHma53f9HZ2ZlJAP/oxfljvmq+NJcBrsAdddzGCAw0wggMJAgEBMIGT
# MHwxCzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdS
# ZWRtb25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xJjAkBgNVBAMT
# HU1pY3Jvc29mdCBUaW1lLVN0YW1wIFBDQSAyMDEwAhMzAAAA2aqWClHLm0vmAAAA
# AADZMA0GCWCGSAFlAwQCAQUAoIIBSjAaBgkqhkiG9w0BCQMxDQYLKoZIhvcNAQkQ
# AQQwLwYJKoZIhvcNAQkEMSIEIIy7g0DhzaGn1kYQNhcnl8+nEqvp+IVvORmNH6KW
# lP39MIH6BgsqhkiG9w0BCRACLzGB6jCB5zCB5DCBvQQg0iyJ8h8orY9BN7/KlKbL
# E+gS8CIKCOeTRYhoLQ7ak3EwgZgwgYCkfjB8MQswCQYDVQQGEwJVUzETMBEGA1UE
# CBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9z
# b2Z0IENvcnBvcmF0aW9uMSYwJAYDVQQDEx1NaWNyb3NvZnQgVGltZS1TdGFtcCBQ
# Q0EgMjAxMAITMwAAANmqlgpRy5tL5gAAAAAA2TAiBCCYBgGioIJo6QIhksn4ghhi
# wnAln1AUrzdV6bU/gH8//DANBgkqhkiG9w0BAQsFAASCAQCascEscGGIPjnreycJ
# wkdRxxHCTcfd0R8Fsvt3obbH87znF8dfgFThEPr21pRevzH6SlFW9Zh1M4aYuSh2
# kYbBraqw98EWmO2ICYNeQODZxrDA0+62RakAyVdVl3Z5hytaYr3/cpcx4SNWipsE
# 66ETphne7B/b2IUX7Muy8g2VRXpJY5gYlTmXlkOI0WaxST48ZXnwez9RJjuJOglE
# A6T6iWAFmyPnrjoMjjYPOo/AYXK39kGFYbZCawkC14dcmqTSJ+dfzqj8p3xiNrxi
# bKfC5rWA0f1F9CG8WuTEYe0gOJ5kXoRReQgHjkwTvnNWwK7nqaT4DPlC5yzntmnp
# 4A/h
# SIG # End signature block
