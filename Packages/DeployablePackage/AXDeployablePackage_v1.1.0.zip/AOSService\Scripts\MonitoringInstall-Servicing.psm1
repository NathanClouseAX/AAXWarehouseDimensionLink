<#
.SYNOPSIS
    Functions to manage the Monitoring Agent during servicing.

.DESCRIPTION
    Contains a set of functions used by the Dynamics 365 for Finance and Operations
    Enterprise Edition servicing process to interact with the Geneva Monitoring Agent.

.NOTES
    Requires PowerShell 3.0 or later.

    Configure Write-Message by calling Set-WriteMessageLogFilePath to set a
    file to send output to.

    Copyright © 2019 Microsoft. All rights reserved.
#>

# Module level variables to control default behavior of Write-Message.
[string]$Script:WriteMessageLogFilePath = $null

<#
.SYNOPSIS
    Set module level variable to control default behavior of Write-Message.
    Set to the full path of the file to append output to (default is null).
#>
function Set-WriteMessageLogFilePath
{
    [CmdletBinding()]
    Param([string]$Path)

    $Script:WriteMessageLogFilePath = $Path
}

<#
.SYNOPSIS
    Write messages to log file and/or output.
#>
function Write-Message
{
    [CmdletBinding()]
    Param(
        [parameter(Mandatory = $false, ValueFromPipeline = $true)][string[]]$Message,
        [switch]$Vrb,
        [string]$LogFilePath = $Script:WriteMessageLogFilePath)

    Process
    {
        if ($LogFilePath)
        {
            $Message | ForEach-Object { "$([DateTime]::UtcNow.ToString("yyyy-MM-dd HH:mm:ss")): $($_)" | Out-File -FilePath $LogFilePath -Append }
        }

        # Verbose messages only goes to log file.
        if (!$Vrb)
        {
            $Message | Write-Output
        }
    }
}

<#
.SYNOPSIS
    Returns the registry path for the MonitoringInstall settings.
#>
function Get-MonitoringInstallRegistryPath
{
    return "HKLM:\SOFTWARE\Microsoft\Dynamics\AX\Diagnostics\MonitoringInstall"
}

<#
.SYNOPSIS
    Returns the scheduled task path for the MonitoringInstall tasks.
#>
function Get-MonitoringInstallTaskPath
{
    # Task path must begin and end with "\" for Get-ScheduledTask to work.
    return "\Microsoft\Dynamics\AX\Diagnostics\"
}

<#
.SYNOPSIS
    Read the Monitoring installation path from registry.
#>
function Get-MonitoringInstallPath()
{
    $RegistryPath = Get-MonitoringInstallRegistryPath
    $InstallPathKey = "InstallPath"
    $InstallPath = $null

    if (Test-Path -LiteralPath $RegistryPath -ErrorAction SilentlyContinue)
    {
        $RegistryKey = Get-Item -LiteralPath $RegistryPath -ErrorAction SilentlyContinue
        if ($RegistryKey)
        {
            $InstallPath = $RegistryKey.GetValue($InstallPathKey)
            if (!$InstallPath)
            {
                Write-Message "Warning: Could not read MonitoringInstall registry key $($InstallPathKey) from: $($RegistryPath)" -Vrb
            }
        }
        else
        {
            Write-Message "Warning: Could not read MonitoringInstall registry keys from: $($RegistryPath)" -Vrb
        }
    }
    else
    {
        Write-Message "Warning: Could not find MonitoringInstall registry path: $($RegistryPath)" -Vrb
    }

    return $InstallPath
}

<#
.SYNOPSIS
    Get the default Monitoring installation path.
#>
function Get-MonitoringInstallPathDefault()
{
    if ($env:SERVICEDRIVE)
    {
        $InstallPath = Join-Path -Path "$($env:SERVICEDRIVE)" -ChildPath "Monitoring"
    }
    else
    {
        $InstallPath = Join-Path -Path "$($env:SystemDrive)" -ChildPath "Monitoring"
    }

    return $InstallPath
}

<#
.SYNOPSIS
    Read the Monitoring manifest path from registry.
#>
function Get-MonitoringManifestPath()
{
    $RegistryPath = Get-MonitoringInstallRegistryPath
    $ManifestPathKey = "ManifestPath"
    $ManifestPath = $null

    if (Test-Path -LiteralPath $RegistryPath -ErrorAction SilentlyContinue)
    {
        $RegistryKey = Get-Item -LiteralPath $RegistryPath -ErrorAction SilentlyContinue
        if ($RegistryKey)
        {
            $ManifestPath = $RegistryKey.GetValue($ManifestPathKey)
            if (!$ManifestPath)
            {
                Write-Message "Warning: Could not read MonitoringInstall registry key $($ManifestPathKey) from: $($RegistryPath)" -Vrb
            }
        }
        else
        {
            Write-Message "Warning: Could not read MonitoringInstall registry key: $($RegistryPath)" -Vrb
        }
    }
    else
    {
        Write-Message "Warning: Could not find MonitoringInstall registry path: $($RegistryPath)" -Vrb
    }

    return $ManifestPath
}

<#
.SYNOPSIS
    Get the default Monitoring manifest path.
#>
function Get-MonitoringManifestPathDefault()
{
    $InstallPath = Get-MonitoringInstallPath
    if (!$InstallPath)
    {
        $InstallPath = Get-MonitoringInstallPathDefault
    }

    $ManifestPath = Join-Path -Path $InstallPath -ChildPath "Instrumentation"

    return $ManifestPath
}

<#
.SYNOPSIS
    Create task for MonitoringInstall.exe action and run as SYSTEM.
#>
function Invoke-MonitoringInstallAsSystem([string]$MonitoringInstallFilePath, [string]$Action, [int]$MaxWaitSec = 300, [int]$MaxLogLines = 100, [switch]$UseExistingTask)
{
    try
    {
        $TaskPath = Get-MonitoringInstallTaskPath
        $TaskName = "MonitoringInstall-$($Action)"
        $MonitoringInstallPath = Split-Path -Path $MonitoringInstallFilePath -Parent
        $LogFilePath = Join-Path -Path $MonitoringInstallPath -ChildPath "$($TaskName).log"

        Write-Message "Getting the $($TaskName) task..." -Vrb
        $ExistingTask = Get-ScheduledTask -TaskPath $TaskPath -TaskName $TaskName -ErrorAction SilentlyContinue
        if ($ExistingTask)
        {
            if ($UseExistingTask)
            {
                Write-Message "Using existing $($TaskName) task found (State: $($ExistingTask.State))." -Vrb
                $Task = $ExistingTask
            }
            else
            {
                Write-Message "Existing $($TaskName) task found, but it will be replaced (State: $($ExistingTask.State))." -Vrb
            }
        }

        if (!$Task)
        {
            Write-Message "Creating $($TaskName) task to run as SYSTEM." -Vrb
            $TaskAction = New-ScheduledTaskAction -Execute $MonitoringInstallFilePath -Argument "/$($Action) /id:SingleAgent /log:$LogFilePath" -WorkingDirectory $MonitoringInstallPath
            $TaskSettings = New-ScheduledTaskSettingsSet -ExecutionTimeLimit (New-TimeSpan -Seconds $MaxWaitSec)
            $Task = Register-ScheduledTask -TaskPath $TaskPath -TaskName $TaskName -User "SYSTEM" -Action $TaskAction -Settings $TaskSettings -Force
        }

        Write-Message "Starting the $($TaskName) task..." -Vrb
        $Task | Start-ScheduledTask
        $ScheduledTask = $Task | Get-ScheduledTask
        Write-Message "Scheduled task started (State: $($ScheduledTask.State))." -Vrb

        Write-Message "Waiting up to $($MaxWaitSec) seconds for the $($TaskName) task to complete..." -Vrb
        [int]$WaitedSec = 0
        while ($ScheduledTask.State -ine "Ready" -and $WaitedSec -lt $MaxWaitSec)
        {
            Start-Sleep -Seconds 1
            $WaitedSec += 1
            $ScheduledTask = $Task | Get-ScheduledTask
        }

        # Check if task completed.
        if ($ScheduledTask.State -ine "Ready")
        {
            $ErrorMessage = "Exceeded timeout after waiting $($WaitedSec) seconds for the $($TaskName) task to complete (State: $($ScheduledTask.State))."
            Write-Message "Error: $($ErrorMessage)" -Vrb
            throw $ErrorMessage
        }
        else
        {
            Write-Message "Completed the $($TaskName) task after waiting $($WaitedSec) seconds (State: $($ScheduledTask.State))." -Vrb
            $TaskInfo = $ScheduledTask | Get-ScheduledTaskInfo
            if ($TaskInfo)
            {
                # Note: Currently the MonitoringInstall exit code cannot be used to determine success or failure.
                Write-Message "The exit code of the $($TaskName) task run at $($TaskInfo.LastRunTime.ToString("u")) is: $($TaskInfo.LastTaskResult)." -Vrb
            }
            else
            {
                Write-Message "Warning: No task run information could be found from the $($TaskName) task." -Vrb
            }
        }

        # Check log content.
        if (Test-Path -Path $LogFilePath -ErrorAction SilentlyContinue)
        {
            $LogContent = Get-Content -Path $LogFilePath -Tail $MaxLogLines
            if ($LogContent)
            {
                Write-Message "The MonitoringInstall $($Action) action log file exists at: $($LogFilePath)" -Vrb
                Write-Message "Contents of log (Last $($MaxLogLines)):" -Vrb
                foreach ($Line in $LogContent)
                {
                    Write-Message $Line -Vrb
                }

                Write-Message "*** End of Log ***" -Vrb
            }
            else
            {
                Write-Message "Warning: The MonitoringInstall $($Action) action did not write any contents to log file at: $($LogFilePath)" -Vrb
            }
        }
        else
        {
            Write-Message "Warning: The MonitoringInstall $($Action) action did not produce any log file at: $($LogFilePath)" -Vrb
        }
    }
    catch
    {
        Write-Message "Error: Failed to run MonitoringInstall $($Action) action: $($_.Message)." -Vrb
        throw
    }
    finally
    {
        # If task was triggered, make sure it is stopped.
        if ($ScheduledTask)
        {
            $ScheduledTask = $ScheduledTask | Get-ScheduledTask

            if ($ScheduledTask -and $ScheduledTask.State -ieq "Running")
            {
                Write-Message "Stopping the $($ScheduledTask.TaskName) task as it is still running." -Vrb
                $ScheduledTask | Stop-ScheduledTask
            }
        }
    }
}

<#
.SYNOPSIS
    Stop Monitoring Agent ETW sessions and processes.
#>
function Stop-MonitoringAgent([int]$MaxWaitSec = 300, [switch]$SkipIfNotInstalled)
{
    $InstallPath = Get-MonitoringInstallPath
    if (!$InstallPath)
    {
        # Return without action if Monitoring Install path was not found in registry and skip switch specified.
        if ($SkipIfNotInstalled)
        {
            Write-Message "No Monitoring Install path found in registry. No attempt to stop the Monitoring Agent will be made." -Vrb
            return
        }
        else
        {
            $InstallPath = Get-MonitoringInstallPathDefault
            Write-Message "Warning: No Monitoring Install path found in registry. Using default: $($InstallPath)." -Vrb
        }
    }

    $MonitoringInstallPath = Join-Path -Path $InstallPath -ChildPath "MonitoringInstall"
    if (!(Test-Path -Path $MonitoringInstallPath -ErrorAction SilentlyContinue))
    {
        throw "No MonitoringInstall folder found at: $($MonitoringInstallPath)"
    }

    $MonitoringInstallFilePath = Join-Path -Path $MonitoringInstallPath -ChildPath "MonitoringInstall.exe"
    if (!(Test-Path -Path $MonitoringInstallFilePath -ErrorAction SilentlyContinue))
    {
        throw "No MonitoringInstall.exe file found at: $($MonitoringInstallFilePath)"
    }

    # Stop the Monitoring Install task if it is running.
    # This must be done before attempting to stop Monitoring Agent as it could otherwise
    # be triggering a start of Monitoring Agent after attempting to stop it.
    try
    {
        Write-Message "Stopping Monitoring Install task..."
        Stop-MonitoringInstallTask -MaxWaitSec $MaxWaitSec
    }
    catch
    {
        # This may not be a problem that requires the update process to stop.
        Write-Message "Warning: Failed to stop the MonitoringInstall task: $($_.Message)."
    }

    # Stop Monitoring ETW Sessions as SYSTEM.
    try
    {
        Write-Message "Stopping Monitoring ETW Sessions..."
        Invoke-MonitoringInstallAsSystem -MonitoringInstallFilePath $MonitoringInstallFilePath -Action "StopSessions"
    }
    catch
    {
        # This may not be a problem that requires the update process to stop.
        Write-Message "Warning: MonitoringInstall failed to stop Monitoring ETW Sessions: $($_.Message)."
    }

    # Stop Monitoring Agent processes as SYSTEM.
    try
    {
        Write-Message "Stopping Monitoring Agent processes..."

        $StopAgentAction = "StopAgents"

        # Determine if MonitoringInstall.exe has the new and improved StopAgentLauncher action.
        # First released with MonitoringInstall.exe 9.3.1789.0 in January 2019.
        # Note: The old StopAgent doesn't actually stop the MonAgentLauncher process, so the other
        # Monitoring Agent processes will be restarted if it does not forcefully terminate it in time.
        $MonitoringInstallFile = Get-Item -Path $MonitoringInstallFilePath
        if ($MonitoringInstallFile.VersionInfo.FileVersion)
        {
            if ($MonitoringInstallFile.VersionInfo.FileMajorPart -ge 9 -and $MonitoringInstallFile.VersionInfo.FileMinorPart -ge 3 -and $MonitoringInstallFile.VersionInfo.FileBuildPart -ge 1789)
            {
                Write-Message "Using MonitoringInstall.exe $($MonitoringInstallFile.VersionInfo.FileVersion) with StopAgentLauncher action." -Vrb
                $StopAgentAction = "StopAgentLauncher"
            }
            else
            {
                Write-Message "Using MonitoringInstall.exe $($MonitoringInstallFile.VersionInfo.FileVersion) with StopAgents action." -Vrb
            }
        }
        else
        {
            Write-Message "Using MonitoringInstall.exe which has no file version information with StopAgents action." -Vrb
        }

        Invoke-MonitoringInstallAsSystem -MonitoringInstallFilePath $MonitoringInstallFilePath -Action $StopAgentAction
    }
    catch
    {
        # Not being able to stop the Monitoring Agent processes is a fatal problem.
        Write-Message "Error: MonitoringInstall failed to stop Monitoring Agent processes: $($_.Message)." -Vrb
        throw
    }
}

<#
.SYNOPSIS
    Start the task to register ETW events, build configurations, and start the Monitoring Agent.
#>
function Start-MonitoringAgent([int]$MaxWaitSec = 300, [switch]$SkipIfNotInstalled)
{
    $TaskPath = Get-MonitoringInstallTaskPath
    $TaskName = "MonitoringInstall"

    Write-Message "Getting the $($TaskName) task..." -Vrb
    $Task = Get-ScheduledTask -TaskPath $TaskPath -TaskName $TaskName -ErrorAction SilentlyContinue
    if (!$Task)
    {
        # Very old installations created the task in the root path.
        Write-Message "Warning: No '$($TaskName)' task found in path '$($TaskPath)'. Looking for task in all paths..." -Vrb
        $Task = Get-ScheduledTask | Where-Object -FilterScript { $_.TaskName -ieq $TaskName } | Select-Object -First 1
    }

    If ($Task)
    {
        Write-Message "The $($TaskName) task was found (State: $($Task.State))." -Vrb
        Write-Message "Starting the $($TaskName) task..." -Vrb
        $Task | Start-ScheduledTask
        $ScheduledTask = $Task | Get-ScheduledTask
        Write-Message "Scheduled task started (State: $($ScheduledTask.State))." -Vrb

        if ($MaxWaitSec -gt 0)
        {
            Write-Message "Waiting up to $($MaxWaitSec) seconds for the $($TaskName) task to complete..." -Vrb

            [int]$WaitedSec = 0
            while ($ScheduledTask.State -ine "Ready" -and $WaitedSec -lt $MaxWaitSec)
            {
                Start-Sleep -Seconds 1
                $WaitedSec += 1
                $ScheduledTask = $Task | Get-ScheduledTask
            }

            # Check if task completed.
            if ($ScheduledTask.State -ine "Ready")
            {
                $ErrorMessage = "Exceeded timeout after waiting $($WaitedSec) seconds for the $($TaskName) task to complete (State: $($ScheduledTask.State))."
                Write-Message "Error: $($ErrorMessage)" -Vrb
                throw $ErrorMessage
            }
            else
            {
                Write-Message "Completed the $($TaskName) task after waiting $($WaitedSec) seconds (State: $($ScheduledTask.State))." -Vrb
                $TaskInfo = $ScheduledTask | Get-ScheduledTaskInfo
                if ($TaskInfo)
                {
                    # Note: Currently the MonitoringInstall exit code cannot be used to determine success or failure.
                    Write-Message "The exit code of the $($TaskName) task run at $($TaskInfo.LastRunTime.ToString("u")) is: $($TaskInfo.LastTaskResult)." -Vrb
                }
                else
                {
                    Write-Message "Warning: No task run information could be found from the $($TaskName) task." -Vrb
                }
            }
        }
        else
        {
            Write-Message "Not waiting for the $($TaskName) task to complete." -Vrb
        }
    }
    else
    {
        # Only throw if Monitoring Install task was not found and no skip switch was specified.
        if ($SkipIfNotInstalled)
        {
            Write-Message "No Monitoring Install task found. No attempt to start the Monitoring Agent will be made." -Vrb
        }
        else
        {
            # Throw if the scheduled task is not found.
            throw "No scheduled task with the name '$($TaskName)' was found. Unable to start Monitoring Agent."
        }
    }
}

<#
.SYNOPSIS
    Stop the Monitoring Install task if it is currently running.
#>
function Stop-MonitoringInstallTask([int]$MaxWaitSec = 300)
{
    $TaskPath = Get-MonitoringInstallTaskPath
    $TaskName = "MonitoringInstall"

    Write-Message "Getting the $($TaskName) task..." -Vrb
    $Task = Get-ScheduledTask -TaskPath $TaskPath -TaskName $TaskName -ErrorAction SilentlyContinue
    if (!$Task)
    {
        # Very old installations created the task in the root path.
        Write-Message "Warning: No '$($TaskName)' task found in path '$($TaskPath)'. Looking for task in all paths..." -Vrb
        $Task = Get-ScheduledTask | Where-Object -FilterScript { $_.TaskName -ieq $TaskName } | Select-Object -First 1
    }

    If ($Task)
    {
        Write-Message "The $($TaskName) task was found (State: $($Task.State))." -Vrb
        if ($Task.State -ieq "Running")
        {
            Write-Message "Stopping the running $($TaskName) task..." -Vrb
            $Task | Stop-ScheduledTask
            $ScheduledTask = $Task | Get-ScheduledTask
            Write-Message "Scheduled task stopping (State: $($ScheduledTask.State))." -Vrb

            if ($MaxWaitSec -gt 0)
            {
                Write-Message "Waiting up to $($MaxWaitSec) seconds for the $($TaskName) task to stop..." -Vrb

                [int]$WaitedSec = 0
                while ($ScheduledTask.State -ine "Ready" -and $WaitedSec -lt $MaxWaitSec)
                {
                    Start-Sleep -Seconds 1
                    $WaitedSec += 1
                    $ScheduledTask = $Task | Get-ScheduledTask
                }

                # Check if task completed.
                if ($ScheduledTask.State -ine "Ready")
                {
                    $ErrorMessage = "Exceeded timeout after waiting $($WaitedSec) seconds for the $($TaskName) task to stop (State: $($ScheduledTask.State))."
                    Write-Message "Error: $($ErrorMessage)" -Vrb
                    throw $ErrorMessage
                }
                else
                {
                    Write-Message "Stopped the $($TaskName) task after waiting $($WaitedSec) seconds (State: $($ScheduledTask.State))." -Vrb

                    # Log task info only as additional information. The objective of this function is to stop
                    # the task if it is running, so the result of the task is not important.
                    $TaskInfo = $ScheduledTask | Get-ScheduledTaskInfo -ErrorAction SilentlyContinue
                    if ($TaskInfo)
                    {
                        Write-Message "The exit code of the $($TaskName) task run at $($TaskInfo.LastRunTime.ToString("u")) is: $($TaskInfo.LastTaskResult)." -Vrb
                    }
                    else
                    {
                        Write-Message "Warning: No task run information could be found from the $($TaskName) task." -Vrb
                    }
                }
            }
            else
            {
                Write-Message "Not waiting for the $($TaskName) task to stop." -Vrb
            }
        }
        else
        {
            Write-Message "Not stopping the $($TaskName) task as it is not running." -Vrb
        }
    }
    else
    {
        # If there is no task found, it is not running, and there is no action required to stop it.
        Write-Message "No Monitoring Install task was found, so there is no task to stop." -Vrb
    }
}
# SIG # Begin signature block
# MIIkfQYJKoZIhvcNAQcCoIIkbjCCJGoCAQExDzANBglghkgBZQMEAgEFADB5Bgor
# BgEEAYI3AgEEoGswaTA0BgorBgEEAYI3AgEeMCYCAwEAAAQQH8w7YFlLCE63JNLG
# KX7zUQIBAAIBAAIBAAIBAAIBADAxMA0GCWCGSAFlAwQCAQUABCDcT3X3edAAEI+u
# cVLkwAvWnbkOykcY4SK3QWpnyERnTqCCDYEwggX/MIID56ADAgECAhMzAAABA14l
# HJkfox64AAAAAAEDMA0GCSqGSIb3DQEBCwUAMH4xCzAJBgNVBAYTAlVTMRMwEQYD
# VQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNy
# b3NvZnQgQ29ycG9yYXRpb24xKDAmBgNVBAMTH01pY3Jvc29mdCBDb2RlIFNpZ25p
# bmcgUENBIDIwMTEwHhcNMTgwNzEyMjAwODQ4WhcNMTkwNzI2MjAwODQ4WjB0MQsw
# CQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9u
# ZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMR4wHAYDVQQDExVNaWNy
# b3NvZnQgQ29ycG9yYXRpb24wggEiMA0GCSqGSIb3DQEBAQUAA4IBDwAwggEKAoIB
# AQDRlHY25oarNv5p+UZ8i4hQy5Bwf7BVqSQdfjnnBZ8PrHuXss5zCvvUmyRcFrU5
# 3Rt+M2wR/Dsm85iqXVNrqsPsE7jS789Xf8xly69NLjKxVitONAeJ/mkhvT5E+94S
# nYW/fHaGfXKxdpth5opkTEbOttU6jHeTd2chnLZaBl5HhvU80QnKDT3NsumhUHjR
# hIjiATwi/K+WCMxdmcDt66VamJL1yEBOanOv3uN0etNfRpe84mcod5mswQ4xFo8A
# DwH+S15UD8rEZT8K46NG2/YsAzoZvmgFFpzmfzS/p4eNZTkmyWPU78XdvSX+/Sj0
# NIZ5rCrVXzCRO+QUauuxygQjAgMBAAGjggF+MIIBejAfBgNVHSUEGDAWBgorBgEE
# AYI3TAgBBggrBgEFBQcDAzAdBgNVHQ4EFgQUR77Ay+GmP/1l1jjyA123r3f3QP8w
# UAYDVR0RBEkwR6RFMEMxKTAnBgNVBAsTIE1pY3Jvc29mdCBPcGVyYXRpb25zIFB1
# ZXJ0byBSaWNvMRYwFAYDVQQFEw0yMzAwMTIrNDM3OTY1MB8GA1UdIwQYMBaAFEhu
# ZOVQBdOCqhc3NyK1bajKdQKVMFQGA1UdHwRNMEswSaBHoEWGQ2h0dHA6Ly93d3cu
# bWljcm9zb2Z0LmNvbS9wa2lvcHMvY3JsL01pY0NvZFNpZ1BDQTIwMTFfMjAxMS0w
# Ny0wOC5jcmwwYQYIKwYBBQUHAQEEVTBTMFEGCCsGAQUFBzAChkVodHRwOi8vd3d3
# Lm1pY3Jvc29mdC5jb20vcGtpb3BzL2NlcnRzL01pY0NvZFNpZ1BDQTIwMTFfMjAx
# MS0wNy0wOC5jcnQwDAYDVR0TAQH/BAIwADANBgkqhkiG9w0BAQsFAAOCAgEAn/XJ
# Uw0/DSbsokTYDdGfY5YGSz8eXMUzo6TDbK8fwAG662XsnjMQD6esW9S9kGEX5zHn
# wya0rPUn00iThoj+EjWRZCLRay07qCwVlCnSN5bmNf8MzsgGFhaeJLHiOfluDnjY
# DBu2KWAndjQkm925l3XLATutghIWIoCJFYS7mFAgsBcmhkmvzn1FFUM0ls+BXBgs
# 1JPyZ6vic8g9o838Mh5gHOmwGzD7LLsHLpaEk0UoVFzNlv2g24HYtjDKQ7HzSMCy
# RhxdXnYqWJ/U7vL0+khMtWGLsIxB6aq4nZD0/2pCD7k+6Q7slPyNgLt44yOneFuy
# bR/5WcF9ttE5yXnggxxgCto9sNHtNr9FB+kbNm7lPTsFA6fUpyUSj+Z2oxOzRVpD
# MYLa2ISuubAfdfX2HX1RETcn6LU1hHH3V6qu+olxyZjSnlpkdr6Mw30VapHxFPTy
# 2TUxuNty+rR1yIibar+YRcdmstf/zpKQdeTr5obSyBvbJ8BblW9Jb1hdaSreU0v4
# 6Mp79mwV+QMZDxGFqk+av6pX3WDG9XEg9FGomsrp0es0Rz11+iLsVT9qGTlrEOla
# P470I3gwsvKmOMs1jaqYWSRAuDpnpAdfoP7YO0kT+wzh7Qttg1DO8H8+4NkI6Iwh
# SkHC3uuOW+4Dwx1ubuZUNWZncnwa6lL2IsRyP64wggd6MIIFYqADAgECAgphDpDS
# AAAAAAADMA0GCSqGSIb3DQEBCwUAMIGIMQswCQYDVQQGEwJVUzETMBEGA1UECBMK
# V2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0
# IENvcnBvcmF0aW9uMTIwMAYDVQQDEylNaWNyb3NvZnQgUm9vdCBDZXJ0aWZpY2F0
# ZSBBdXRob3JpdHkgMjAxMTAeFw0xMTA3MDgyMDU5MDlaFw0yNjA3MDgyMTA5MDla
# MH4xCzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdS
# ZWRtb25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xKDAmBgNVBAMT
# H01pY3Jvc29mdCBDb2RlIFNpZ25pbmcgUENBIDIwMTEwggIiMA0GCSqGSIb3DQEB
# AQUAA4ICDwAwggIKAoICAQCr8PpyEBwurdhuqoIQTTS68rZYIZ9CGypr6VpQqrgG
# OBoESbp/wwwe3TdrxhLYC/A4wpkGsMg51QEUMULTiQ15ZId+lGAkbK+eSZzpaF7S
# 35tTsgosw6/ZqSuuegmv15ZZymAaBelmdugyUiYSL+erCFDPs0S3XdjELgN1q2jz
# y23zOlyhFvRGuuA4ZKxuZDV4pqBjDy3TQJP4494HDdVceaVJKecNvqATd76UPe/7
# 4ytaEB9NViiienLgEjq3SV7Y7e1DkYPZe7J7hhvZPrGMXeiJT4Qa8qEvWeSQOy2u
# M1jFtz7+MtOzAz2xsq+SOH7SnYAs9U5WkSE1JcM5bmR/U7qcD60ZI4TL9LoDho33
# X/DQUr+MlIe8wCF0JV8YKLbMJyg4JZg5SjbPfLGSrhwjp6lm7GEfauEoSZ1fiOIl
# XdMhSz5SxLVXPyQD8NF6Wy/VI+NwXQ9RRnez+ADhvKwCgl/bwBWzvRvUVUvnOaEP
# 6SNJvBi4RHxF5MHDcnrgcuck379GmcXvwhxX24ON7E1JMKerjt/sW5+v/N2wZuLB
# l4F77dbtS+dJKacTKKanfWeA5opieF+yL4TXV5xcv3coKPHtbcMojyyPQDdPweGF
# RInECUzF1KVDL3SV9274eCBYLBNdYJWaPk8zhNqwiBfenk70lrC8RqBsmNLg1oiM
# CwIDAQABo4IB7TCCAekwEAYJKwYBBAGCNxUBBAMCAQAwHQYDVR0OBBYEFEhuZOVQ
# BdOCqhc3NyK1bajKdQKVMBkGCSsGAQQBgjcUAgQMHgoAUwB1AGIAQwBBMAsGA1Ud
# DwQEAwIBhjAPBgNVHRMBAf8EBTADAQH/MB8GA1UdIwQYMBaAFHItOgIxkEO5FAVO
# 4eqnxzHRI4k0MFoGA1UdHwRTMFEwT6BNoEuGSWh0dHA6Ly9jcmwubWljcm9zb2Z0
# LmNvbS9wa2kvY3JsL3Byb2R1Y3RzL01pY1Jvb0NlckF1dDIwMTFfMjAxMV8wM18y
# Mi5jcmwwXgYIKwYBBQUHAQEEUjBQME4GCCsGAQUFBzAChkJodHRwOi8vd3d3Lm1p
# Y3Jvc29mdC5jb20vcGtpL2NlcnRzL01pY1Jvb0NlckF1dDIwMTFfMjAxMV8wM18y
# Mi5jcnQwgZ8GA1UdIASBlzCBlDCBkQYJKwYBBAGCNy4DMIGDMD8GCCsGAQUFBwIB
# FjNodHRwOi8vd3d3Lm1pY3Jvc29mdC5jb20vcGtpb3BzL2RvY3MvcHJpbWFyeWNw
# cy5odG0wQAYIKwYBBQUHAgIwNB4yIB0ATABlAGcAYQBsAF8AcABvAGwAaQBjAHkA
# XwBzAHQAYQB0AGUAbQBlAG4AdAAuIB0wDQYJKoZIhvcNAQELBQADggIBAGfyhqWY
# 4FR5Gi7T2HRnIpsLlhHhY5KZQpZ90nkMkMFlXy4sPvjDctFtg/6+P+gKyju/R6mj
# 82nbY78iNaWXXWWEkH2LRlBV2AySfNIaSxzzPEKLUtCw/WvjPgcuKZvmPRul1LUd
# d5Q54ulkyUQ9eHoj8xN9ppB0g430yyYCRirCihC7pKkFDJvtaPpoLpWgKj8qa1hJ
# Yx8JaW5amJbkg/TAj/NGK978O9C9Ne9uJa7lryft0N3zDq+ZKJeYTQ49C/IIidYf
# wzIY4vDFLc5bnrRJOQrGCsLGra7lstnbFYhRRVg4MnEnGn+x9Cf43iw6IGmYslmJ
# aG5vp7d0w0AFBqYBKig+gj8TTWYLwLNN9eGPfxxvFX1Fp3blQCplo8NdUmKGwx1j
# NpeG39rz+PIWoZon4c2ll9DuXWNB41sHnIc+BncG0QaxdR8UvmFhtfDcxhsEvt9B
# xw4o7t5lL+yX9qFcltgA1qFGvVnzl6UJS0gQmYAf0AApxbGbpT9Fdx41xtKiop96
# eiL6SJUfq/tHI4D1nvi/a7dLl+LrdXga7Oo3mXkYS//WsyNodeav+vyL6wuA6mk7
# r/ww7QRMjt/fdW1jkT3RnVZOT7+AVyKheBEyIXrvQQqxP/uozKRdwaGIm1dxVk5I
# RcBCyZt2WwqASGv9eZ/BvW1taslScxMNelDNMYIWUjCCFk4CAQEwgZUwfjELMAkG
# A1UEBhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQx
# HjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEoMCYGA1UEAxMfTWljcm9z
# b2Z0IENvZGUgU2lnbmluZyBQQ0EgMjAxMQITMwAAAQNeJRyZH6MeuAAAAAABAzAN
# BglghkgBZQMEAgEFAKCB0DAZBgkqhkiG9w0BCQMxDAYKKwYBBAGCNwIBBDAcBgor
# BgEEAYI3AgELMQ4wDAYKKwYBBAGCNwIBFTAvBgkqhkiG9w0BCQQxIgQglwKn0JYr
# Gf6lcaNWHvr7uXkFDMo8BtEfNDzFcREiVE8wZAYKKwYBBAGCNwIBDDFWMFSgNoA0
# AE4AZwBlAG4AQQBuAGQASQBuAHMAdABhAGwAbABCAGkAbgBhAHIAaQBlAHMALgBw
# AHMAMaEagBhodHRwOi8vd3d3Lm1pY3Jvc29mdC5jb20wDQYJKoZIhvcNAQEBBQAE
# ggEAb/lQBK6Y60Ss01yDhLofoVuRGMTO/WPVBCGk2wqUp+HlFTdv/JYptazS5g2x
# AOvp3Vs0yXLNaAjMui2q1nGhsBNrvCWLiJ4Tne5HiV8RRpZBbySXrEiu2JAlIMQx
# Or3r63Ut9XV7edWo9HtZoY8EJNKbAEHKwzjAKl29zpky8WrFoO/1jj5AqaRB+3wY
# pJIO0Q1a5M5gFNagIuv7IZiuOKtS57+NKEcPL9EIwob2CjzBlMCGcSkTNl+83Thf
# cYb9cH2NZMIiNc/GKE8Ks+TGe6QG4xmThoKAprPFNDJjSFfVzIdqcClq4j+yWSm2
# uGI8PJjsDU1xqioIR/NpCVSGxqGCE7owghO2BgorBgEEAYI3AwMBMYITpjCCE6IG
# CSqGSIb3DQEHAqCCE5MwghOPAgEDMQ8wDQYJYIZIAWUDBAIBBQAwggFYBgsqhkiG
# 9w0BCRABBKCCAUcEggFDMIIBPwIBAQYKKwYBBAGEWQoDATAxMA0GCWCGSAFlAwQC
# AQUABCA7BuFVI2qaVfeW7wuAuUTxIIyl9nborrXfNH7pyu7e6QIGXOWnwZ3uGBMy
# MDE5MDYwNTA4MTQ0MC44OTlaMAcCAQGAAgH0oIHUpIHRMIHOMQswCQYDVQQGEwJV
# UzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UE
# ChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMSkwJwYDVQQLEyBNaWNyb3NvZnQgT3Bl
# cmF0aW9ucyBQdWVydG8gUmljbzEmMCQGA1UECxMdVGhhbGVzIFRTUyBFU046NzI4
# RC1DNDVGLUY5RUIxJTAjBgNVBAMTHE1pY3Jvc29mdCBUaW1lLVN0YW1wIFNlcnZp
# Y2Wggg8iMIIE9TCCA92gAwIBAgITMwAAANPQlFadDr2DBgAAAAAA0zANBgkqhkiG
# 9w0BAQsFADB8MQswCQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4G
# A1UEBxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMSYw
# JAYDVQQDEx1NaWNyb3NvZnQgVGltZS1TdGFtcCBQQ0EgMjAxMDAeFw0xODA4MjMy
# MDI2NDBaFw0xOTExMjMyMDI2NDBaMIHOMQswCQYDVQQGEwJVUzETMBEGA1UECBMK
# V2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0
# IENvcnBvcmF0aW9uMSkwJwYDVQQLEyBNaWNyb3NvZnQgT3BlcmF0aW9ucyBQdWVy
# dG8gUmljbzEmMCQGA1UECxMdVGhhbGVzIFRTUyBFU046NzI4RC1DNDVGLUY5RUIx
# JTAjBgNVBAMTHE1pY3Jvc29mdCBUaW1lLVN0YW1wIFNlcnZpY2UwggEiMA0GCSqG
# SIb3DQEBAQUAA4IBDwAwggEKAoIBAQCu8pwugBdto6Ev70z2bCBvNqKL2fJFzUHB
# ev9e3WbUZZVOqQhlfMzMUkDl01g9jGUSfzqnx1EmAjUz2pJ3rTbK2YbLZRTU9PUA
# Y43lV2sgxv2iPCT8vdT+a4jgBZP4L450AnXKFeuTgRdvOm7NpYFGuq3Nqih8A1aU
# dcPto160vCbc+qJlIHwewjKcNWcDHkP/hW+NxACMXjVwebqv2WDwwPojIrZHYa40
# CYDyikKoT4mHM9ynawJN+Fesv81MPBbifWYvPWnLX6EtHgHUnVmAwE4uqCIjwIqF
# mELsMemWPnuVPB3IxogNW4PaZ7n6nJ1S8yJwca/A1adYppgIbZH1AgMBAAGjggEb
# MIIBFzAdBgNVHQ4EFgQUKFHKD69qEDubB2laWFSg7GrUZ3gwHwYDVR0jBBgwFoAU
# 1WM6XIoxkPNDe3xGG8UzaFqFbVUwVgYDVR0fBE8wTTBLoEmgR4ZFaHR0cDovL2Ny
# bC5taWNyb3NvZnQuY29tL3BraS9jcmwvcHJvZHVjdHMvTWljVGltU3RhUENBXzIw
# MTAtMDctMDEuY3JsMFoGCCsGAQUFBwEBBE4wTDBKBggrBgEFBQcwAoY+aHR0cDov
# L3d3dy5taWNyb3NvZnQuY29tL3BraS9jZXJ0cy9NaWNUaW1TdGFQQ0FfMjAxMC0w
# Ny0wMS5jcnQwDAYDVR0TAQH/BAIwADATBgNVHSUEDDAKBggrBgEFBQcDCDANBgkq
# hkiG9w0BAQsFAAOCAQEAPWLw/RQWtLCI/0PNudhl8FtKkGhJv6GV04eHiOobSCgE
# lcV/MtYOCFXg+jvGMl3QZc0FIK++ge9KQ4Kssp8JiSuigaYNm3+ijnhyJnOKZqHx
# XPRIWC2YFz18KhyWNUYMLeF9ZAjTSuj0xnhZSaa6GK8t/GvALlJtKCyaX+OkywuM
# EL/Pb38hIQXnf1r/eUaOX6p/7QEHPEv3NHqtQgHZDA87Cau5WZohADGlRdLyq3Eb
# 7Vbu0+QWXE5j+mxzbc3A8Z5+6wek1IEkRJ1j+Q4uOmfT+tF62jX39E7YreTLMvIr
# 7K3BGtgiMVILHG2A8QGlkfBoW/601SBBFmAQFaxfbzCCBnEwggRZoAMCAQICCmEJ
# gSoAAAAAAAIwDQYJKoZIhvcNAQELBQAwgYgxCzAJBgNVBAYTAlVTMRMwEQYDVQQI
# EwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNyb3Nv
# ZnQgQ29ycG9yYXRpb24xMjAwBgNVBAMTKU1pY3Jvc29mdCBSb290IENlcnRpZmlj
# YXRlIEF1dGhvcml0eSAyMDEwMB4XDTEwMDcwMTIxMzY1NVoXDTI1MDcwMTIxNDY1
# NVowfDELMAkGA1UEBhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAOBgNVBAcT
# B1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEmMCQGA1UE
# AxMdTWljcm9zb2Z0IFRpbWUtU3RhbXAgUENBIDIwMTAwggEiMA0GCSqGSIb3DQEB
# AQUAA4IBDwAwggEKAoIBAQCpHQ28dxGKOiDs/BOX9fp/aZRrdFQQ1aUKAIKF++18
# aEssX8XD5WHCdrc+Zitb8BVTJwQxH0EbGpUdzgkTjnxhMFmxMEQP8WCIhFRDDNdN
# uDgIs0Ldk6zWczBXJoKjRQ3Q6vVHgc2/JGAyWGBG8lhHhjKEHnRhZ5FfgVSxz5NM
# ksHEpl3RYRNuKMYa+YaAu99h/EbBJx0kZxJyGiGKr0tkiVBisV39dx898Fd1rL2K
# Qk1AUdEPnAY+Z3/1ZsADlkR+79BL/W7lmsqxqPJ6Kgox8NpOBpG2iAg16HgcsOmZ
# zTznL0S6p/TcZL2kAcEgCZN4zfy8wMlEXV4WnAEFTyJNAgMBAAGjggHmMIIB4jAQ
# BgkrBgEEAYI3FQEEAwIBADAdBgNVHQ4EFgQU1WM6XIoxkPNDe3xGG8UzaFqFbVUw
# GQYJKwYBBAGCNxQCBAweCgBTAHUAYgBDAEEwCwYDVR0PBAQDAgGGMA8GA1UdEwEB
# /wQFMAMBAf8wHwYDVR0jBBgwFoAU1fZWy4/oolxiaNE9lJBb186aGMQwVgYDVR0f
# BE8wTTBLoEmgR4ZFaHR0cDovL2NybC5taWNyb3NvZnQuY29tL3BraS9jcmwvcHJv
# ZHVjdHMvTWljUm9vQ2VyQXV0XzIwMTAtMDYtMjMuY3JsMFoGCCsGAQUFBwEBBE4w
# TDBKBggrBgEFBQcwAoY+aHR0cDovL3d3dy5taWNyb3NvZnQuY29tL3BraS9jZXJ0
# cy9NaWNSb29DZXJBdXRfMjAxMC0wNi0yMy5jcnQwgaAGA1UdIAEB/wSBlTCBkjCB
# jwYJKwYBBAGCNy4DMIGBMD0GCCsGAQUFBwIBFjFodHRwOi8vd3d3Lm1pY3Jvc29m
# dC5jb20vUEtJL2RvY3MvQ1BTL2RlZmF1bHQuaHRtMEAGCCsGAQUFBwICMDQeMiAd
# AEwAZQBnAGEAbABfAFAAbwBsAGkAYwB5AF8AUwB0AGEAdABlAG0AZQBuAHQALiAd
# MA0GCSqGSIb3DQEBCwUAA4ICAQAH5ohRDeLG4Jg/gXEDPZ2joSFvs+umzPUxvs8F
# 4qn++ldtGTCzwsVmyWrf9efweL3HqJ4l4/m87WtUVwgrUYJEEvu5U4zM9GASinbM
# QEBBm9xcF/9c+V4XNZgkVkt070IQyK+/f8Z/8jd9Wj8c8pl5SpFSAK84Dxf1L3mB
# ZdmptWvkx872ynoAb0swRCQiPM/tA6WWj1kpvLb9BOFwnzJKJ/1Vry/+tuWOM7ti
# X5rbV0Dp8c6ZZpCM/2pif93FSguRJuI57BlKcWOdeyFtw5yjojz6f32WapB4pm3S
# 4Zz5Hfw42JT0xqUKloakvZ4argRCg7i1gJsiOCC1JeVk7Pf0v35jWSUPei45V3ai
# caoGig+JFrphpxHLmtgOR5qAxdDNp9DvfYPw4TtxCd9ddJgiCGHasFAeb73x4QDf
# 5zEHpJM692VHeOj4qEir995yfmFrb3epgcunCaw5u+zGy9iCtHLNHfS4hQEegPsb
# iSpUObJb2sgNVZl6h3M7COaYLeqN4DMuEin1wC9UJyH3yKxO2ii4sanblrKnQqLJ
# zxlBTeCG+SqaoxFmMNO7dDJL32N79ZmKLxvHIa9Zta7cRDyXUHHXodLFVeNp3lfB
# 0d4wwP3M5k37Db9dT+mdHhk4L7zPWAUu7w2gUDXa7wknHNWzfjUeCLraNtvTX4/e
# dIhJEqGCA7AwggKYAgEBMIH+oYHUpIHRMIHOMQswCQYDVQQGEwJVUzETMBEGA1UE
# CBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9z
# b2Z0IENvcnBvcmF0aW9uMSkwJwYDVQQLEyBNaWNyb3NvZnQgT3BlcmF0aW9ucyBQ
# dWVydG8gUmljbzEmMCQGA1UECxMdVGhhbGVzIFRTUyBFU046NzI4RC1DNDVGLUY5
# RUIxJTAjBgNVBAMTHE1pY3Jvc29mdCBUaW1lLVN0YW1wIFNlcnZpY2WiJQoBATAJ
# BgUrDgMCGgUAAxUAZ0Jaca70ItpZJTXDi9RuapkSXWeggd4wgdukgdgwgdUxCzAJ
# BgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25k
# MR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xKTAnBgNVBAsTIE1pY3Jv
# c29mdCBPcGVyYXRpb25zIFB1ZXJ0byBSaWNvMScwJQYDVQQLEx5uQ2lwaGVyIE5U
# UyBFU046NERFOS0wQzVFLTNFMDkxKzApBgNVBAMTIk1pY3Jvc29mdCBUaW1lIFNv
# dXJjZSBNYXN0ZXIgQ2xvY2swDQYJKoZIhvcNAQEFBQACBQDgocofMCIYDzIwMTkw
# NjA1MTI1NzAzWhgPMjAxOTA2MDYxMjU3MDNaMHcwPQYKKwYBBAGEWQoEATEvMC0w
# CgIFAOChyh8CAQAwCgIBAAICB5QCAf8wBwIBAAICFgUwCgIFAOCjG58CAQAwNgYK
# KwYBBAGEWQoEAjEoMCYwDAYKKwYBBAGEWQoDAaAKMAgCAQACAxbjYKEKMAgCAQAC
# AwehIDANBgkqhkiG9w0BAQUFAAOCAQEAgbpaqXdJ3uWgpFExRu4t8HZwdFBkU0aH
# 2kOQyIPMN1ZMgo4swJytebp8mNLpyPS7n3+KQZtFqbwDgEMit49vdGnrQwRgczf3
# eTqVLQV7pzwk5MqmBCWUlTbtmFVv98ercjytOwot+ULZLZIyrB6rcpj6qZvfV79i
# 3ALbFSeJIWcrFKuQTfMSHhhNizmOLiYRzKE8RJQWDafJAL2Pp3AxyQtG61h2B0V8
# IgGFi2W3iP/oh9UGvAEvjMB2DHcWx0XOzc8onj7ZmP2o25zVgoPfNC7ECV0ljHqC
# XzuP+68uEtN2Ez+i29gltAv6q5xVbeYOXNuIslTsMTWitrLgCJGZMTGCAvUwggLx
# AgEBMIGTMHwxCzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYD
# VQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xJjAk
# BgNVBAMTHU1pY3Jvc29mdCBUaW1lLVN0YW1wIFBDQSAyMDEwAhMzAAAA09CUVp0O
# vYMGAAAAAADTMA0GCWCGSAFlAwQCAQUAoIIBMjAaBgkqhkiG9w0BCQMxDQYLKoZI
# hvcNAQkQAQQwLwYJKoZIhvcNAQkEMSIEIIT0+PGUfS7RwGEOIZ4yAM7nnpbnfJ5O
# Q88zpyB5S/UGMIHiBgsqhkiG9w0BCRACDDGB0jCBzzCBzDCBsQQUZ0Jaca70ItpZ
# JTXDi9RuapkSXWcwgZgwgYCkfjB8MQswCQYDVQQGEwJVUzETMBEGA1UECBMKV2Fz
# aGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0IENv
# cnBvcmF0aW9uMSYwJAYDVQQDEx1NaWNyb3NvZnQgVGltZS1TdGFtcCBQQ0EgMjAx
# MAITMwAAANPQlFadDr2DBgAAAAAA0zAWBBTbk3Zo5Vjowtpo0I51k9x69/V0ITAN
# BgkqhkiG9w0BAQsFAASCAQANaGB0bcdOa08grahIJZso6DJ9zyWc2VabfHcuWdcr
# onwyOK/dqqgqrzNk36+WZK1+1EIVJeG649bJt+yKBDI/VcA47/H/4OhMQWTjGfz4
# fqgK9wrXt9QWZBWL63fw074Kg/418qEGO0SLRTvkHSRX1BGE/TMOvCDGt+OVtev8
# RSOWFyLWH46yBhUHLaJ64ygG3XvgSefJWou31CIS4pMRQ3f8UmhwUeN2H4SaytQY
# UwbR9NNHjM1notDnvm/r1CE75/bbkMBwNShS3zh2/EoxpdS9ul8J/dp/G7PMS1GA
# 2PTErseoDaLAd0y3cTZMLa8MHe7zJdvzsEt8ptqdQimj
# SIG # End signature block
