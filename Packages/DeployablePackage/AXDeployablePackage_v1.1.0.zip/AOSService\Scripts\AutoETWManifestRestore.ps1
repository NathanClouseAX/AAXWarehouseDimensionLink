﻿<#
.SYNOPSIS
    Restore the ETW manifest files in the instrumentation folder from a backup.

.DESCRIPTION
    The script will stop the Monitoring Agent, unregister the existing ETW manifest files in the
    instrumentation folder, restore the ETW manifests from a previous backup, and run the
    MonitoringInstall scheduled task to register the updated ETW manifests and start the Monitoring
    Agent. MonitoringInstall-Servicing.psm1 must exist in the script folder.

    Exit codes:
       0: Success.
       2: Monitoring PowerShell module could not be initialized.
       4: Monitoring Agent could not be stopped.
       8: Monitoring Agent could not be started.
      16: One or more manifest files could not be removed.
      32: One or more manifest files could not be restored.
    1024: Unknown error.

    Copyright © 2019 Microsoft. All rights reserved.
#>
[CmdletBinding()]
Param(
    [Parameter(Mandatory = $false, HelpMessage = "The maximum number of seconds to wait for the stop tasks to complete.")]
    [int]$StopTaskMaxWaitSec = 300,
    [Parameter(Mandatory = $false, HelpMessage = "The maximum number of seconds to wait for the start task to complete. Set to 0 to not wait.")]
    [int]$StartTaskMaxWaitSec = 300,
    [Parameter(Mandatory = $false, HelpMessage = "The path to the log directory in which output should be written.")]
    [string]$LogDir
)

# Initialize exit code.
[int]$ExitCode = 0

# Initialize Monitoring module and logging.
[string]$LogPath = $null
try
{
    if ($LogDir)
    {
        # Add log file name.
        $LogPath = Join-Path -Path $LogDir -ChildPath "Monitoring-EtwRestore_$([DateTime]::UtcNow.ToString("yyyyMMddHHmmss")).log"

        if ([System.IO.Path]::IsPathRooted($LogPath))
        {
            # Ensure that the directory exists.
            $LogParentPath = Split-Path -Path $LogPath -Parent
            if (!(Test-Path -Path $LogParentPath -ErrorAction SilentlyContinue))
            {
                New-Item -Path $LogParentPath -ItemType "Directory" | Out-Null
            }
        }
        else
        {
            # Resolve relative path under current directory.
            $LogPath = Join-Path -Path $PSScriptRoot -ChildPath $LogPath
        }
    }

    $MonitoringModulePath = Join-Path -Path $PSScriptRoot -ChildPath "MonitoringInstall-Servicing.psm1"
    if (!(Test-Path -Path $MonitoringModulePath -ErrorAction SilentlyContinue))
    {
        throw "Monitoring servicing module not found at: $($MonitoringModulePath)"
    }

    # Import Monitoring module.
    Import-Module -Name $MonitoringModulePath

    # For Monitoring Write-Message - Set log file path.
    Set-WriteMessageLogFilePath -Path $LogPath
}
catch
{
    $ExitCode = 2
    $ErrorMessage = "Error initializing Monitoring PowerShell module from '$($MonitoringModulePath)': $($_)"

    # Use Write-Output since Write-Message is defined in module that could not be loaded.
    Write-Output "$([DateTime]::UtcNow.ToString("yyyy-MM-dd HH:mm:ss")): $($ErrorMessage)"
    Write-Output "$($_.ScriptStackTrace)"
    Write-Output "$($_.Exception)"

    # If a log path was defined, also write error message to it.
    if ($LogPath)
    {
        "$([DateTime]::UtcNow.ToString("yyyy-MM-dd HH:mm:ss")): $($ErrorMessage)" | Out-File -FilePath $LogPath -Append
        "$($_.ScriptStackTrace)" | Out-File -FilePath $LogPath -Append
        "$($_.Exception)" | Out-File -FilePath $LogPath -Append
        "ETW restore script failed with exit code: $($ExitCode)." | Out-File -FilePath $LogPath -Append
    }

    # Use throw to indicate error to AXUpdateInstaller.
    # In case of exceptions, the output is not captured, so only the error message and
    # log file contents will be available for diagnostics.
    throw "$($ErrorMessage) [Log: $($LogPath)]"
}

try
{
    Write-Message "Script to restore Monitoring ETW manifest files starting..."
    Write-Message "Command: $(@([Environment]::GetCommandLineArgs()) -join " ")" -Vrb

    # Set backup path. If the RunbookBackupFolder variable is not set, use ManualETWManifestBackup folder.
    $BackupFolder = $RunbookBackupFolder
    if (!$BackupFolder)
    {
        $BackupFolder = Join-Path -Path $PSScriptRoot -ChildPath "ManualETWManifestBackup"
    }

    Write-Message "ETW manifest backup path: $($BackupFolder)"

    # Check if there are any files to restore.
    [bool]$RestoreApplicable = $true
    if (Test-Path -Path $BackupFolder -ErrorAction SilentlyContinue)
    {
        $BackupFiles = @(Get-ChildItem -Path $BackupFolder -File)
        if ($BackupFiles.Count -eq 0)
        {
            $RestoreApplicable = $false
            Write-Message "ETW manifest backup path does not contain any files. Skipping ETW manifest restore step."
        }
    }
    else
    {
        $RestoreApplicable = $false
        Write-Message "ETW manifest backup path does not exist. Skipping ETW manifest update step."
    }

    # If applicable, unregister ETW events, stop agent, restore manifest files, register ETW events, and start agent.
    if ($RestoreApplicable)
    {
        # Stop the Monitoring Agent ETW sessions and agent processes.
        try
        {
            Write-Message "Stopping Monitoring Agent..."
            Stop-MonitoringAgent -MaxWaitSec $StopTaskMaxWaitSec -SkipIfNotInstalled
        }
        catch
        {
            # Set exit code to indicate Monitoring Agent could not be stopped.
            $ExitCode = 4

            # Throw to terminate script.
            throw
        }

        $ErrorMessages = @()

        # Restarting the EventLog service can prevent some locked file issues.
        Write-Message "Restarting EventLog service..." -Vrb
        try
        {
            Restart-Service -Name "EventLog" -Force
        }
        catch
        {
            Write-Message "Warning: Failed to restart EventLog service: $($_)" -Vrb
        }

        # Get Monitoring manifest path.
        $MonManifestPath = Get-MonitoringManifestPath
        if (!$MonManifestPath)
        {
            $MonManifestPath = Get-MonitoringManifestPathDefault
            Write-Message "Warning: No Monitoring Manifest path found in registry. Using default: $($MonManifestPath)" -Vrb
        }

        Write-Message "Monitoring manifest path: $($MonManifestPath)"

        if (!(Test-Path -Path $MonManifestPath -ErrorAction SilentlyContinue))
        {
            Write-Message "Monitoring manifest path was not found. Creating new directory: $($MonManifestPath)" -Vrb
            New-Item -ItemType Directory -Path $MonManifestPath | Out-Null
        }

        # Remove files from Monitoring manifest folder.
        $RemoveFiles = @(Get-ChildItem -Path $MonManifestPath -File)
        $RemoveErrors = @()
        Write-Message "Removing $($RemoveFiles.Count) files from Monitoring manifest folder..."
        foreach ($File in $RemoveFiles)
        {
            Write-Message "- [Removing] $($File.Name)" -Vrb

            [int]$Attempt = 1
            [int]$MaxAttempts = 3
            while ($Attempt -le $MaxAttempts)
            {
                try
                {
                    Remove-Item -Path $($File.FullName) -Force
                }
                catch
                {
                    if ($Attempt -lt $MaxAttempts)
                    {
                        Write-Message "- [Warning - $($Attempt)]: Failed to remove $($File.Name): $($_.Exception.Message)." -Vrb
                        Start-Sleep -Second 1
                    }
                    else
                    {
                        Write-Message "- [Error]: Failed all attempts to remove $($File.FullName): $($_.Exception.Message)." -Vrb
                        $RemoveErrors += $File
                    }
                }

                $Attempt++
            }
        }

        if ($RemoveErrors.Count -gt 0)
        {
            Write-Message "Error: Failed to remove $($RemoveErrors.Count) files from Monitoring manifest folder."
            $ErrorMessages += "Failed to remove $($RemoveErrors.Count) files from Monitoring manifest folder."
            $ExitCode = $ExitCode -bor 16
        }
        else
        {
            Write-Message "Manifest files were all removed from: $($MonManifestPath)"
        }

        # Restore Monitoring manifest folder from backup (no subfolders).
        $RestoreFiles = @(Get-ChildItem -Path $BackupFolder -File)
        $RestoreErrors = @()
        Write-Message "Restoring $($RestoreFiles.Count) files to Monitoring manifest folder..."
        foreach ($File in $RestoreFiles)
        {
            $DestinationFilePath = Join-Path -Path $MonManifestPath -ChildPath $($File.Name)
            Write-Message "- [Restoring] $($File.Name)" -Vrb

            [int]$Attempt = 1
            [int]$MaxAttempts = 3
            while ($Attempt -le $MaxAttempts)
            {
                try
                {
                    Copy-Item -Path $($File.FullName) -Destination $DestinationFilePath -Force
                }
                catch
                {
                    if ($Attempt -lt $MaxAttempts)
                    {
                        Write-Message "- [Warning - $($Attempt)]: Failed to restore $($File.Name): $($_.Exception.Message)." -Vrb
                        Start-Sleep -Second 1
                    }
                    else
                    {
                        Write-Message "- [Error]: Failed all attempts to restore $($File.FullName): $($_.Exception.Message)." -Vrb
                        $RestoreErrors += $File
                    }
                }

                $Attempt++
            }
        }

        if ($RestoreErrors.Count -gt 0)
        {
            Write-Message "Error: Failed to restore $($RestoreErrors.Count) files to Monitoring manifest folder."
            $ErrorMessages += "Failed to restore $($RestoreErrors.Count) files to Monitoring manifest folder."
            $ExitCode = $ExitCode -bor 32
        }
        else
        {
            Write-Message "Manifest files were all restored to: $($MonManifestPath)"
        }

        # Start the MonitoringInstall task.
        try
        {
            Write-Message "Starting Monitoring Agent..."
            Start-MonitoringAgent -MaxWaitSec $StartTaskMaxWaitSec -SkipIfNotInstalled
        }
        catch
        {
            Write-Message "Error: Failed to start Monitoring Agent: $($_)"
            $ErrorMessages += "Failed to start Monitoring Agent: $($_)"

            # Set exit code to indicate Monitoring Agent could not be started.
            $ExitCode = $ExitCode -bor 8
        }

        # Throw exception with error messages.
        if ($ErrorMessages.Count -gt 0)
        {
            $ErrorMessage = [string]::Join("; ", $ErrorMessages)
            throw $ErrorMessage
        }
    }
}
catch
{
    # Ensure non-zero exit code if an exception is caught and no exit code set.
    if ($ExitCode -eq 0)
    {
        $ExitCode = 1024
    }

    $ErrorMessage = "Error during ETW restore: $($_)"

    Write-Message $ErrorMessage
    Write-Message "$($_.ScriptStackTrace)" -Vrb
    Write-Message "$($_.Exception)" -Vrb
    Write-Message "ETW restore script failed with exit code: $($ExitCode)."

    # Use throw to indicate error to AXUpdateInstaller.
    # In case of exceptions, the output is not captured, so only the error message and
    # log file contents will be available for diagnostics.
    throw "$($ErrorMessage) [Log: $($LogPath)]"
}

Write-Message "ETW restore script completed with exit code: $($ExitCode)."
exit $ExitCode
# SIG # Begin signature block
# MIIkfQYJKoZIhvcNAQcCoIIkbjCCJGoCAQExDzANBglghkgBZQMEAgEFADB5Bgor
# BgEEAYI3AgEEoGswaTA0BgorBgEEAYI3AgEeMCYCAwEAAAQQH8w7YFlLCE63JNLG
# KX7zUQIBAAIBAAIBAAIBAAIBADAxMA0GCWCGSAFlAwQCAQUABCAUVrBOs6VHVob1
# UwXvScF4UVx5F6YjDceHpQsaOtrHaKCCDYEwggX/MIID56ADAgECAhMzAAABA14l
# HJkfox64AAAAAAEDMA0GCSqGSIb3DQEBCwUAMH4xCzAJBgNVBAYTAlVTMRMwEQYD
# VQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNy
# b3NvZnQgQ29ycG9yYXRpb24xKDAmBgNVBAMTH01pY3Jvc29mdCBDb2RlIFNpZ25p
# bmcgUENBIDIwMTEwHhcNMTgwNzEyMjAwODQ4WhcNMTkwNzI2MjAwODQ4WjB0MQsw
# CQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9u
# ZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMR4wHAYDVQQDExVNaWNy
# b3NvZnQgQ29ycG9yYXRpb24wggEiMA0GCSqGSIb3DQEBAQUAA4IBDwAwggEKAoIB
# AQDRlHY25oarNv5p+UZ8i4hQy5Bwf7BVqSQdfjnnBZ8PrHuXss5zCvvUmyRcFrU5
# 3Rt+M2wR/Dsm85iqXVNrqsPsE7jS789Xf8xly69NLjKxVitONAeJ/mkhvT5E+94S
# nYW/fHaGfXKxdpth5opkTEbOttU6jHeTd2chnLZaBl5HhvU80QnKDT3NsumhUHjR
# hIjiATwi/K+WCMxdmcDt66VamJL1yEBOanOv3uN0etNfRpe84mcod5mswQ4xFo8A
# DwH+S15UD8rEZT8K46NG2/YsAzoZvmgFFpzmfzS/p4eNZTkmyWPU78XdvSX+/Sj0
# NIZ5rCrVXzCRO+QUauuxygQjAgMBAAGjggF+MIIBejAfBgNVHSUEGDAWBgorBgEE
# AYI3TAgBBggrBgEFBQcDAzAdBgNVHQ4EFgQUR77Ay+GmP/1l1jjyA123r3f3QP8w
# UAYDVR0RBEkwR6RFMEMxKTAnBgNVBAsTIE1pY3Jvc29mdCBPcGVyYXRpb25zIFB1
# ZXJ0byBSaWNvMRYwFAYDVQQFEw0yMzAwMTIrNDM3OTY1MB8GA1UdIwQYMBaAFEhu
# ZOVQBdOCqhc3NyK1bajKdQKVMFQGA1UdHwRNMEswSaBHoEWGQ2h0dHA6Ly93d3cu
# bWljcm9zb2Z0LmNvbS9wa2lvcHMvY3JsL01pY0NvZFNpZ1BDQTIwMTFfMjAxMS0w
# Ny0wOC5jcmwwYQYIKwYBBQUHAQEEVTBTMFEGCCsGAQUFBzAChkVodHRwOi8vd3d3
# Lm1pY3Jvc29mdC5jb20vcGtpb3BzL2NlcnRzL01pY0NvZFNpZ1BDQTIwMTFfMjAx
# MS0wNy0wOC5jcnQwDAYDVR0TAQH/BAIwADANBgkqhkiG9w0BAQsFAAOCAgEAn/XJ
# Uw0/DSbsokTYDdGfY5YGSz8eXMUzo6TDbK8fwAG662XsnjMQD6esW9S9kGEX5zHn
# wya0rPUn00iThoj+EjWRZCLRay07qCwVlCnSN5bmNf8MzsgGFhaeJLHiOfluDnjY
# DBu2KWAndjQkm925l3XLATutghIWIoCJFYS7mFAgsBcmhkmvzn1FFUM0ls+BXBgs
# 1JPyZ6vic8g9o838Mh5gHOmwGzD7LLsHLpaEk0UoVFzNlv2g24HYtjDKQ7HzSMCy
# RhxdXnYqWJ/U7vL0+khMtWGLsIxB6aq4nZD0/2pCD7k+6Q7slPyNgLt44yOneFuy
# bR/5WcF9ttE5yXnggxxgCto9sNHtNr9FB+kbNm7lPTsFA6fUpyUSj+Z2oxOzRVpD
# MYLa2ISuubAfdfX2HX1RETcn6LU1hHH3V6qu+olxyZjSnlpkdr6Mw30VapHxFPTy
# 2TUxuNty+rR1yIibar+YRcdmstf/zpKQdeTr5obSyBvbJ8BblW9Jb1hdaSreU0v4
# 6Mp79mwV+QMZDxGFqk+av6pX3WDG9XEg9FGomsrp0es0Rz11+iLsVT9qGTlrEOla
# P470I3gwsvKmOMs1jaqYWSRAuDpnpAdfoP7YO0kT+wzh7Qttg1DO8H8+4NkI6Iwh
# SkHC3uuOW+4Dwx1ubuZUNWZncnwa6lL2IsRyP64wggd6MIIFYqADAgECAgphDpDS
# AAAAAAADMA0GCSqGSIb3DQEBCwUAMIGIMQswCQYDVQQGEwJVUzETMBEGA1UECBMK
# V2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0
# IENvcnBvcmF0aW9uMTIwMAYDVQQDEylNaWNyb3NvZnQgUm9vdCBDZXJ0aWZpY2F0
# ZSBBdXRob3JpdHkgMjAxMTAeFw0xMTA3MDgyMDU5MDlaFw0yNjA3MDgyMTA5MDla
# MH4xCzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdS
# ZWRtb25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xKDAmBgNVBAMT
# H01pY3Jvc29mdCBDb2RlIFNpZ25pbmcgUENBIDIwMTEwggIiMA0GCSqGSIb3DQEB
# AQUAA4ICDwAwggIKAoICAQCr8PpyEBwurdhuqoIQTTS68rZYIZ9CGypr6VpQqrgG
# OBoESbp/wwwe3TdrxhLYC/A4wpkGsMg51QEUMULTiQ15ZId+lGAkbK+eSZzpaF7S
# 35tTsgosw6/ZqSuuegmv15ZZymAaBelmdugyUiYSL+erCFDPs0S3XdjELgN1q2jz
# y23zOlyhFvRGuuA4ZKxuZDV4pqBjDy3TQJP4494HDdVceaVJKecNvqATd76UPe/7
# 4ytaEB9NViiienLgEjq3SV7Y7e1DkYPZe7J7hhvZPrGMXeiJT4Qa8qEvWeSQOy2u
# M1jFtz7+MtOzAz2xsq+SOH7SnYAs9U5WkSE1JcM5bmR/U7qcD60ZI4TL9LoDho33
# X/DQUr+MlIe8wCF0JV8YKLbMJyg4JZg5SjbPfLGSrhwjp6lm7GEfauEoSZ1fiOIl
# XdMhSz5SxLVXPyQD8NF6Wy/VI+NwXQ9RRnez+ADhvKwCgl/bwBWzvRvUVUvnOaEP
# 6SNJvBi4RHxF5MHDcnrgcuck379GmcXvwhxX24ON7E1JMKerjt/sW5+v/N2wZuLB
# l4F77dbtS+dJKacTKKanfWeA5opieF+yL4TXV5xcv3coKPHtbcMojyyPQDdPweGF
# RInECUzF1KVDL3SV9274eCBYLBNdYJWaPk8zhNqwiBfenk70lrC8RqBsmNLg1oiM
# CwIDAQABo4IB7TCCAekwEAYJKwYBBAGCNxUBBAMCAQAwHQYDVR0OBBYEFEhuZOVQ
# BdOCqhc3NyK1bajKdQKVMBkGCSsGAQQBgjcUAgQMHgoAUwB1AGIAQwBBMAsGA1Ud
# DwQEAwIBhjAPBgNVHRMBAf8EBTADAQH/MB8GA1UdIwQYMBaAFHItOgIxkEO5FAVO
# 4eqnxzHRI4k0MFoGA1UdHwRTMFEwT6BNoEuGSWh0dHA6Ly9jcmwubWljcm9zb2Z0
# LmNvbS9wa2kvY3JsL3Byb2R1Y3RzL01pY1Jvb0NlckF1dDIwMTFfMjAxMV8wM18y
# Mi5jcmwwXgYIKwYBBQUHAQEEUjBQME4GCCsGAQUFBzAChkJodHRwOi8vd3d3Lm1p
# Y3Jvc29mdC5jb20vcGtpL2NlcnRzL01pY1Jvb0NlckF1dDIwMTFfMjAxMV8wM18y
# Mi5jcnQwgZ8GA1UdIASBlzCBlDCBkQYJKwYBBAGCNy4DMIGDMD8GCCsGAQUFBwIB
# FjNodHRwOi8vd3d3Lm1pY3Jvc29mdC5jb20vcGtpb3BzL2RvY3MvcHJpbWFyeWNw
# cy5odG0wQAYIKwYBBQUHAgIwNB4yIB0ATABlAGcAYQBsAF8AcABvAGwAaQBjAHkA
# XwBzAHQAYQB0AGUAbQBlAG4AdAAuIB0wDQYJKoZIhvcNAQELBQADggIBAGfyhqWY
# 4FR5Gi7T2HRnIpsLlhHhY5KZQpZ90nkMkMFlXy4sPvjDctFtg/6+P+gKyju/R6mj
# 82nbY78iNaWXXWWEkH2LRlBV2AySfNIaSxzzPEKLUtCw/WvjPgcuKZvmPRul1LUd
# d5Q54ulkyUQ9eHoj8xN9ppB0g430yyYCRirCihC7pKkFDJvtaPpoLpWgKj8qa1hJ
# Yx8JaW5amJbkg/TAj/NGK978O9C9Ne9uJa7lryft0N3zDq+ZKJeYTQ49C/IIidYf
# wzIY4vDFLc5bnrRJOQrGCsLGra7lstnbFYhRRVg4MnEnGn+x9Cf43iw6IGmYslmJ
# aG5vp7d0w0AFBqYBKig+gj8TTWYLwLNN9eGPfxxvFX1Fp3blQCplo8NdUmKGwx1j
# NpeG39rz+PIWoZon4c2ll9DuXWNB41sHnIc+BncG0QaxdR8UvmFhtfDcxhsEvt9B
# xw4o7t5lL+yX9qFcltgA1qFGvVnzl6UJS0gQmYAf0AApxbGbpT9Fdx41xtKiop96
# eiL6SJUfq/tHI4D1nvi/a7dLl+LrdXga7Oo3mXkYS//WsyNodeav+vyL6wuA6mk7
# r/ww7QRMjt/fdW1jkT3RnVZOT7+AVyKheBEyIXrvQQqxP/uozKRdwaGIm1dxVk5I
# RcBCyZt2WwqASGv9eZ/BvW1taslScxMNelDNMYIWUjCCFk4CAQEwgZUwfjELMAkG
# A1UEBhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQx
# HjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEoMCYGA1UEAxMfTWljcm9z
# b2Z0IENvZGUgU2lnbmluZyBQQ0EgMjAxMQITMwAAAQNeJRyZH6MeuAAAAAABAzAN
# BglghkgBZQMEAgEFAKCB0DAZBgkqhkiG9w0BCQMxDAYKKwYBBAGCNwIBBDAcBgor
# BgEEAYI3AgELMQ4wDAYKKwYBBAGCNwIBFTAvBgkqhkiG9w0BCQQxIgQgN/c2GyiQ
# B3joQr7l7sxuzbS5pm2H5JYmBJ2ZctyulOwwZAYKKwYBBAGCNwIBDDFWMFSgNoA0
# AE4AZwBlAG4AQQBuAGQASQBuAHMAdABhAGwAbABCAGkAbgBhAHIAaQBlAHMALgBw
# AHMAMaEagBhodHRwOi8vd3d3Lm1pY3Jvc29mdC5jb20wDQYJKoZIhvcNAQEBBQAE
# ggEATcNC4HHXLqDvVagVgM6qSeaKAWivAGe82SrBqDZCHqOIGh9oLIhXisezUw34
# Bhvp6tF4ARPoKAdwDaOjgC5gDiZqSanjfuXxm2yIrtO91LJhzSEMCIRAPoqNXk/4
# Mr46CGR+4gB82rHY+FCRA9no7Q/SgbMcAs2lTpN/W+KMHh3JoVlJZJsA9XusgDvq
# MF/P7at1mb6Lkgr78ugO7XP9PGvLZl7QsUBIWSXIRRHHaEGWVIy8ArFQmXatqHL2
# O2O0bWhADh++mh3pLjpo9u5q8rpqq8l2zrNNsjpZpsXhIqmKp14PArL/Z7lrFhQh
# UUiWVVS7jM/xRCJkRYOg1ia2MqGCE7owghO2BgorBgEEAYI3AwMBMYITpjCCE6IG
# CSqGSIb3DQEHAqCCE5MwghOPAgEDMQ8wDQYJYIZIAWUDBAIBBQAwggFYBgsqhkiG
# 9w0BCRABBKCCAUcEggFDMIIBPwIBAQYKKwYBBAGEWQoDATAxMA0GCWCGSAFlAwQC
# AQUABCD3g1M5ai7DCZDUfc1R3epzSjfchiSZrj4QiwDjDWAQLQIGXOgEHiFEGBMy
# MDE5MDYwNTA4MTQ0MC43NjZaMAcCAQGAAgH0oIHUpIHRMIHOMQswCQYDVQQGEwJV
# UzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UE
# ChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMSkwJwYDVQQLEyBNaWNyb3NvZnQgT3Bl
# cmF0aW9ucyBQdWVydG8gUmljbzEmMCQGA1UECxMdVGhhbGVzIFRTUyBFU046QzBG
# NC0zMDg2LURFRjgxJTAjBgNVBAMTHE1pY3Jvc29mdCBUaW1lLVN0YW1wIFNlcnZp
# Y2Wggg8iMIIE9TCCA92gAwIBAgITMwAAANAcamBhwufhrQAAAAAA0DANBgkqhkiG
# 9w0BAQsFADB8MQswCQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4G
# A1UEBxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMSYw
# JAYDVQQDEx1NaWNyb3NvZnQgVGltZS1TdGFtcCBQQ0EgMjAxMDAeFw0xODA4MjMy
# MDI2MjhaFw0xOTExMjMyMDI2MjhaMIHOMQswCQYDVQQGEwJVUzETMBEGA1UECBMK
# V2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0
# IENvcnBvcmF0aW9uMSkwJwYDVQQLEyBNaWNyb3NvZnQgT3BlcmF0aW9ucyBQdWVy
# dG8gUmljbzEmMCQGA1UECxMdVGhhbGVzIFRTUyBFU046QzBGNC0zMDg2LURFRjgx
# JTAjBgNVBAMTHE1pY3Jvc29mdCBUaW1lLVN0YW1wIFNlcnZpY2UwggEiMA0GCSqG
# SIb3DQEBAQUAA4IBDwAwggEKAoIBAQCbPoY211rO+8Z9zCo8IAYVmps5IDy61+pD
# NMYTp0m8huVorXo5SKMmKAYnE0C1sg6srmX5Q0s4a64HYRinDv2ly2HM2cU36hva
# 3Ey1ZXtNkas6jSudX1Idqe3NuICGkOTGtydhBeSLWQ57tWx4c0/eFPyRb56B93OV
# e35gMirnNNUxG13+Z0PV52SRjGTZ+zUPZy7crK1UP8RNbKfHWd2PYZK6WSRv37Vd
# 7ocqC79HbP1xJb8pZLxTVCqWlfPokE1oZfKxmHTtBDlPyT1rGkqCgV97H/KWaAeX
# sy/WReXaWuaPVxJVCnpcEsRrgtfFmnSiNoEzu+fg7FIIBPXOkkYrAgMBAAGjggEb
# MIIBFzAdBgNVHQ4EFgQUA4Mol6hrJfLEUzIfma06vHcYxXEwHwYDVR0jBBgwFoAU
# 1WM6XIoxkPNDe3xGG8UzaFqFbVUwVgYDVR0fBE8wTTBLoEmgR4ZFaHR0cDovL2Ny
# bC5taWNyb3NvZnQuY29tL3BraS9jcmwvcHJvZHVjdHMvTWljVGltU3RhUENBXzIw
# MTAtMDctMDEuY3JsMFoGCCsGAQUFBwEBBE4wTDBKBggrBgEFBQcwAoY+aHR0cDov
# L3d3dy5taWNyb3NvZnQuY29tL3BraS9jZXJ0cy9NaWNUaW1TdGFQQ0FfMjAxMC0w
# Ny0wMS5jcnQwDAYDVR0TAQH/BAIwADATBgNVHSUEDDAKBggrBgEFBQcDCDANBgkq
# hkiG9w0BAQsFAAOCAQEApbwklmQJ31r0v5RTfzYZkW48IPXgYF18spdGCVoMGD7q
# K1GR5IXN0eTzTWNJTRpOkR4726dJ9trulEfwTDe9owtngVnUTTZco4j1Ba1hLnc0
# rcT1wZfbQc9bXWmhEI3KLobATjK7Stfz49VV9QvRgr3ldnqGGbY5miHg5CKOIGOr
# 9XDFtT3ve9jTqJZl8qxJVoKfHcUidYdGwfAKj8zcMIrt0+aE9V7G00wTNV9duDIA
# 5vazZAUkJh6vs+H2Hmsl0SreztcnLOuSGL5HwSJrenGPlBT4mEeZqRhdJWunQdNW
# fEGmN1ovQZs7KayRu9l5Oia8rM7wkXDVF9cE+cCBLDCCBnEwggRZoAMCAQICCmEJ
# gSoAAAAAAAIwDQYJKoZIhvcNAQELBQAwgYgxCzAJBgNVBAYTAlVTMRMwEQYDVQQI
# EwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNyb3Nv
# ZnQgQ29ycG9yYXRpb24xMjAwBgNVBAMTKU1pY3Jvc29mdCBSb290IENlcnRpZmlj
# YXRlIEF1dGhvcml0eSAyMDEwMB4XDTEwMDcwMTIxMzY1NVoXDTI1MDcwMTIxNDY1
# NVowfDELMAkGA1UEBhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAOBgNVBAcT
# B1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEmMCQGA1UE
# AxMdTWljcm9zb2Z0IFRpbWUtU3RhbXAgUENBIDIwMTAwggEiMA0GCSqGSIb3DQEB
# AQUAA4IBDwAwggEKAoIBAQCpHQ28dxGKOiDs/BOX9fp/aZRrdFQQ1aUKAIKF++18
# aEssX8XD5WHCdrc+Zitb8BVTJwQxH0EbGpUdzgkTjnxhMFmxMEQP8WCIhFRDDNdN
# uDgIs0Ldk6zWczBXJoKjRQ3Q6vVHgc2/JGAyWGBG8lhHhjKEHnRhZ5FfgVSxz5NM
# ksHEpl3RYRNuKMYa+YaAu99h/EbBJx0kZxJyGiGKr0tkiVBisV39dx898Fd1rL2K
# Qk1AUdEPnAY+Z3/1ZsADlkR+79BL/W7lmsqxqPJ6Kgox8NpOBpG2iAg16HgcsOmZ
# zTznL0S6p/TcZL2kAcEgCZN4zfy8wMlEXV4WnAEFTyJNAgMBAAGjggHmMIIB4jAQ
# BgkrBgEEAYI3FQEEAwIBADAdBgNVHQ4EFgQU1WM6XIoxkPNDe3xGG8UzaFqFbVUw
# GQYJKwYBBAGCNxQCBAweCgBTAHUAYgBDAEEwCwYDVR0PBAQDAgGGMA8GA1UdEwEB
# /wQFMAMBAf8wHwYDVR0jBBgwFoAU1fZWy4/oolxiaNE9lJBb186aGMQwVgYDVR0f
# BE8wTTBLoEmgR4ZFaHR0cDovL2NybC5taWNyb3NvZnQuY29tL3BraS9jcmwvcHJv
# ZHVjdHMvTWljUm9vQ2VyQXV0XzIwMTAtMDYtMjMuY3JsMFoGCCsGAQUFBwEBBE4w
# TDBKBggrBgEFBQcwAoY+aHR0cDovL3d3dy5taWNyb3NvZnQuY29tL3BraS9jZXJ0
# cy9NaWNSb29DZXJBdXRfMjAxMC0wNi0yMy5jcnQwgaAGA1UdIAEB/wSBlTCBkjCB
# jwYJKwYBBAGCNy4DMIGBMD0GCCsGAQUFBwIBFjFodHRwOi8vd3d3Lm1pY3Jvc29m
# dC5jb20vUEtJL2RvY3MvQ1BTL2RlZmF1bHQuaHRtMEAGCCsGAQUFBwICMDQeMiAd
# AEwAZQBnAGEAbABfAFAAbwBsAGkAYwB5AF8AUwB0AGEAdABlAG0AZQBuAHQALiAd
# MA0GCSqGSIb3DQEBCwUAA4ICAQAH5ohRDeLG4Jg/gXEDPZ2joSFvs+umzPUxvs8F
# 4qn++ldtGTCzwsVmyWrf9efweL3HqJ4l4/m87WtUVwgrUYJEEvu5U4zM9GASinbM
# QEBBm9xcF/9c+V4XNZgkVkt070IQyK+/f8Z/8jd9Wj8c8pl5SpFSAK84Dxf1L3mB
# ZdmptWvkx872ynoAb0swRCQiPM/tA6WWj1kpvLb9BOFwnzJKJ/1Vry/+tuWOM7ti
# X5rbV0Dp8c6ZZpCM/2pif93FSguRJuI57BlKcWOdeyFtw5yjojz6f32WapB4pm3S
# 4Zz5Hfw42JT0xqUKloakvZ4argRCg7i1gJsiOCC1JeVk7Pf0v35jWSUPei45V3ai
# caoGig+JFrphpxHLmtgOR5qAxdDNp9DvfYPw4TtxCd9ddJgiCGHasFAeb73x4QDf
# 5zEHpJM692VHeOj4qEir995yfmFrb3epgcunCaw5u+zGy9iCtHLNHfS4hQEegPsb
# iSpUObJb2sgNVZl6h3M7COaYLeqN4DMuEin1wC9UJyH3yKxO2ii4sanblrKnQqLJ
# zxlBTeCG+SqaoxFmMNO7dDJL32N79ZmKLxvHIa9Zta7cRDyXUHHXodLFVeNp3lfB
# 0d4wwP3M5k37Db9dT+mdHhk4L7zPWAUu7w2gUDXa7wknHNWzfjUeCLraNtvTX4/e
# dIhJEqGCA7AwggKYAgEBMIH+oYHUpIHRMIHOMQswCQYDVQQGEwJVUzETMBEGA1UE
# CBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9z
# b2Z0IENvcnBvcmF0aW9uMSkwJwYDVQQLEyBNaWNyb3NvZnQgT3BlcmF0aW9ucyBQ
# dWVydG8gUmljbzEmMCQGA1UECxMdVGhhbGVzIFRTUyBFU046QzBGNC0zMDg2LURF
# RjgxJTAjBgNVBAMTHE1pY3Jvc29mdCBUaW1lLVN0YW1wIFNlcnZpY2WiJQoBATAJ
# BgUrDgMCGgUAAxUAKSkfi3FxMlc3Nr+9neHTozE+jpWggd4wgdukgdgwgdUxCzAJ
# BgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25k
# MR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xKTAnBgNVBAsTIE1pY3Jv
# c29mdCBPcGVyYXRpb25zIFB1ZXJ0byBSaWNvMScwJQYDVQQLEx5uQ2lwaGVyIE5U
# UyBFU046NERFOS0wQzVFLTNFMDkxKzApBgNVBAMTIk1pY3Jvc29mdCBUaW1lIFNv
# dXJjZSBNYXN0ZXIgQ2xvY2swDQYJKoZIhvcNAQEFBQACBQDgoe+qMCIYDzIwMTkw
# NjA1MTUzNzE0WhgPMjAxOTA2MDYxNTM3MTRaMHcwPQYKKwYBBAGEWQoEATEvMC0w
# CgIFAOCh76oCAQAwCgIBAAICJIgCAf8wBwIBAAICGkIwCgIFAOCjQSoCAQAwNgYK
# KwYBBAGEWQoEAjEoMCYwDAYKKwYBBAGEWQoDAaAKMAgCAQACAxbjYKEKMAgCAQAC
# AwehIDANBgkqhkiG9w0BAQUFAAOCAQEAn1PXIp7ajoNoxABfprbhuZTwr0SUnXZr
# NbetydeHy3Pm99Xsugvuh65OxvQkpRKnjE6hShIJ+71z5o208RDY3zW2EsxGB+Kf
# doA8rL4Jzl3XGx3IIZkq6chyPT2zagh+T2A5+PG/NqNEkUoNtZNzjhcL1n9qW/rn
# 5MNuJvJ2XiHYoGhzViWx0C3QZM8JReuhgWAXN8Yr2VV2vd1curk3KIi/AH+KvnGQ
# 8eavR6DVPIfyrcEDLw7YDX5fwQHl3hGqooL9p1xIqdLy32co2uECyd5BdHE8QRck
# dhfT323gGi2Nw2ddnAyXJeeOXYlY1CC8pCgRcS9z3GrX3e4SN2kRTzGCAvUwggLx
# AgEBMIGTMHwxCzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYD
# VQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xJjAk
# BgNVBAMTHU1pY3Jvc29mdCBUaW1lLVN0YW1wIFBDQSAyMDEwAhMzAAAA0BxqYGHC
# 5+GtAAAAAADQMA0GCWCGSAFlAwQCAQUAoIIBMjAaBgkqhkiG9w0BCQMxDQYLKoZI
# hvcNAQkQAQQwLwYJKoZIhvcNAQkEMSIEILR7s4C0TbBagH3C2SCShOWVxRklDjR6
# haCy5FiPg70nMIHiBgsqhkiG9w0BCRACDDGB0jCBzzCBzDCBsQQUKSkfi3FxMlc3
# Nr+9neHTozE+jpUwgZgwgYCkfjB8MQswCQYDVQQGEwJVUzETMBEGA1UECBMKV2Fz
# aGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0IENv
# cnBvcmF0aW9uMSYwJAYDVQQDEx1NaWNyb3NvZnQgVGltZS1TdGFtcCBQQ0EgMjAx
# MAITMwAAANAcamBhwufhrQAAAAAA0DAWBBSlYy9xGQ2DS1tZH2oXtBPjoRKXdTAN
# BgkqhkiG9w0BAQsFAASCAQAQvoTrURCquufUZafU1wWIP8jXTNVMwW/QB/X4fhwJ
# wPDu3mPijGFILwL/eHjC8euw4QqxsFRgnMjRLTelb6lERuPWthogvKdcXqxu/utc
# SGIXbgNtB3oFcZcDHOwAt4DVvbMaeEKTwIepPVT8c6ho+XxXaWNWVo/DR2EX6HEc
# caVwclct5yDPZP9ZGwlJuKjo50PQCcwn6E1ZD5szt8Ok81s13SrvvJ9bqrwpS50d
# nWohkJLl8qoSe60g1A449ymi+lS1h7se3QaFwcSbqNujwYQkQn0Oq9TXVEXC1O0E
# a3QB0mPWBLQQitlnSxffmY5LnGGrD/cRW2iuV1bddM60
# SIG # End signature block
