﻿<#
.SYNOPSIS
    Module containing generic cmdlets for fault handling.

.DESCRIPTION
    Copyright © 2019 Microsoft. All rights reserved.
#>

<#
.SYNOPSIS
    Call to invoke a command with a backoff / retry on failure

.PARAMETER Command
    The script block of the command to execute.
    
.PARAMETER ArgumentList
    The list of arguments to pass to the command block.
    
.PARAMETER CommandOutput
    Reference parameter that is set to the Command output from the last attempt executed. 
    Note: if the TimeoutAction block is executed this will contain the output from that block's execution.
    
.PARAMETER RetryIntervalSec
    The retry interval in seconds. The sleep between attempts will multiply this value against the attempt number.
    
.PARAMETER TimeoutSeconds
    The maximum number of seconds to continue attempting retries from the start of the first attempt.
    Note: this is not a timeout on the command block execution. If the Command execution exceeds this 
    time it will not attempt a retry in the case of failure. Instead it will immediately proceed to 
    executing the TimeoutAction block (if specified).
    
.PARAMETER Logger
    Script block used to log execution messages.
    
.PARAMETER TimeoutAction
    The action to run if all retries have been exhausted.
    
.PARAMETER TreatTimeoutActionAsSuccess
    When specified, treat successful execution of TimeoutAction as success.
#>
[CmdletBinding]
function Invoke-RetryWithBackoff(
  [Parameter(Mandatory = $true)]
  [scriptblock] $Command, 
  
  [Parameter(Mandatory = $false)]
  [object[]] $ArgumentList = $(),
  
  [Parameter(Mandatory = $false)]
  [ref] $CommandOutput,

  [Parameter(Mandatory = $false)]
  [int]$RetryIntervalSec = 5, 
  
  [Parameter(Mandatory = $false)]
  [int]$TimeoutSeconds = 300, 
  
  [Parameter(Mandatory = $false)]
  [scriptblock]$Logger = {param($message) Write-Output $message},
  
  [Parameter(Mandatory = $false)]
  [scriptblock]$TimeoutAction,
  
  [Parameter(Mandatory = $false)]
  [switch] $TreatTimeoutActionAsSuccess
  )
{
  $timeoutTime = $(get-date).AddSeconds($TimeoutSeconds)
  $continue = $true
  $currentRetryIteration = 1
  
  while($continue)
  {
    $continue = $false

    try
    {
      # invoke the script block
      $retValue = Invoke-Command $Command -ArgumentList $ArgumentList -ErrorVariable errors

      # If an output variable was specified, set it with the output from the script block.
      if($CommandOutput)
      {
        $CommandOutput.Value = $retValue
      }
      
      return
    }
    catch
    {
      $sleepSeconds = $RetryIntervalSec * $currentRetryIteration
      $nextAttempt = $(Get-Date).AddSeconds($sleepSeconds)
      
      # script block failed. If another attempt is possible, sleep and try again. Otherwise rethrow the error.
      if($(Get-Date) -le $timeoutTime -and $nextAttempt -le $timeoutTime)
      {
        $currentRetryIteration+=1
        Invoke-Command $Logger -ArgumentList ("Warning: Command failed with: {0}" -f ($_ | Format-List -force | Out-String))
        Invoke-Command $Logger -ArgumentList "Sleeping for $sleepSeconds seconds before retrying."
        Start-Sleep $sleepSeconds
        Invoke-Command $Logger -ArgumentList "Done sleeping. Retrying..."

        # This is the only case where we'd continue.
        $continue = $true
      }
      else
      {
        Invoke-Command $Logger -ArgumentList ("Retries exhausted. Final attempt failure: {0}" -f ($_ | Format-List -force | Out-String))
        
        #If a timeout action was specified, execute it here.
        if($TimeoutAction)
        {
          Invoke-Command $Logger -ArgumentList ("Invoking timeout action...")
          $retValue = Invoke-Command $TimeoutAction -ErrorVariable timeoutErrors
          Invoke-Command $Logger -ArgumentList ("Timeout action completed.")
          
          if($CommandOutput)
          {
            $CommandOutput.Value = $retValue
          }

          if($TreatTimeoutActionAsSuccess)
          {
            Invoke-Command $Logger -ArgumentList "Timeout action treated as success."
            return
          }
        }

        # Re-throw the original command exception.
        throw $_
      }
    }
  }

  # This should never be reached but guard against unexpected failure in the catch block above.
  throw "An unexpected error occurred executing command."
}

Export-ModuleMember -Function Invoke-RetryWithBackoff
# SIG # Begin signature block
# MIIkfQYJKoZIhvcNAQcCoIIkbjCCJGoCAQExDzANBglghkgBZQMEAgEFADB5Bgor
# BgEEAYI3AgEEoGswaTA0BgorBgEEAYI3AgEeMCYCAwEAAAQQH8w7YFlLCE63JNLG
# KX7zUQIBAAIBAAIBAAIBAAIBADAxMA0GCWCGSAFlAwQCAQUABCDmCW3lk7U8ChV+
# MS0bGiaN9CgqhH/ub+m7uiMFb2WxeKCCDYEwggX/MIID56ADAgECAhMzAAABA14l
# HJkfox64AAAAAAEDMA0GCSqGSIb3DQEBCwUAMH4xCzAJBgNVBAYTAlVTMRMwEQYD
# VQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNy
# b3NvZnQgQ29ycG9yYXRpb24xKDAmBgNVBAMTH01pY3Jvc29mdCBDb2RlIFNpZ25p
# bmcgUENBIDIwMTEwHhcNMTgwNzEyMjAwODQ4WhcNMTkwNzI2MjAwODQ4WjB0MQsw
# CQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9u
# ZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMR4wHAYDVQQDExVNaWNy
# b3NvZnQgQ29ycG9yYXRpb24wggEiMA0GCSqGSIb3DQEBAQUAA4IBDwAwggEKAoIB
# AQDRlHY25oarNv5p+UZ8i4hQy5Bwf7BVqSQdfjnnBZ8PrHuXss5zCvvUmyRcFrU5
# 3Rt+M2wR/Dsm85iqXVNrqsPsE7jS789Xf8xly69NLjKxVitONAeJ/mkhvT5E+94S
# nYW/fHaGfXKxdpth5opkTEbOttU6jHeTd2chnLZaBl5HhvU80QnKDT3NsumhUHjR
# hIjiATwi/K+WCMxdmcDt66VamJL1yEBOanOv3uN0etNfRpe84mcod5mswQ4xFo8A
# DwH+S15UD8rEZT8K46NG2/YsAzoZvmgFFpzmfzS/p4eNZTkmyWPU78XdvSX+/Sj0
# NIZ5rCrVXzCRO+QUauuxygQjAgMBAAGjggF+MIIBejAfBgNVHSUEGDAWBgorBgEE
# AYI3TAgBBggrBgEFBQcDAzAdBgNVHQ4EFgQUR77Ay+GmP/1l1jjyA123r3f3QP8w
# UAYDVR0RBEkwR6RFMEMxKTAnBgNVBAsTIE1pY3Jvc29mdCBPcGVyYXRpb25zIFB1
# ZXJ0byBSaWNvMRYwFAYDVQQFEw0yMzAwMTIrNDM3OTY1MB8GA1UdIwQYMBaAFEhu
# ZOVQBdOCqhc3NyK1bajKdQKVMFQGA1UdHwRNMEswSaBHoEWGQ2h0dHA6Ly93d3cu
# bWljcm9zb2Z0LmNvbS9wa2lvcHMvY3JsL01pY0NvZFNpZ1BDQTIwMTFfMjAxMS0w
# Ny0wOC5jcmwwYQYIKwYBBQUHAQEEVTBTMFEGCCsGAQUFBzAChkVodHRwOi8vd3d3
# Lm1pY3Jvc29mdC5jb20vcGtpb3BzL2NlcnRzL01pY0NvZFNpZ1BDQTIwMTFfMjAx
# MS0wNy0wOC5jcnQwDAYDVR0TAQH/BAIwADANBgkqhkiG9w0BAQsFAAOCAgEAn/XJ
# Uw0/DSbsokTYDdGfY5YGSz8eXMUzo6TDbK8fwAG662XsnjMQD6esW9S9kGEX5zHn
# wya0rPUn00iThoj+EjWRZCLRay07qCwVlCnSN5bmNf8MzsgGFhaeJLHiOfluDnjY
# DBu2KWAndjQkm925l3XLATutghIWIoCJFYS7mFAgsBcmhkmvzn1FFUM0ls+BXBgs
# 1JPyZ6vic8g9o838Mh5gHOmwGzD7LLsHLpaEk0UoVFzNlv2g24HYtjDKQ7HzSMCy
# RhxdXnYqWJ/U7vL0+khMtWGLsIxB6aq4nZD0/2pCD7k+6Q7slPyNgLt44yOneFuy
# bR/5WcF9ttE5yXnggxxgCto9sNHtNr9FB+kbNm7lPTsFA6fUpyUSj+Z2oxOzRVpD
# MYLa2ISuubAfdfX2HX1RETcn6LU1hHH3V6qu+olxyZjSnlpkdr6Mw30VapHxFPTy
# 2TUxuNty+rR1yIibar+YRcdmstf/zpKQdeTr5obSyBvbJ8BblW9Jb1hdaSreU0v4
# 6Mp79mwV+QMZDxGFqk+av6pX3WDG9XEg9FGomsrp0es0Rz11+iLsVT9qGTlrEOla
# P470I3gwsvKmOMs1jaqYWSRAuDpnpAdfoP7YO0kT+wzh7Qttg1DO8H8+4NkI6Iwh
# SkHC3uuOW+4Dwx1ubuZUNWZncnwa6lL2IsRyP64wggd6MIIFYqADAgECAgphDpDS
# AAAAAAADMA0GCSqGSIb3DQEBCwUAMIGIMQswCQYDVQQGEwJVUzETMBEGA1UECBMK
# V2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0
# IENvcnBvcmF0aW9uMTIwMAYDVQQDEylNaWNyb3NvZnQgUm9vdCBDZXJ0aWZpY2F0
# ZSBBdXRob3JpdHkgMjAxMTAeFw0xMTA3MDgyMDU5MDlaFw0yNjA3MDgyMTA5MDla
# MH4xCzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdS
# ZWRtb25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xKDAmBgNVBAMT
# H01pY3Jvc29mdCBDb2RlIFNpZ25pbmcgUENBIDIwMTEwggIiMA0GCSqGSIb3DQEB
# AQUAA4ICDwAwggIKAoICAQCr8PpyEBwurdhuqoIQTTS68rZYIZ9CGypr6VpQqrgG
# OBoESbp/wwwe3TdrxhLYC/A4wpkGsMg51QEUMULTiQ15ZId+lGAkbK+eSZzpaF7S
# 35tTsgosw6/ZqSuuegmv15ZZymAaBelmdugyUiYSL+erCFDPs0S3XdjELgN1q2jz
# y23zOlyhFvRGuuA4ZKxuZDV4pqBjDy3TQJP4494HDdVceaVJKecNvqATd76UPe/7
# 4ytaEB9NViiienLgEjq3SV7Y7e1DkYPZe7J7hhvZPrGMXeiJT4Qa8qEvWeSQOy2u
# M1jFtz7+MtOzAz2xsq+SOH7SnYAs9U5WkSE1JcM5bmR/U7qcD60ZI4TL9LoDho33
# X/DQUr+MlIe8wCF0JV8YKLbMJyg4JZg5SjbPfLGSrhwjp6lm7GEfauEoSZ1fiOIl
# XdMhSz5SxLVXPyQD8NF6Wy/VI+NwXQ9RRnez+ADhvKwCgl/bwBWzvRvUVUvnOaEP
# 6SNJvBi4RHxF5MHDcnrgcuck379GmcXvwhxX24ON7E1JMKerjt/sW5+v/N2wZuLB
# l4F77dbtS+dJKacTKKanfWeA5opieF+yL4TXV5xcv3coKPHtbcMojyyPQDdPweGF
# RInECUzF1KVDL3SV9274eCBYLBNdYJWaPk8zhNqwiBfenk70lrC8RqBsmNLg1oiM
# CwIDAQABo4IB7TCCAekwEAYJKwYBBAGCNxUBBAMCAQAwHQYDVR0OBBYEFEhuZOVQ
# BdOCqhc3NyK1bajKdQKVMBkGCSsGAQQBgjcUAgQMHgoAUwB1AGIAQwBBMAsGA1Ud
# DwQEAwIBhjAPBgNVHRMBAf8EBTADAQH/MB8GA1UdIwQYMBaAFHItOgIxkEO5FAVO
# 4eqnxzHRI4k0MFoGA1UdHwRTMFEwT6BNoEuGSWh0dHA6Ly9jcmwubWljcm9zb2Z0
# LmNvbS9wa2kvY3JsL3Byb2R1Y3RzL01pY1Jvb0NlckF1dDIwMTFfMjAxMV8wM18y
# Mi5jcmwwXgYIKwYBBQUHAQEEUjBQME4GCCsGAQUFBzAChkJodHRwOi8vd3d3Lm1p
# Y3Jvc29mdC5jb20vcGtpL2NlcnRzL01pY1Jvb0NlckF1dDIwMTFfMjAxMV8wM18y
# Mi5jcnQwgZ8GA1UdIASBlzCBlDCBkQYJKwYBBAGCNy4DMIGDMD8GCCsGAQUFBwIB
# FjNodHRwOi8vd3d3Lm1pY3Jvc29mdC5jb20vcGtpb3BzL2RvY3MvcHJpbWFyeWNw
# cy5odG0wQAYIKwYBBQUHAgIwNB4yIB0ATABlAGcAYQBsAF8AcABvAGwAaQBjAHkA
# XwBzAHQAYQB0AGUAbQBlAG4AdAAuIB0wDQYJKoZIhvcNAQELBQADggIBAGfyhqWY
# 4FR5Gi7T2HRnIpsLlhHhY5KZQpZ90nkMkMFlXy4sPvjDctFtg/6+P+gKyju/R6mj
# 82nbY78iNaWXXWWEkH2LRlBV2AySfNIaSxzzPEKLUtCw/WvjPgcuKZvmPRul1LUd
# d5Q54ulkyUQ9eHoj8xN9ppB0g430yyYCRirCihC7pKkFDJvtaPpoLpWgKj8qa1hJ
# Yx8JaW5amJbkg/TAj/NGK978O9C9Ne9uJa7lryft0N3zDq+ZKJeYTQ49C/IIidYf
# wzIY4vDFLc5bnrRJOQrGCsLGra7lstnbFYhRRVg4MnEnGn+x9Cf43iw6IGmYslmJ
# aG5vp7d0w0AFBqYBKig+gj8TTWYLwLNN9eGPfxxvFX1Fp3blQCplo8NdUmKGwx1j
# NpeG39rz+PIWoZon4c2ll9DuXWNB41sHnIc+BncG0QaxdR8UvmFhtfDcxhsEvt9B
# xw4o7t5lL+yX9qFcltgA1qFGvVnzl6UJS0gQmYAf0AApxbGbpT9Fdx41xtKiop96
# eiL6SJUfq/tHI4D1nvi/a7dLl+LrdXga7Oo3mXkYS//WsyNodeav+vyL6wuA6mk7
# r/ww7QRMjt/fdW1jkT3RnVZOT7+AVyKheBEyIXrvQQqxP/uozKRdwaGIm1dxVk5I
# RcBCyZt2WwqASGv9eZ/BvW1taslScxMNelDNMYIWUjCCFk4CAQEwgZUwfjELMAkG
# A1UEBhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQx
# HjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEoMCYGA1UEAxMfTWljcm9z
# b2Z0IENvZGUgU2lnbmluZyBQQ0EgMjAxMQITMwAAAQNeJRyZH6MeuAAAAAABAzAN
# BglghkgBZQMEAgEFAKCB0DAZBgkqhkiG9w0BCQMxDAYKKwYBBAGCNwIBBDAcBgor
# BgEEAYI3AgELMQ4wDAYKKwYBBAGCNwIBFTAvBgkqhkiG9w0BCQQxIgQgHcozksRW
# eMzAIdmAM3YsZ00lnEO8WSKKv6pFCrEcn0UwZAYKKwYBBAGCNwIBDDFWMFSgNoA0
# AE4AZwBlAG4AQQBuAGQASQBuAHMAdABhAGwAbABCAGkAbgBhAHIAaQBlAHMALgBw
# AHMAMaEagBhodHRwOi8vd3d3Lm1pY3Jvc29mdC5jb20wDQYJKoZIhvcNAQEBBQAE
# ggEAkiAuwymsR6n0nYE2xK6G2/4WJsPA1gahr6zrua8TlU/Ra8CjNNOJR1aNqtoj
# 1sWkJxv6BGePsKg78UF6OMGD6CvCyXyReUOP9YRp+7O/R/7+MvPUeffSYOHK2dgG
# lEUKWWT11rIIu0au22HMeMc0rVHTt1lBnq/virY9aQ+IaDWhBFbBEB2TI/yE4jqZ
# Drnh22pn6sYtPnUQEUnYr5rHgq04snolHgUdMo49NTPBBqi4j6PhF6XrS+AQxLyG
# G+hj4qM6um7BTYIMqxm5UvCCXiF1/HBzy18k9UAhUEwCsPXZ9PjHmN45zIZtVPdG
# pBqy/hy1V6YiNO/eT6QouYfSEKGCE7owghO2BgorBgEEAYI3AwMBMYITpjCCE6IG
# CSqGSIb3DQEHAqCCE5MwghOPAgEDMQ8wDQYJYIZIAWUDBAIBBQAwggFYBgsqhkiG
# 9w0BCRABBKCCAUcEggFDMIIBPwIBAQYKKwYBBAGEWQoDATAxMA0GCWCGSAFlAwQC
# AQUABCBSsWDM8TVpLZl5LQZW2iCQgmGnxxXZQFKlZ/TXP7o0TwIGXOWn8Ju7GBMy
# MDE5MDYwNTA4MTQ0MC41NjlaMAcCAQGAAgH0oIHUpIHRMIHOMQswCQYDVQQGEwJV
# UzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UE
# ChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMSkwJwYDVQQLEyBNaWNyb3NvZnQgT3Bl
# cmF0aW9ucyBQdWVydG8gUmljbzEmMCQGA1UECxMdVGhhbGVzIFRTUyBFU046QjFC
# Ny1GNjdGLUZFQzIxJTAjBgNVBAMTHE1pY3Jvc29mdCBUaW1lLVN0YW1wIFNlcnZp
# Y2Wggg8iMIIE9TCCA92gAwIBAgITMwAAANK441ptxFsadwAAAAAA0jANBgkqhkiG
# 9w0BAQsFADB8MQswCQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4G
# A1UEBxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMSYw
# JAYDVQQDEx1NaWNyb3NvZnQgVGltZS1TdGFtcCBQQ0EgMjAxMDAeFw0xODA4MjMy
# MDI2MzRaFw0xOTExMjMyMDI2MzRaMIHOMQswCQYDVQQGEwJVUzETMBEGA1UECBMK
# V2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0
# IENvcnBvcmF0aW9uMSkwJwYDVQQLEyBNaWNyb3NvZnQgT3BlcmF0aW9ucyBQdWVy
# dG8gUmljbzEmMCQGA1UECxMdVGhhbGVzIFRTUyBFU046QjFCNy1GNjdGLUZFQzIx
# JTAjBgNVBAMTHE1pY3Jvc29mdCBUaW1lLVN0YW1wIFNlcnZpY2UwggEiMA0GCSqG
# SIb3DQEBAQUAA4IBDwAwggEKAoIBAQC+qpQoHYm0mqG66gSozjjHawbPv9kMIM7r
# jzn5nQkwULjbO6VsrEN/TxBqhKR0WNIhlBmDYKZ8z55RtjFJjIhmsZzpL1u/xfXT
# pDNmLAlWRmpMzuH4pYVD6ASSnEnE7oDhuaONwt1bZfs24rsdpbI0xZNMN4xSH/RV
# A9efrLJFmdHDn4R3tgUH1mk6SY9LN2kuEk7Fpt0tlVYW1+pWZrY6qHe6PFsfD6Ql
# aRgMoCk0DDaTYFSqldu1Nw2GIYZoYnQS74qs4HwN9LVAzs/W1zK4NvTGtKbxWn5S
# AFZ1qDQGVXGKqxl3e8pWuCOrOzMKsHIrDdNESpV1ZzK+kpW6OJdFAgMBAAGjggEb
# MIIBFzAdBgNVHQ4EFgQU7Kw4cXX6l8kj+VJyZUngPaJ34M4wHwYDVR0jBBgwFoAU
# 1WM6XIoxkPNDe3xGG8UzaFqFbVUwVgYDVR0fBE8wTTBLoEmgR4ZFaHR0cDovL2Ny
# bC5taWNyb3NvZnQuY29tL3BraS9jcmwvcHJvZHVjdHMvTWljVGltU3RhUENBXzIw
# MTAtMDctMDEuY3JsMFoGCCsGAQUFBwEBBE4wTDBKBggrBgEFBQcwAoY+aHR0cDov
# L3d3dy5taWNyb3NvZnQuY29tL3BraS9jZXJ0cy9NaWNUaW1TdGFQQ0FfMjAxMC0w
# Ny0wMS5jcnQwDAYDVR0TAQH/BAIwADATBgNVHSUEDDAKBggrBgEFBQcDCDANBgkq
# hkiG9w0BAQsFAAOCAQEARs9DKXEcDr02d0F6vRVnsIACciomkhaYKLn5bPll+AMj
# 0Jg/y5wfmXCUeS0J6B73VnkIsx/ZVvEp24krbJx9ZlTyHOOTYez7yhy43a5Htysu
# B7eVYnCgGbtfL3S98VONnlDpDBuBepy+ZyQcg006edb8Tk/1v1ktdj2WZnMDbOp2
# Sq00/05htEFzZGdCi+ZKRfwke/07TvD1UPXIgjpf/trZ6R6cI/FN17Ly2igHJPUc
# 6aFh0OHRd83kSllwO6luqXsbxV+p5ifyhSbH7UQFcGf2eZgviziHCZZZ+GUxAChF
# vhz38o5fgUuciJd3aoZ1RbpLeUC7FpSjVECk+XzZ+zCCBnEwggRZoAMCAQICCmEJ
# gSoAAAAAAAIwDQYJKoZIhvcNAQELBQAwgYgxCzAJBgNVBAYTAlVTMRMwEQYDVQQI
# EwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNyb3Nv
# ZnQgQ29ycG9yYXRpb24xMjAwBgNVBAMTKU1pY3Jvc29mdCBSb290IENlcnRpZmlj
# YXRlIEF1dGhvcml0eSAyMDEwMB4XDTEwMDcwMTIxMzY1NVoXDTI1MDcwMTIxNDY1
# NVowfDELMAkGA1UEBhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAOBgNVBAcT
# B1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEmMCQGA1UE
# AxMdTWljcm9zb2Z0IFRpbWUtU3RhbXAgUENBIDIwMTAwggEiMA0GCSqGSIb3DQEB
# AQUAA4IBDwAwggEKAoIBAQCpHQ28dxGKOiDs/BOX9fp/aZRrdFQQ1aUKAIKF++18
# aEssX8XD5WHCdrc+Zitb8BVTJwQxH0EbGpUdzgkTjnxhMFmxMEQP8WCIhFRDDNdN
# uDgIs0Ldk6zWczBXJoKjRQ3Q6vVHgc2/JGAyWGBG8lhHhjKEHnRhZ5FfgVSxz5NM
# ksHEpl3RYRNuKMYa+YaAu99h/EbBJx0kZxJyGiGKr0tkiVBisV39dx898Fd1rL2K
# Qk1AUdEPnAY+Z3/1ZsADlkR+79BL/W7lmsqxqPJ6Kgox8NpOBpG2iAg16HgcsOmZ
# zTznL0S6p/TcZL2kAcEgCZN4zfy8wMlEXV4WnAEFTyJNAgMBAAGjggHmMIIB4jAQ
# BgkrBgEEAYI3FQEEAwIBADAdBgNVHQ4EFgQU1WM6XIoxkPNDe3xGG8UzaFqFbVUw
# GQYJKwYBBAGCNxQCBAweCgBTAHUAYgBDAEEwCwYDVR0PBAQDAgGGMA8GA1UdEwEB
# /wQFMAMBAf8wHwYDVR0jBBgwFoAU1fZWy4/oolxiaNE9lJBb186aGMQwVgYDVR0f
# BE8wTTBLoEmgR4ZFaHR0cDovL2NybC5taWNyb3NvZnQuY29tL3BraS9jcmwvcHJv
# ZHVjdHMvTWljUm9vQ2VyQXV0XzIwMTAtMDYtMjMuY3JsMFoGCCsGAQUFBwEBBE4w
# TDBKBggrBgEFBQcwAoY+aHR0cDovL3d3dy5taWNyb3NvZnQuY29tL3BraS9jZXJ0
# cy9NaWNSb29DZXJBdXRfMjAxMC0wNi0yMy5jcnQwgaAGA1UdIAEB/wSBlTCBkjCB
# jwYJKwYBBAGCNy4DMIGBMD0GCCsGAQUFBwIBFjFodHRwOi8vd3d3Lm1pY3Jvc29m
# dC5jb20vUEtJL2RvY3MvQ1BTL2RlZmF1bHQuaHRtMEAGCCsGAQUFBwICMDQeMiAd
# AEwAZQBnAGEAbABfAFAAbwBsAGkAYwB5AF8AUwB0AGEAdABlAG0AZQBuAHQALiAd
# MA0GCSqGSIb3DQEBCwUAA4ICAQAH5ohRDeLG4Jg/gXEDPZ2joSFvs+umzPUxvs8F
# 4qn++ldtGTCzwsVmyWrf9efweL3HqJ4l4/m87WtUVwgrUYJEEvu5U4zM9GASinbM
# QEBBm9xcF/9c+V4XNZgkVkt070IQyK+/f8Z/8jd9Wj8c8pl5SpFSAK84Dxf1L3mB
# ZdmptWvkx872ynoAb0swRCQiPM/tA6WWj1kpvLb9BOFwnzJKJ/1Vry/+tuWOM7ti
# X5rbV0Dp8c6ZZpCM/2pif93FSguRJuI57BlKcWOdeyFtw5yjojz6f32WapB4pm3S
# 4Zz5Hfw42JT0xqUKloakvZ4argRCg7i1gJsiOCC1JeVk7Pf0v35jWSUPei45V3ai
# caoGig+JFrphpxHLmtgOR5qAxdDNp9DvfYPw4TtxCd9ddJgiCGHasFAeb73x4QDf
# 5zEHpJM692VHeOj4qEir995yfmFrb3epgcunCaw5u+zGy9iCtHLNHfS4hQEegPsb
# iSpUObJb2sgNVZl6h3M7COaYLeqN4DMuEin1wC9UJyH3yKxO2ii4sanblrKnQqLJ
# zxlBTeCG+SqaoxFmMNO7dDJL32N79ZmKLxvHIa9Zta7cRDyXUHHXodLFVeNp3lfB
# 0d4wwP3M5k37Db9dT+mdHhk4L7zPWAUu7w2gUDXa7wknHNWzfjUeCLraNtvTX4/e
# dIhJEqGCA7AwggKYAgEBMIH+oYHUpIHRMIHOMQswCQYDVQQGEwJVUzETMBEGA1UE
# CBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9z
# b2Z0IENvcnBvcmF0aW9uMSkwJwYDVQQLEyBNaWNyb3NvZnQgT3BlcmF0aW9ucyBQ
# dWVydG8gUmljbzEmMCQGA1UECxMdVGhhbGVzIFRTUyBFU046QjFCNy1GNjdGLUZF
# QzIxJTAjBgNVBAMTHE1pY3Jvc29mdCBUaW1lLVN0YW1wIFNlcnZpY2WiJQoBATAJ
# BgUrDgMCGgUAAxUAcPgof9VSM5lFaTg3Dr/lOZju88Kggd4wgdukgdgwgdUxCzAJ
# BgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25k
# MR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xKTAnBgNVBAsTIE1pY3Jv
# c29mdCBPcGVyYXRpb25zIFB1ZXJ0byBSaWNvMScwJQYDVQQLEx5uQ2lwaGVyIE5U
# UyBFU046NERFOS0wQzVFLTNFMDkxKzApBgNVBAMTIk1pY3Jvc29mdCBUaW1lIFNv
# dXJjZSBNYXN0ZXIgQ2xvY2swDQYJKoZIhvcNAQEFBQACBQDgocnxMCIYDzIwMTkw
# NjA1MTI1NjE3WhgPMjAxOTA2MDYxMjU2MTdaMHcwPQYKKwYBBAGEWQoEATEvMC0w
# CgIFAOChyfECAQAwCgIBAAICMecCAf8wBwIBAAICF+gwCgIFAOCjG3ECAQAwNgYK
# KwYBBAGEWQoEAjEoMCYwDAYKKwYBBAGEWQoDAaAKMAgCAQACAxbjYKEKMAgCAQAC
# AwehIDANBgkqhkiG9w0BAQUFAAOCAQEAZy+mtzYlffr3oXvD6rAcb/N6BJFeHE8J
# C7eN7gKrvDcy8M3953mXqHSQMpPF+jI8y0LE7pBFtelD/YEog5VhyMyRxHREpnlF
# 0SZs8KmSDmy+j5q1LnH4l5mJ21Tfvj8bkuNt940wSwcN0VKH6fCWyYXzoSC6bmRb
# phq/ektlhFsPafImFiSR0q0OvY8QDyUEX+GaXQ+nZWsemMlFmkDK+rKilmaNmLVZ
# xDbDxDwuvMUzP14QKiqiZLnNPjloitNMyHJ6yHrNw4K7Zzqi8PuP1fXyw9Ku8NdV
# ZnZqroU1i/pd4UT534KRPiosIn31hBgrUhHfEXnsJU22YNxWV7LdpTGCAvUwggLx
# AgEBMIGTMHwxCzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYD
# VQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xJjAk
# BgNVBAMTHU1pY3Jvc29mdCBUaW1lLVN0YW1wIFBDQSAyMDEwAhMzAAAA0rjjWm3E
# Wxp3AAAAAADSMA0GCWCGSAFlAwQCAQUAoIIBMjAaBgkqhkiG9w0BCQMxDQYLKoZI
# hvcNAQkQAQQwLwYJKoZIhvcNAQkEMSIEIHw5aetCU+sqwZ2s1wpdpQebZC0GO/wB
# cNvdd59prvYgMIHiBgsqhkiG9w0BCRACDDGB0jCBzzCBzDCBsQQUcPgof9VSM5lF
# aTg3Dr/lOZju88IwgZgwgYCkfjB8MQswCQYDVQQGEwJVUzETMBEGA1UECBMKV2Fz
# aGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0IENv
# cnBvcmF0aW9uMSYwJAYDVQQDEx1NaWNyb3NvZnQgVGltZS1TdGFtcCBQQ0EgMjAx
# MAITMwAAANK441ptxFsadwAAAAAA0jAWBBS3pb3A+y+UV2/FFRUaMq2193H6QDAN
# BgkqhkiG9w0BAQsFAASCAQBcU5dgh8XCPYcNwg+YZBeb/cZp0+TFgGIUhtZCuUvH
# oG3vUF1eokTVCeR5i5swVP0BHnkoxjn3P5YEVMBwjQgeKJ0EywleWhFsMw6xzIni
# W9Ra6JD/OVWhSDJZwLq30jJqqhj3EkKhcwaDBQEkvd6IoGidNKiMr+eIdcNEryak
# tEtGq0rOrQgoJs4VqMrnxnSl7BusCqxmUC899jAVrZhIlGJyA2/FTU10kSbfWLb/
# CQSthCU78/0BNCTR9xHYndNXpX6QI2B4DC+IzCvDxbOJz/xRMCY4fNyskEO0/bl3
# mW/VRgzy2WiL+P9IRM5QcaMofsoCVabd9VW6ozoelC6Y
# SIG # End signature block
